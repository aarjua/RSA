const express = require("express");
const proxy = require("express-http-proxy");
const cors = require("cors");
const morgan = require("morgan");
const dotenv = require("dotenv");
const path = require("path");

// Load environment variables from parent folder .env file.
const envPath = path.resolve(__dirname, `../${process.env.NODE_ENV || 'development'}.env`);
console.log('gateway envPath:', envPath)
dotenv.config({ path: envPath });

// Load environment variables from .env file in this service directory
const envPathLocal = path.resolve(__dirname, `./${process.env.NODE_ENV || 'development'}.env`);
console.log('gateway envPathLocal:', envPathLocal)
dotenv.config({ path: envPathLocal });

const app = express();
const port = process.env.PORT || 3016;
const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || `http://localhost:3018`;
const USER_SERVICE_URL = process.env.USER_SERVICE_URL || `http://localhost:3021`;
const AGGREGATOR_SERVICE_URL = process.env.AGGREGATOR_SERVICE_URL || `http://localhost:3022`;
const SETTING_SERVICE_URL = process.env.SETTING_SERVICE_URL || `http://localhost:3024`;
const PAYMENT_SERVICE_URL = process.env.PAYMENT_SERVICE_URL || `http://localhost:3027`;
app.use(morgan("dev"));
app.use(cors());

app.use('/api/auth', proxy(AUTH_SERVICE_URL));
app.use('/api/users', proxy(USER_SERVICE_URL, { limit: process.env.PAYLOAD_LIMIT || '50mb' }));
app.use('/api/agg', proxy(AGGREGATOR_SERVICE_URL));
app.use('/api/setting', proxy(SETTING_SERVICE_URL));
app.use('/api/payment', proxy(PAYMENT_SERVICE_URL));

app.get('/api', (req, res) => res.sendStatus(200));

app.listen(port, () => {
    console.log(`YAP Gateway server is up and running on port ${port}`);
    console.log(`YAP AGGREGATOR routes redirecting to ${AGGREGATOR_SERVICE_URL}`);
    console.log(`YAP AUTH routes redirecting to ${AUTH_SERVICE_URL}`);
    console.log(`YAP USER routes redirecting to ${USER_SERVICE_URL}`);
    console.log(`YAP SETTING routes redirecting to ${SETTING_SERVICE_URL}`);
    console.log(`YAP PAYMENT routes redirecting to ${PAYMENT_SERVICE_URL}`);
});