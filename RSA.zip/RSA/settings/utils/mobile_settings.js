const { toggleStatusDtos } = require("../dtos/mobile_settings.dtos");

const validateParamsId = (req) => {
  return new Promise(async (resolve, reject) => {
    try {
      await toggleStatusDtos.validateAsync(req.params);
      resolve(true);
    } catch (err) {
      reject(err);
    }
  });
};

const priceCalculation = (
  base_fare,
  totalRateDistancesRate,
  totalPeakHourRate,
  totalStopOver = 0,
  waitTimeChanges,
  tollTaxChanges,
  discount = 0,
  tax_amount,
  isPercentage
) => {
  let totalFareAmount = 0;
  let amountWithoutVat =
    +base_fare +
    totalRateDistancesRate +
    totalPeakHourRate +
    totalStopOver * 1 +
    waitTimeChanges +
    tollTaxChanges -
    discount;
  if (isPercentage) {
    totalFareAmount = amountWithoutVat + (amountWithoutVat * tax_amount) / 100;
  } else {
    totalFareAmount = amountWithoutVat + tax_amount;
  }
  return totalFareAmount;
};

const getTaxAmountCal = (total_amount, tax_amount, is_tax_percentage) => {
  return is_tax_percentage ? (total_amount * +tax_amount) / 100 : +tax_amount;
};
module.exports = {
  validateParamsId,
  priceCalculation,
  getTaxAmountCal,
};
