const express = require("express");
const router = express.Router();
const { OfferController} = require("../controllers");
const {
    multerMiddleware,
    auth: { auth },
  } = require("../middlewares");


router.route("/").get(OfferController.getAll);
router.route("/").post([auth(),multerMiddleware.uploadSingle("image")],OfferController.add)
router.route("/:id")
  .patch([auth(),multerMiddleware.uploadSingle("image")],OfferController.update)
  .delete(auth(),OfferController.delete)

module.exports = router;
