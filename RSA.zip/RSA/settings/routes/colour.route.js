const express = require("express");
const router = express.Router();
const { ColourController} = require("../controllers");
const {
  multerMiddleware,
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");


router.route("/").get(ColourController.getAll);
router.route("/").post(auth(),ColourController.add)
router.route("/:id")
  .patch(auth(),ColourController.update)
  .delete(auth(),ColourController.delete)
module.exports = router;
