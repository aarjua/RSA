const express = require("express");
const router = express.Router();
const { VehicleModelController} = require("../controllers");
const {
  multerMiddleware,
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");


router.route("/") .post(auth(),VehicleModelController.add);
router.route("/:id") .patch(auth(),VehicleModelController.update)
router.route("/") .get(VehicleModelController.getAll);
router.route("/:id") .delete(auth(),VehicleModelController.delete);
router.route("/toggleStatus/:id") .patch(auth(),VehicleModelController.toggleVehicle);
module.exports = router;
