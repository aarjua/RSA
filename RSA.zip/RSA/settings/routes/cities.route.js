const express = require("express");
const router = express.Router();
const citiesController = require("../controllers/cities.controller");

router.route("/:countryId").get(citiesController.getCitiesById);

module.exports = router;
