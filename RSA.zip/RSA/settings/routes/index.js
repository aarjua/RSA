var express = require("express");
var router = express.Router();

router.get("/hc", (req, res) => res.sendStatus(200));
// Mobile settings
console.log("setting here")
router.use("/countries", require("./country.route"));
router.use("/get_cities_by_country", require("./cities.route"));
router.use("/rate_distances", require("./rate_distances.route"));
router.use("/peak_hours", require("./peak_hours.route"));
router.use("/mobile_settings", require("./mobile_settings.route"));

router.use("/enum/categories", require("./category.route"));
router.use("/enum/colours", require("./colour.route"));
router.use("/enum/fuels", require("./fuel.route"));
router.use("/enum/vehicles", require("./vehicle.route"));
router.use("/enum/vehicles/brands", require("./vehicle.brand.route"));
router.use("/enum/vehicles/types", require("./vehicle.type.route"));
router.use("/enum/vehicles/models", require("./vehicle.model.route"));
router.use("/enum/prices", require("./price.route"));
router.use("/enum/offers", require("./offer.route"));
router.use("/pages", require("./page.route"));
router.use("/recommendation", require("./recommendation_price.route"));
router.use("/email_settings", require("./email.settings.route"));

module.exports = router;
