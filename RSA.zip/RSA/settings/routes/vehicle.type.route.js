const express = require("express");
const router = express.Router();
const { VehicleTypeController} = require("../controllers");
const {
  multerMiddleware,
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");


router.route("/") .post(auth(),VehicleTypeController.add);
router.route("/:id") .patch(auth(),VehicleTypeController.update)
router.route("/") .get(VehicleTypeController.getAll);
router.route("/:id") .delete(auth(),VehicleTypeController.delete);
module.exports = router;
