const express = require("express");
const router = express.Router();
const { FuelController} = require("../controllers");
const {
    multerMiddleware,
    auth: { auth },
  } = require("../middlewares");


router.route("/").get(auth(),FuelController.getAll);
router.route("/").post([auth(),multerMiddleware.uploadSingle("image")],FuelController.add)
router.route("/:id")
  .patch([auth(),multerMiddleware.uploadSingle("image")],FuelController.update)
  .delete(auth(),FuelController.delete)

module.exports = router;
