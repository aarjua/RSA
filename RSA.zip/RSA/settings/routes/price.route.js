const express = require("express");
const router = express.Router();
const { PriceController} = require("../controllers");
const {
    multerMiddleware,
    auth: { auth },
  } = require("../middlewares");


router.route("/").get(auth(),PriceController.getAll);
router.route("/").post(auth(),PriceController.add)
router.route("/:id")
  .patch(auth(),PriceController.update)
  .delete(auth(),PriceController.delete)

module.exports = router;
