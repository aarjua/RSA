const express = require("express");
const router = express.Router();
const rateDistancesController = require("../controllers/rate_distances.controller");

router
  .route("/:countryId/:cityId?")
  .get(rateDistancesController.getRateDistancesByCountryId)
  .post(rateDistancesController.addRateDistancesByCountryId);
router
  .route("/:rateDistanceId/:countryId/:cityId?")
  .patch(rateDistancesController.updateRateDistancesByCountryId);
router
  .route("/:rateDistanceId")
  .delete(rateDistancesController.deleteRateDistancesById);
module.exports = router;
