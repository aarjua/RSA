const express = require("express");
const router = express.Router();
const { EmailController } = require("../controllers");

router.route("/").post(EmailController.add);
router.route("/").get(EmailController.get);
router
  .route("/:id")
  .patch(EmailController.update)
module.exports = router;
