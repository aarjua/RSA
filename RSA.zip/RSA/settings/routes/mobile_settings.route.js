const express = require("express");
const router = express.Router();
const { MobileSettings } = require("../controllers");

router.route("/add").post(MobileSettings.addMobileSettings);
router.route("/update/:id").patch(MobileSettings.updateMobileSettings);
router.route("/").get(MobileSettings.getMobileSettingsListing);
router
  .route("/:id")
  .get(MobileSettings.getMobileSettingsById)
  .patch(MobileSettings.toggleStatus)
  .delete(MobileSettings.deleteMobileSettings);
module.exports = router;
