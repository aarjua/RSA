const express = require("express");
const router = express.Router();
const { PageController } = require("../controllers");


router.route("/:type").get(PageController.get);
router.route("/").post(PageController.add);
router.route("/:id").patch(PageController.update);
router.route("/:id").delete(PageController.delete);
module.exports = router;
