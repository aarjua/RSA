const express = require("express");
const router = express.Router();
const { VehicleController} = require("../controllers");
const {
  multerMiddleware,
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");



// router.route("/vehicleTypeList") .get(VehicleTypeController.getAll);
router.route("/vehicleList").get(VehicleController.getVehicleList);
router.route("/vehicleDelete/:id").delete(auth(),VehicleController.deleteVehicle);
router.route("/vehicleView/:id").get(VehicleController.getVehicle);
router.route("/addVehicle").post([auth(),multerMiddleware.uploadSingle("image")],VehicleController.addVehicle);
router.route("/toggleStatus/:id").patch(auth(),VehicleController.toggleVehicle);
router.route("/vehicleUpdate/:id").patch([auth(),multerMiddleware.uploadSingle("image")],VehicleController.updateVehicle);
// router.route("/brands") .get(VehicleController.getVehicleBrands)
// router.route("/types") .get(VehicleController.getVehicleTypes)

router.route("/").get(VehicleController.getAll);
router.route("/").post([auth(),multerMiddleware.uploadSingle("image")],VehicleController.add)
router.route("/:id")
.patch([auth(),multerMiddleware.uploadSingle("image")],VehicleController.update)
.delete(auth(),VehicleController.delete)
module.exports = router;
