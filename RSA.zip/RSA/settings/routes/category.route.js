const express = require("express");
const router = express.Router();
const { CategoryController} = require("../controllers");

router.route("/").get(CategoryController.getAllCategory);
router.route("/").post(CategoryController.addCategory)
router.route("/:id")
   .get(CategoryController.getCategory)
  .patch(CategoryController.updateCategory)
.delete(CategoryController.deleteCategory)
module.exports = router;
