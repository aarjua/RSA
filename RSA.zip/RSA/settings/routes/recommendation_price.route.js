const express = require("express");
const router = express.Router();
const { RecommendationPrice } = require("../controllers");

router.route('/price').post(RecommendationPrice.getRecommendationPrice)
router.route('/reverse_price_calculation').post(RecommendationPrice.reversePriceCalculation)
module.exports = router;
