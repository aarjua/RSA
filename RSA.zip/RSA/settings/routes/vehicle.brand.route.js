const express = require("express");
const router = express.Router();
const { VehicleBrandController} = require("../controllers");
const {
  multerMiddleware,
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");


router.route("/") .post([auth(),multerMiddleware.uploadSingle("image")],VehicleBrandController.add);
router.route("/:id") .patch([auth(),multerMiddleware.uploadSingle("image")],VehicleBrandController.update)
router.route("/") .get(VehicleBrandController.getAll);
router.route("/:id") .delete(auth(),VehicleBrandController.delete);

module.exports = router;
