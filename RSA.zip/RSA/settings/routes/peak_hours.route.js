const express = require("express");
const router = express.Router();
const peakHoursController = require("../controllers/peak_hours.controller");

router
  .route("/:countryId/:cityId?")
  .get(peakHoursController.getPeakHoursByCountryId)
  .post(peakHoursController.addPeakHoursByCountryId);
router
  .route("/:countryId/:cityId?/:peakHourId")
  .patch(peakHoursController.updatePeakHoursByCountryId);
router
  .route("/:peakHourId")
  .delete(peakHoursController.deletePeakHoursById);
module.exports = router;
