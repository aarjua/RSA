const {
    responseCodes,
    db: {
      Sequelize: { Op },
    },
  } = require("../config");
  const joi = require("joi");
  const {emailSettingDtos} = require("../dtos/email_settings.dtos");
  const { EmailSetting } = require("../models");
  
  const emailSettingsDtos = joi.object({
    enviroment: joi.string().required(),
    send_from: joi.string().required(),
    send_grid_key: joi.string().required(),
  });

  module.exports = {
    get: async (req, res) => {
      try {
        const emailSetting = await EmailSetting.findAll({});
        return res.status(200).json({
          data: emailSetting,
        });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    add: async (req, res) => {
      try {
        const { error, value } = emailSettingsDtos.validate(req.body);
        if (error) {
          console.error("error:", error);
          return res.status(400).json({
            code: responseCodes.ES.validations.invalidBody.code,
            description: error,
          });
        }
        
        await EmailSetting.create({...value});
        return res.status(201).json({ code: responseCodes.ES.created.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    update: async (req, res) => {
      try {
        const { error, value } = emailSettingsDtos.validate(req.body);
        if (error) {
          console.error("error:", error);
          return res.status(400).json({
            code: responseCodes.ES.validations.invalidBody.code,
            description: error,
          });
        }
        const emailSettingId = req.params.id;
        const emailSettingInfo = await EmailSetting.findOne({
          where: {
            id: emailSettingId,
          },
        });
        if (!emailSettingInfo) {
          return res.status(404).json({ code: responseCodes.UR.notFound.code });
        }
        await emailSettingInfo.update({
          ...emailSettingInfo,
          ...value,
        });
        return res.status(200).json({ code: responseCodes.ES.updated.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
  };
  