const {
  Sequelize: { Op },
} = require("../config/db.config");
const { Country } = require("../models");
const { responseCodes } = require("../config");

module.exports = {
  getAllCountry: async (req, res) => {
    try {
      const countryList = await Country.findAll({ order: [["name", "ASC"]] });
      if (!countryList) {
        return res
          .status(400)
          .json({ code: responseCodes.CN.invalidBody.code });
      }
      return res.status(200).json(countryList);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
