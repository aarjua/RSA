const {
  Sequelize: { Op },
} = require("../config/db.config");
const { VehicleType} = require("../models");
const { responseCodes } = require("../config");
const joi = require("joi");
const { s3 } = require("../services");
module.exports = {
  add: async (req, res) => {
    try {
          const value = await joi
        .object({
          type: joi.string().trim().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.VC.invalidBody.code });
        });
      
      const isAlreadyExist = await VehicleType.findOne({
        where: {
           type: { [Op.like] :'%' + value.type + '%' }},
      });

      if (isAlreadyExist) {
        return res
          .status(400)
          .json({ code: responseCodes.VC.alreadyExists.code });
      }
      console.log("api testing",value)
      await VehicleType.create(value);
      return res.status(201).json({ code: responseCodes.VC.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async  (req, res) => {
      
      let typeList = await VehicleType.findAll({
        attributes: ['id','type']
      })
      if(!typeList) {
        return res.status(400).json({ code: responseCodes.VC.notFound.code }); //need to change the status code
      }
      return res.status(200).json({data: typeList})
  },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      const value = await joi
        .object({
          type: joi.string().trim().optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.VC.invalidBody.code });
        });
      if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.VC.updated.code });
      }
      let data = {};
      const isAlreadyExist = await VehicleType.findOne({
          where:{
             type:{ [Op.like] : '%' + value.type + '%'},
          }
      })
      if (isAlreadyExist){
          return res.status(400).json({ code: responseCodes.VC.alreadyExists.code });
      }
      if (value.hasOwnProperty("type")) {
        data.type = value.type;
      }
      await VehicleType.update(data, { where: { id:id } });
      return res.status(200).json({ code: responseCodes.VC.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const answerName = await VehicleType.destroy({
        where: {
          id:id,
        },
      });
      if (answerName < 1) {
        return res.status(400).json({ code: responseCodes.VC.notFound.code }); //need to change the status code
      }
      return res.status(200).json({ code: responseCodes.VC.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
