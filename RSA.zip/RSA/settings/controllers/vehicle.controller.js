const {
  Sequelize: { Op }, 
} = require("../config/db.config");


const { Vehicle, VehicleType, VehicleModel } = require("../models");
const { responseCodes } = require("../config");
const joi = require("joi");
const { s3 } = require("../services");

module.exports = {
  add: async (req, res) => {
    try {
      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.image = url;
        console.log("url", url, req.body.image)
        //  file = await s3.uploadFileToS3(req.file);
      }
      const value = await joi
        .object({
          company_name: joi.string().trim().required(),
          image: joi.string().trim().required(),
          model: joi.string().trim().required(),
          type: joi.string().trim().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.IN.invalidBody.code });
        });

      const isAnswerAlreadyExist = await Vehicle.findOne({
        where: { company_name: value.company_name },
      });
      if (isAnswerAlreadyExist) {
        return res
          .status(400)
          .json({ code: responseCodes.IN.alreadyExists.code });
      }
      await Vehicle.create(value);
      return res.status(201).json({ code: responseCodes.IN.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      if (typeof req.query.ids === "string")
        req.query.ids = req.query.ids.split(",");
      const { ids } = await joi.object({
        ids: joi.array().items(joi.string().uuid())
      }).validateAsync(req.query);

      const where = {
        ...(Array.isArray(ids) && { id: { [Op.in]: ids } }),
      };
      let answerList = await Vehicle.findAll({
        attributes: ['id', 'company_name', 'image'],
        include: [
          {
            model: VehicleType,
            as: 'vehicletypes',
            through:{
              model:VehicleModel,
              as: 'vehiclemodels',
              attributes:['id', 'model','seat']},
            attributes: ['id', 'type'],
          },
        ],
        where,
      });
     
      if (!answerList) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
      }
 
      answerList = answerList.map(item => item.dataValues);
      return res.status(200).json({data: answerList});
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.image = url;
        console.log("url", url, req.body.image)
        //  file = await s3.uploadFileToS3(req.file);
      }
      const value = await joi
        .object({
          company_name: joi.string().trim().optional(),
          image: joi.string().trim().optional(),
          model: joi.string().trim().optional(),
          type: joi.string().trim().optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.IN.invalidBody.code });
        });
      if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.IN.updated.code });
      }
      let data = {};
      if (value.hasOwnProperty("company_name")) {
        data.company_name = value.company_name;
      }
      if(value.hasOwnProperty("model")){
        data.model = value.model
       }
       if(value.hasOwnProperty("type")){
        data.type = value.type
       }
      await Vehicle.update(data, { where: { id } });
      return res.status(200).json({ code: responseCodes.IN.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const answerName = await Vehicle.destroy({
        where: {
          id,
        },
      });
      if (answerName < 1) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
      }
      return res.status(200).json({ code: responseCodes.IN.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteVehicle: async (req, res) => {
    try {
      const { id } = req.params;
      const answerName = await VehicleModel.destroy({
        where: {
          id,
        },
      });
      if (answerName < 1) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
      }
      return res.status(200).json({ code: responseCodes.IN.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getVehicle: async (req , res) => {
    try {
       const { id } = req.params;
       const vehicle = await VehicleModel.findOne({
        where: { id: id},
        attributes: ['id','model','status','seat'],
      include: [
        {
          model: VehicleType,
          as: 'type',
          attributes: ['id', 'type'],
          include: [
            {
              model: Vehicle,
              as: 'vehicle',
              attributes: ['id', 'company_name', 'image'],
            },
          ],
        }
      ],
       });
       if (!vehicle) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
      }
 
      return res.status(200).json({data: vehicle});

    }  catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addVehicle: async (req ,res) => {
      try {
        if (req.file) {
          const { url } = await s3.uploadFileToS3(req.file);
          req.body.image = url;
          //  file = await s3.uploadFileToS3(req.file);
        }
        const value = await joi
          .object({
            company_name: joi.string().trim().required(),
            image: joi.string().trim().required(),
            model: joi.string().trim().required(),
            type: joi.string().trim().required(),
            seat: joi.number().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.IN.invalidBody.code });
          });
  
        const isModelAlreadyExist = await VehicleModel.findOne({
          where: { model: {
            [Op.like] :'%' + value.model + '%' }},
        });
        const isTypeAlreadyExist = await VehicleType.findOne({
          where: { type: {
            [Op.like] : '%' + value.type + '%' }},
        });
        const isCompanyAlreadyExist = await Vehicle.findOne({
          where: { company_name: { 
            [Op.like] : '%' + value.company_name + '%' }},
        })
        if(isModelAlreadyExist && isTypeAlreadyExist && isCompanyAlreadyExist){
          return res
            .status(400)
            .json({ code: responseCodes.IN.alreadyExists.code });
        }
        let savedVehicleData = await Vehicle.findOrCreate({
          where: { company_name:  value.company_name },
          defaults: { company_name : value.company_name, image: value.image},
        });
        let savedVehicleType = await VehicleType.findOrCreate({
           where: { type: value.type , vehicle_id: savedVehicleData[0].dataValues.id},
          defaults: { vehicle_id: savedVehicleData[0].dataValues.id, type: value.type},
        })
       
        let savedVehicleModel = await VehicleModel.findOrCreate({
          where: { model: value.model , vehicle_id: savedVehicleData[0].dataValues.id, vehicle_type_id: savedVehicleType[0].dataValues.id },
         defaults: {vehicle_id: savedVehicleData[0].dataValues.id, vehicle_type_id: savedVehicleType[0].dataValues.id 
          ,model: value.model , seat: value.seat },
       })
        return res.status(201).json({ code: responseCodes.IN.created.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
  },
  toggleVehicle: async (req ,res) => {
     try {
      let { id } = req.params;
       let vehicleStatus = await VehicleModel.findOne({
          where: { id: id },
          attributes: ['status']
      });
      if(vehicleStatus.dataValues.status == true){
        await VehicleModel.update(
          { status: false },
          {where: { id : id}, 
        })
      }
       else {
        await VehicleModel.update(
          { status: true },
          {where: { id : id}, 
        })
       } 
       let updatedStatus = await VehicleModel.findOne({
        where: { id: id },
        attributes: ['status']
    });
       return res.status(200).json({ code: responseCodes.IN.updated.code })
     } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateVehicle: async (req, res) => {
   try {
    const { id } = req.params;
    if (req.file) {
      const { url } = await s3.uploadFileToS3(req.file);
      req.body.image = url;
      //  file = await s3.uploadFileToS3(req.file);
    }
    const value = await joi
      .object({
        company_name: joi.string().trim().optional(),
        image: joi.string().trim().optional(),
        model: joi.string().trim().optional(),
        type: joi.string().trim().optional(),
        seat: joi.number().optional(),
      })
      .validateAsync(req.body)
      .catch((err) => {
        console.log("err:", err);
        return res
          .status(400)
          .json({ code: responseCodes.IN.invalidBody.code });
      });
    if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.IN.updated.code });
      }
    
    const data = await VehicleModel.findOne({
      where:{id :id},
      attributes:['vehicle_id','vehicle_type_id']
    })  
    
      let dataVehilcleModel = {};
      let dataVehilcleType= {};
      let dataVehilcle = {};
      if(Object.hasOwnProperty.bind(value)('model')){
        dataVehilcleModel.model = value.model;
        await VehicleModel.update( dataVehilcleModel, { where: { id:id }} )
      }
      if (Object.hasOwnProperty.bind(value)('seat')) {
        dataVehilcleType.seat = value.seat;
          await VehicleType.update( dataVehilcleModel, { where: { id:id }} )
      }
       if (Object.hasOwnProperty.bind(value)('type')) {
        dataVehilcleType.type = value.type;
        let updatedVehicleType = await VehicleType.update( dataVehilcleType, { where: { id:data.dataValues.vehicle_type_id, vehicle_id:data.dataValues.vehicle_id}} )
      }
      if (Object.hasOwnProperty.bind(value)('seat')) {
        dataVehilcleType.seat = value.seat;
        let updatedVehicleModel = await VehicleType.update( dataVehilcleType, { where: { id:data.dataValues.vehicle_type_id, vehicle_id:data.dataValues.vehicle_id}} )
      }

      if (Object.hasOwnProperty.bind(value)('company_name')) {
        dataVehilcle.company_name = value.company_name;
        let updatedVehicle = await Vehicle.findOrCreate({
          where: { company_name:  value.company_name },
          defaults: { company_name : value.company_name, image: value.image},
        });
        
        
        
        ( dataVehilcle, { where: { id:data.dataValues.vehicle_id}} )

      }
      if (Object.hasOwnProperty.bind(value)('image')) {
        dataVehilcle.image = value.image;
        let updatedVehicle = await Vehicle.update( dataVehilcle, { where: { id:data.dataValues.vehicle_id}} )
      }
      return res.status(200).json({ code: responseCodes.IN.updated.code });
   }
   catch (err) {
    console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
   }
  },
  getVehicleList: async (req, res) => {
    try {
     
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;
      const offset = (page - 1) * perPage;
  
      const sortBy = req.query.sortBy
      const orderBy =req.query.orderBy
      const searchString = req.query.search;
      const companyNameFilter = req.query.company_name;
      const typeNameFilter = req.query.type;
      const statusFilter = req.query.status;

      let list;
  
      const whereCondition = {};
      if (searchString!== undefined ) {
        whereCondition[Op.or] = [
          {
            '$type.type$': {
              [Op.like]: `%${searchString}%`,
            },
          },
          {
            '$type.vehicle.company_name$': {
              [Op.like]: `%${searchString}%`,
            },
          },
          {
            ['$model$']: {
              [Op.like]: `%${searchString}%`,
            },
          },
        ];
        
      }
     
      if (companyNameFilter) {
        whereCondition['$type.vehicle.company_name$'] = companyNameFilter;
      }
      if (typeNameFilter) {
        whereCondition['$type.type$'] = typeNameFilter;
      }
      if (statusFilter !== undefined) {
        whereCondition.status = statusFilter === 'true' ? true : false;
      }
      let orderByCond = [["model",'ASC']];
      if (sortBy && orderBy) { 
       if (sortBy === "model") {
          orderByCond = [["model", orderBy]];
        }
        else if(sortBy === "type"){
        orderByCond  =[[{ model:VehicleType, as: "type" }, sortBy, orderBy]];
      }
      else if(sortBy === "company_name"){
        orderByCond  =[[{ model: VehicleType.Vehicle, as: "vehicle" }, sortBy, orderBy]];
      } 
      }
      list = await VehicleModel.findAll({
        attributes: ['id', 'model', 'status','seat'],
        include: [
          {
            model: VehicleType,
            as: 'type',
            attributes: ['id', 'type'],
            include: [
              {
                model: Vehicle,
                as: 'vehicle',
                attributes: ['id', 'company_name', 'image'],
              },
            ],
          },
        ],
        where: whereCondition,
        offset,
        limit: perPage,
        order:orderByCond
      });
  
      if (!list) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code });
      }
      const totalRecordsCount = await VehicleModel.count({
        include: [
          {
            model: VehicleType,
            as: 'type',
            attributes: [],
            include: [
              {
                model: Vehicle,
                as: 'vehicle',
                attributes: [],
              },
            ],
          },
        ],
        where: whereCondition,
      });
      
  
      return res.status(200).json({ data: list, totalCount: totalRecordsCount });
    
  } catch (err) {
      console.error("err:", err);
      return res.status(500).json({ code: responseCodes.SE.internalError.code });
    }
  },    
};
