const {
    Sequelize: { Op },
  } = require("../config/db.config");
  const { Country,Category } = require("../models");
  const { responseCodes } = require("../config");
  const joi = require("joi");
  module.exports = {
    getAllCategory: async (req, res) => {
        try {
          const query = await joi
          .object({
            search: joi.string(),
            limit: joi.number(),
            page: joi.number(),
            sortBy: joi
            .string()
            .valid(...Object.keys(Category.rawAttributes),"category.name")
            .default("created_at"),
            orderBy: joi.string().valid("ASC","DESC").default("DESC"),
          })
            .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.CA.invalidQuery.code });
            
          })
          if (!query) return;
          const {
            search,
            limit,
            page,
            sortBy = "created_at",
            orderBy = "ASC",
          } = query;
         const where = {
          [Op.and]: [search ? { name: { [Op.like]: `%${search}%` } } : {}],
         };
          const [data, count] = await Promise.all([
            Category.findAll({
              where,
              order: [
                sortBy === "category.name"
                  ? ["category", "name", orderBy]
                  : [sortBy, orderBy],
              ],
              ...(limit && page && { limit: parseInt(limit) }),
              ...(limit &&
                page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
              }),
                Category.count({ where }),
          ])
          return res.status(200).json({ data, count });
           
        } catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }
      },
      getCategory: async (req,res) => {
      try{
       const { id:categoryId } = req.params;
       const isCategoryExist = await Category.findOne({
        where:{id:categoryId}
       })
       if(!isCategoryExist){
        return res.status(400).json({ code: responseCodes.CA.validations.categoryNotFound.code })
       }
       return  res.status(200).json(isCategoryExist);

      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
      },

      deleteCategory: async (req, res) => {
        try {
          const { id:categoryId } = req.params
          const categoryList = await Category.destroy({
            where:{
                id: categoryId
            }
          });
           if(categoryList < 1){
              return res.status(400).json({ code: responseCodes.CA.notFound.code }); //need to change the status code
           }
          return res.status(200).json({ code: responseCodes.CA.deleted.code});
        } catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }
      },
     addCategory:  async (req, res) => {
      try{
        const value = await joi.object({
            name: joi.string().trim().required(),
        }).validateAsync(req.body).catch(err => {
            console.log('err:',err)
            return res.status(400).json({ code: responseCodes.CA.invalidBody.code }); 
        })
        const categoryAlreadyExist = await Category.findOne({
          where:{name:value.name}
        })         
        if(categoryAlreadyExist){
          return  res.status(400).json({ code: responseCodes.CA.categoryAlreadyExist.code })
        }
         await Category.create(value);
         return res.status(201).json({ code: responseCodes.CA.created.code });
      }  catch(err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    updateCategory: async (req, res) => {
      try{
        const { id:categoryId } =req.params;
       const value = await joi.object({
        name: joi.string().trim().optional(),
        status:joi.boolean().optional(),
       }).validateAsync(req.body).catch(err => {
         console.log('err:', err)
         return res.status(400).json({ code: responseCodes.CA.invalidBody.code });
       })
       if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.CA.updated.code });
    }     
      const category = await Category .findOne({where: {id:categoryId},attributes:["id"]})
      if(!category){
        return res.status(404).json({ code: responseCodes.CA.notFound.code });
      }
        let data = {}
          if(value.hasOwnProperty("name")){
            const categoryAlreadyExist = await Category.count({
              where:{
                id:{[Op.ne]:categoryId},
                name:value.name
              }
             })
            if(categoryAlreadyExist){
              return  res.status(400).json({ code: responseCodes.CA.categoryAlreadyExist.code })
            }
            data.name = value.name
          }
          if(value.hasOwnProperty("status")){
            data.status = value.status
          }

        await Category.update(
          data,
          {where:{id:categoryId}}
        )
        return res.status(200).json({ code: responseCodes.CA.updated.code })
      }
      catch(err){
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    }
  };
  