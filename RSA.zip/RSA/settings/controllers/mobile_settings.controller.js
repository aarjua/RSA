const {
  responseCodes,
  db: {
    Sequelize: { Op },
  },
} = require("../config");
const {
  mobileSettingsDtos,
  mobileSettingsPaginationDtos,
} = require("../dtos/mobile_settings.dtos");
const { MobileSettings, PeakHours, RateDistances } = require("../models");
const { validateParamsId } = require("../utils/mobile_settings");

const rateForDistancesByCountryOrCity = async (countryId, cityId) => {
  const rateForDistancesInfo = await RateDistances.findAll({
    where: {
      ...(cityId
        ? {
            city_id: cityId,
            country_id: countryId,
          }
        : { country_id: countryId }),
    },
  });
  return rateForDistancesInfo.map((rateDistances) => rateDistances?.id);
};

const peakHourByCountryOrCity = async (countryId, cityId) => {
  const peakHourInfo = await PeakHours.findAll({
    where: {
      ...(cityId
        ? {
            city_id: cityId,
            country_id: countryId,
          }
        : { country_id: countryId }),
    },
  });
  return peakHourInfo.map((peakHour) => peakHour?.id);
};

module.exports = {
  getMobileSettingsById: async (req, res) => {
    try {
      try {
        await validateParamsId(req);
      } catch (err) {
        console.log(err);
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      const mobileSettingId = req.params.id;
      const mobileSettingInfo = await MobileSettings.findOne({
        where: {
          id: mobileSettingId,
        },
        include: [
          {
            association: "city",
            attributes: ["id", "name"],
          },
          {
            association: "country",
            attributes: ["id", "name", "currency_name"],
          },
        ],
      });
      return res.status(200).json({
        data: {
          ...mobileSettingInfo.dataValues,
        },
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getMobileSettingsListing: async (req, res) => {
    try {
      const { limit, page, search, country_id, city_id, is_active } =
        await mobileSettingsPaginationDtos.validateAsync(req.query);
      let mobileSettingInfo;
      let mobileSettingFilteredCount;
      if (search) {
        mobileSettingInfo = await MobileSettings.findAll({
          where: {
            [Op.or]: {
              "$city.name$": {
                [Op.like]: `%${search}%`,
              },
              "$country.name$": {
                [Op.like]: `%${search}%`,
              },
            },
          },
          include: [
            {
              association: "city",
              attributes: ["id", "name"],
            },
            {
              association: "country",
              attributes: ["id", "name", "currency_name"],
            },
          ],
          raw: true,
          nest: true,
          limit: limit,
          offset: (page - 1) * limit,
        });
      } else if (country_id && city_id) {
        if (is_active) {
          mobileSettingInfo = await MobileSettings.findAll({
            where: {
              country_id: country_id,
              city_id: city_id,
              is_active: is_active === "true",
            },
            include: [
              {
                association: "city",
                attributes: ["id", "name"],
              },
              {
                association: "country",
                attributes: ["id", "name", "currency_name"],
              },
            ],
            raw: true,
            nest: true,
            limit: limit,
            offset: (page - 1) * limit,
          });
          mobileSettingFilteredCount = await MobileSettings.count({
            where: {
              country_id: country_id,
              city_id: city_id,
              is_active: is_active === "true",
            },
          });
        } else {
          mobileSettingInfo = await MobileSettings.findAll({
            where: {
              country_id: country_id,
              city_id: city_id,
            },
            include: [
              {
                association: "city",
                attributes: ["id", "name"],
              },
              {
                association: "country",
                attributes: ["id", "name", "currency_name"],
              },
            ],
            raw: true,
            nest: true,
            limit: limit,
            offset: (page - 1) * limit,
          });
          mobileSettingFilteredCount = await MobileSettings.count({
            where: { country_id: country_id, city_id: city_id },
          });
        }
      } else {
        mobileSettingInfo = await MobileSettings.findAll({
          include: [
            {
              association: "city",
              attributes: ["id", "name"],
            },
            {
              association: "country",
              attributes: ["id", "name", "currency_name"],
            },
          ],
          raw: true,
          nest: true,
          limit: limit,
          offset: (page - 1) * limit,
        });
      }
      const mobileSettings = [];
      for (let i = 0; i < mobileSettingInfo.length; i++) {
        delete mobileSettingInfo[i].city_id;
        delete mobileSettingInfo[i].country_id;
        mobileSettings.push({
          ...mobileSettingInfo[i],
          city: mobileSettingInfo[i].city.name,
          country: mobileSettingInfo[i].country.name,
          currency_name: mobileSettingInfo[i].country.currency_name,
        });
      }
      return res.status(200).json({
        data: mobileSettings,
        count: search
          ? mobileSettingInfo.length
          : country_id || city_id || is_active
          ? mobileSettingFilteredCount
          : await MobileSettings.count(),
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addMobileSettings: async (req, res) => {
    try {
      const { error, value } = mobileSettingsDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.PC.invalidBody.code,
          description: error,
        });
      }
      if (value.city_id) {
        const mobileSettingInfo = await MobileSettings.findOne({
          where: { city_id: value.city_id },
        });

        if (mobileSettingInfo) {
          await mobileSettingInfo.update({
            ...mobileSettingInfo.dataValues,
            is_active: false,
            end_date: new Date(),
          });
        }
      }
      await MobileSettings.create({
        ...value,
        start_date: new Date(),
        is_active: true,
      });
      return res.status(201).json({ code: responseCodes.PC.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateMobileSettings: async (req, res) => {
    try {
      const { error, value } = mobileSettingsDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.PC.invalidBody.code,
          description: error,
        });
      }
      const mobileSettingId = req.params.id;
      const mobileSettingInfo = await MobileSettings.findOne({
        where: {
          id: mobileSettingId,
        },
      });
      if (!mobileSettingInfo) {
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      await mobileSettingInfo.update({
        ...mobileSettingInfo,
        ...value,
      });
      return res.status(200).json({ code: responseCodes.PC.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleStatus: async (req, res) => {
    try {
      try {
        await validateParamsId(req);
      } catch (err) {
        console.log(err);
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      const mobileSettingId = req.params.id;
      const mobileSettingInfo = await MobileSettings.findOne({
        where: {
          id: mobileSettingId,
        },
      });
      if (!mobileSettingInfo) {
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      if (mobileSettingInfo.dataValues.is_active) {
        await mobileSettingInfo.update({
          ...mobileSettingInfo.dataValues,
          is_active: false,
          end_date: new Date(),
        });
      } else {
        await mobileSettingInfo.update({
          ...mobileSettingInfo.dataValues,
          is_active: true,
          end_date: null,
        });
      }
      return res.status(200).json({ code: responseCodes.PC.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteMobileSettings: async (req, res) => {
    try {
      try {
        await validateParamsId(req);
      } catch (err) {
        console.log(err);
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      const mobileSettingId = req.params.id;
      const mobileSettingInfo = await MobileSettings.findOne({
        where: {
          id: mobileSettingId,
        },
      });
      if (!mobileSettingInfo) {
        return res
          .status(400)
          .json({ code: responseCodes.PC.invalidBody.code });
      }
      const rateForDistancesInfo = await rateForDistancesByCountryOrCity(
        mobileSettingInfo?.dataValues?.country_id,
        mobileSettingInfo?.dataValues?.city_id
      );
      const peakHoursInfo = await peakHourByCountryOrCity(
        mobileSettingInfo?.dataValues?.country_id,
        mobileSettingInfo?.dataValues?.city_id
      );
      await RateDistances.destroy({ where: { id: rateForDistancesInfo } });
      await PeakHours.destroy({ where: { id: peakHoursInfo } });
      await MobileSettings.destroy({
        where: {
          id: mobileSettingInfo.dataValues.id,
        },
      });
      return res.status(200).json({
        code: responseCodes.PC.deleted.code,
        message: responseCodes.PC.deleted.message,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
