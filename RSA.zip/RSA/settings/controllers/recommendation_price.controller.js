const {
  responseCodes,
  db: {
    Sequelize: { Op },
  },
} = require("../config");
const {
  getRecommendationPriceDtos,
  reversePriceCalculationDtos,
} = require("../dtos/mobile_settings.dtos");
const {
  Cities,
  MobileSettings,
  RateDistances,
  PeakHours,
  Country,
} = require("../models");
const {
  priceCalculation,
  getTaxAmountCal,
} = require("../utils/mobile_settings");
const moment = require("moment");

const getMobileSettingByCityOrCountryId = async (countryId, cityId) => {
  let mobileSettingsInfo = await MobileSettings.findOne({
    where: {
      ...(cityId
        ? {
            city_id: cityId,
            country_id: countryId,
          }
        : { country_id: countryId }),
      is_active: true,
    },
  });
  if (!mobileSettingsInfo) {
    mobileSettingsInfo = await MobileSettings.findOne({
      where: {
        country_id: countryId,
        is_active: true,
      },
    });
    if (!mobileSettingsInfo) {
      return res.status(404).json({
        code: responseCodes.PC.notFound.code,
        message: responseCodes.PC.notFound.message,
      });
    }
  }
  return mobileSettingsInfo;
};

const cityByName = async (name) => {
  return await Cities.findOne({
    where: {
      [Op.and]: {
        name: {
          [Op.like]: name,
        },
      },
    },
  });
};

const countryByName = async (name) => {
  return await Country.findOne({
    where: {
      [Op.and]: {
        name: {
          [Op.like]: name,
        },
      },
    },
  });
};

const rateDistancesByCountryOrCity = async (countryId, cityId) => {
  let rateForDistancesInfo = await RateDistances.findAll({
    where: {
      ...(cityId
        ? {
            city_id: cityId,
            country_id: countryId,
          }
        : { country_id: countryId, city_id: null }),
    },
  });
  if (rateForDistancesInfo.length === 0) {
    rateForDistancesInfo = await RateDistances.findAll({
      where: {
        country_id: countryId,
        city_id: null,
      },
    });
    if (!rateForDistancesInfo.length === 0) {
      return [];
    }
  }
  return rateForDistancesInfo;
};

const peakHourByCountryOrCity = async (countryId, cityId) => {
  let peakHourInfo = await PeakHours.findAll({
    where: {
      ...(cityId
        ? {
            city_id: cityId,
            country_id: countryId,
          }
        : { country_id: countryId }),
    },
  });
  if (peakHourInfo.length === 0) {
    peakHourInfo = await PeakHours.findAll({
      where: {
        country_id: countryId,
        city_id: null,
      },
    });

    if (!peakHourInfo.length === 0) {
      return [];
    }
  }
  return peakHourInfo;
};

const rateForDistancesCalculations = async (
  rateDistancesInfo,
  totalDistance
) => {
  let totalRateForDistances = 0;
  let largestRateDistancesTo = 0;
  let largestRateDistancesRate = 0;
  if (rateDistancesInfo.length > 0) {
    rateDistancesInfo?.forEach((rateDistances) => {
      largestRateDistancesTo = Math.max(
        +rateDistances.dataValues.to,
        largestRateDistancesTo
      );
      if (largestRateDistancesTo === +rateDistances.dataValues.to) {
        largestRateDistancesRate = +rateDistances.dataValues.rate;
      }
      if (+rateDistances.dataValues.to <= totalDistance) {
        totalRateForDistances +=
          +rateDistances.dataValues.to * +(+rateDistances.dataValues.rate);
        totalDistance -= +rateDistances.dataValues.to;
      }
    });
    totalRateForDistances += totalDistance * largestRateDistancesRate;
    return totalRateForDistances;
  } else {
    return totalDistance;
  }
};

const peakHourCalculations = (peakHourInfo, startTime) => {
  const hourMins = moment(startTime).format("HH:mm");
  let totalPeakHourRate = 0;
  if (peakHourInfo.length > 0) {
    peakHourInfo?.forEach((peakHour) => {
      const isPeakHourInRange = moment(hourMins, "HH:mm").isBetween(
        moment(peakHour.from, "HH:mm"),
        moment(peakHour.to, "HH:mm")
      );
      if (isPeakHourInRange) {
        totalPeakHourRate += +peakHour.rate;
      } else {
        totalPeakHourRate += 0;
      }
    });
    return totalPeakHourRate;
  }
  return 0;
};
module.exports = {
  getRecommendationPrice: async (req, res) => {
    try {
      const { error, value } = getRecommendationPriceDtos.validate(req.body);
      if (error) {
        console.log("error:", error);
        return res.status(400).json({
          code: responseCodes.PC.invalidBody.code,
          description: error,
        });
      }
      const cityInfo = await cityByName(value.start_city_name);
      const countryInfo = await countryByName(value.country);

      let mobileSettingsInfo = await getMobileSettingByCityOrCountryId(
        countryInfo?.dataValues?.id,
        cityInfo?.dataValues?.id
      );

      const rateDistancesInfo = await rateDistancesByCountryOrCity(
        countryInfo?.dataValues?.id,
        cityInfo?.dataValues?.id
      );
      const peakHourInfo = await peakHourByCountryOrCity(
        countryInfo?.dataValues?.id,
        cityInfo?.dataValues?.id
      );

      const totalRateForDistances = await rateForDistancesCalculations(
        rateDistancesInfo,
        value.distance
      );

      const totalPeakHourRate = peakHourCalculations(
        peakHourInfo,
        value.start_time
      );

      const { base_fare, wait_charges, tax_amount, is_tax_percentage } =
        mobileSettingsInfo.dataValues;
      const total_suggested_price = priceCalculation(
        +base_fare,
        totalRateForDistances,
        totalPeakHourRate,
        value.total_stop_over,
        +wait_charges,
        0,
        0,
        +tax_amount,
        is_tax_percentage
      );
      return res.status(200).json({
        data: {
          total_suggested_price: +total_suggested_price.toFixed(2),
          price_master_id: mobileSettingsInfo.dataValues.id,
        },
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  reversePriceCalculation: async (req, res) => {
    try {
      const { error, value } = reversePriceCalculationDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.PC.invalidBody.code,
          description: error,
        });
      }
      const priceInfo = await MobileSettings.findByPk(value.price_master_id);
      if (!priceInfo) {
        return res.status(404).json({
          code: responseCodes.PC.notFound.code,
          message: responseCodes.PC.invalidBody.message,
        });
      }
      const {
        base_fare,
        wait_charges,
        tax_amount,
        is_tax_percentage,
        country_id,
      } = priceInfo.dataValues;

      const countryInfo = await Country.findByPk(country_id);

      const taxAmount = getTaxAmountCal(
        value.total_amount,
        tax_amount,
        is_tax_percentage
      );
      const baseFare = value.total_amount - taxAmount - +wait_charges;
      const totalFare = baseFare - base_fare;
      const reverseCalculations = {
        base_fare: +baseFare.toFixed(2),
        wait_charges: +wait_charges,
        is_tax_percentage: is_tax_percentage,
        tax_amount: taxAmount,
        currency: countryInfo.dataValues.currency_name,
        total_fare: totalFare,
      };
      return res.status(200).json({
        data: reverseCalculations,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
