const {
    Sequelize: { Op },
  } = require("../config/db.config");
  const { VehicleFuel } = require("../models");
  const { responseCodes } = require("../config");
  const joi = require("joi");
  module.exports = {
    add: async (req, res) => {
      try {
        const value = await joi
          .object({
            name: joi.string().trim().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.IN.invalidBody.code });
          });
  
        const isAnswerAlreadyExist = await VehicleFuel.findOne({
          where: { name: value.name },
        });
        if (isAnswerAlreadyExist) {
          return res
            .status(400)
            .json({ code: responseCodes.IN.alreadyExists.code });
        }
        await VehicleFuel.create(value);
        return res.status(201).json({ code: responseCodes.IN.created.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    getAll: async (req, res) => {
      try {
        if (typeof req.query.ids === "string")
          req.query.ids = req.query.ids.split(",");
        const { ids } = await joi.object({
          ids: joi.array().items(joi.string().uuid())
        }).validateAsync(req.query);
  
        const where = {
          ...(Array.isArray(ids) && { id: { [Op.in]: ids } }),
        };
        let answerList = await VehicleFuel.findAll({
          where
        });
        if (!answerList) {
          return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
        }
        answerList = answerList.map(item => item.dataValues);
        return res.status(200).json({data: answerList});
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    update: async (req, res) => {
      try {
        const { id } = req.params;
        const value = await joi
          .object({
            name: joi.string().trim().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.IN.invalidBody.code });
          });
        if (!Object.keys(value).length) {
          //INFO: If there is nothing to update send success response.
          return res.json({ code: responseCodes.IN.updated.code });
        }
        let data = {};
        if (value.hasOwnProperty("name")) {
          data.name = value.name;
        }
        await VehicleFuel.update(data, { where: { id } });
        return res.status(200).json({ code: responseCodes.IN.updated.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    delete: async (req, res) => {
      try {
        const { id } = req.params;
        const answerName = await VehicleFuel.destroy({
          where: {
            id,
          },
        });
        if (answerName < 1) {
          return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
        }
        return res.status(200).json({ code: responseCodes.IN.deleted.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
  };
  