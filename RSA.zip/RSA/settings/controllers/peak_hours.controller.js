const { PeakHours } = require("../models");
const { responseCodes } = require("../config");
const {
  rateDistancesPeakHourDtos,
} = require("../dtos/rate_distances_peak_hour.dtos");

module.exports = {
  getPeakHoursByCountryId: async (req, res) => {
    try {
      const { countryId, cityId } = req.params;
      const peakHoursByCountry = await PeakHours.findAll({
        where: {
          ...(cityId
            ? {
                city_id: cityId,
                country_id: countryId,
              }
            : { country_id: countryId, city_id: null }),
        },
        raw: true,
      });
      if (!peakHoursByCountry) {
        return res
          .status(400)
          .json({ code: responseCodes.PH.invalidBody.code });
      }
      return res.status(200).json(peakHoursByCountry);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addPeakHoursByCountryId: async (req, res) => {
    const { countryId, cityId } = req.params;
    if (!countryId)
      return res.status(400).json({
        code: responseCodes.PH.invalidBody.code,
        message: responseCodes.PH.invalidBody.message,
      });
    const { error, value } = rateDistancesPeakHourDtos.validate(req.body);
    if (error) {
      console.error("error:", error);
      return res.status(400).json({
        code: responseCodes.PH.invalidBody.code,
        description: error,
      });
    }
    await PeakHours.create({
      ...value,
      country_id: countryId,
      city_id: cityId,
    });
    return res.status(201).json({ code: responseCodes.PH.created.code });
  },
  updatePeakHoursByCountryId: async (req, res) => {
    try {
      const { countryId, cityId, peakHourId } = req.params;
      if (!countryId || !peakHourId)
        return res.status(400).json({
          code: responseCodes.PH.invalidBody.code,
          message: responseCodes.PH.invalidBody.message,
        });
      const { error, value } = rateDistancesPeakHourDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.PH.invalidBody.code,
          description: error,
        });
      }

      const peakHoursInfo = await PeakHours.findOne({
        where: { id: peakHourId },
      });
      if (!peakHoursInfo) {
        return res.status(404).json({ code: responseCodes.PH.notFound.code });
      }

      const requestBody = { ...value, country_id: countryId, city_id: cityId };
      await peakHoursInfo.update(requestBody);
      return res.status(201).json({
        code: responseCodes.PH.updated.code,
        message: responseCodes.PH.updated.message,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deletePeakHoursById: async (req, res) => {
    try {
      const { peakHourId } = req.params;
      if (!peakHourId)
        return res.status(400).json({
          code: responseCodes.PH.invalidBody.code,
          message: responseCodes.PH.invalidBody.message,
        });

      const peakHoursInfo = await PeakHours.destroy({
        where: {
          id: peakHourId,
        },
      });
      if (!peakHoursInfo)
        return res
          .status(400)
          .json({ code: responseCodes.PH.invalidBody.code });

      return res.status(200).json({
        code: responseCodes.PH.deleted.code,
        message: responseCodes.PH.deleted.message,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
