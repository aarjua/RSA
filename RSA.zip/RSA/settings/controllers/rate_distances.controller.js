const { responseCodes } = require("../config");
const { RateDistances } = require("../models");
const {
  rateDistancesPeakHourDtos,
} = require("../dtos/rate_distances_peak_hour.dtos");
module.exports = {
  getRateDistancesByCountryId: async (req, res) => {
    try {
      const { countryId, cityId } = req.params;
      const rateDistancesByCountry = await RateDistances.findAll({
        where: {
          ...(cityId
            ? {
                city_id: cityId,
                country_id: countryId,
              }
            : { country_id: countryId, city_id: null }),
        },
        raw: true,
      });
      if (!rateDistancesByCountry) {
        return res
          .status(400)
          .json({ code: responseCodes.RD.invalidBody.code });
      }
      return res.status(200).json(rateDistancesByCountry);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addRateDistancesByCountryId: async (req, res) => {
    const { countryId, cityId } = req.params;
    if (!countryId)
      return res.status(400).json({
        code: responseCodes.RD.invalidBody.code,
        message: responseCodes.RD.invalidBody.code,
      });
    const { error, value } = rateDistancesPeakHourDtos.validate(req.body);
    if (error) {
      console.error("error:", error);
      return res.status(400).json({
        code: responseCodes.RD.invalidBody.code,
        description: error,
      });
    }
    await RateDistances.create({
      ...value,
      country_id: countryId,
      city_id: cityId,
    });
    return res.status(201).json({ code: responseCodes.RD.created.code });
  },
  updateRateDistancesByCountryId: async (req, res) => {
    try {
      const { countryId, rateDistanceId, cityId } = req.params;
      if (!countryId || !rateDistanceId)
        return res.status(400).json({
          code: responseCodes.RD.invalidBody.code,
          message: responseCodes.RD.invalidBody.code,
        });
      const { error, value } = rateDistancesPeakHourDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RD.invalidBody.code,
          description: error,
        });
      }

      const rateDistancesInfo = await RateDistances.findOne({
        where: {
          id: rateDistanceId,
          country_id: countryId,
          city_id: cityId ? cityId : null,
        },
      });
      if (!rateDistancesInfo) {
        return res
          .status(404)
          .json({ code: responseCodes.RD.invalidBody.code });
      }

      const requestBody = {
        ...value,
        country_id: countryId,
        city_id: cityId ? cityId : null,
      };
      await rateDistancesInfo.update(requestBody);
      return res.status(201).json({
        code: responseCodes.RD.updated.code,
        message: responseCodes.RD.updated.message,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteRateDistancesById: async (req, res) => {
    try {
      const { rateDistanceId } = req.params;
      if (!rateDistanceId)
        return res.status(400).json({
          code: responseCodes.RD.invalidBody.code,
          message: responseCodes.RD.invalidBody.code,
        });

      const rateDistancesInfo = await RateDistances.destroy({
        where: {
          id: rateDistanceId,
        },
      });
      if (!rateDistancesInfo)
        return res
          .status(400)
          .json({ code: responseCodes.RD.invalidBody.code });

      return res.status(200).json({
        code: responseCodes.RD.deleted.code,
        message: responseCodes.RD.deleted.message,
      });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
