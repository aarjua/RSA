const { Cities } = require("../models");
const { responseCodes } = require("../config");

module.exports = {
  getCitiesById: async (req, res) => {
    try {
      const { countryId } = req.params;
      const citiesByCountry = await Cities.findAll({
        where: {
          country_id: countryId,
        },
        order: [["name", "ASC"]],
        raw: true,
      });
      if (!citiesByCountry) {
        return res
          .status(400)
          .json({ code: responseCodes.CI.invalidBody.code });
      }
      return res.status(200).json(citiesByCountry);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
