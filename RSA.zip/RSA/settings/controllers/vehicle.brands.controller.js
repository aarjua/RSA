const {
  Sequelize: { Op },
} = require("../config/db.config");
const { Vehicle } = require("../models");
const { responseCodes } = require("../config");
const joi = require("joi");
const { s3 } = require("../services");
module.exports = {
  add: async (req, res) => {
    try {
    
      if (req.file){
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.image = url; 
    }
          const value = await joi
        .object({
          company_name: joi.string().required(),
          image: joi.string().trim().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.VC.invalidBody.code });
        });
      
      const isAlreadyExist = await Vehicle.findOne({
        where: { company_name:{ [Op.like]: '%' + value.company_name + '%' }},
      });
     
      if (isAlreadyExist) {
        return res
          .status(400)
          .json({ code: responseCodes.VC.alreadyExists.code });
      }
     
      await Vehicle.create(value);
      return res.status(201).json({ code: responseCodes.VC.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
      let brandList = await Vehicle.findAll({
        attributes: ['id', 'company_name','image'],
      })
      if(!brandList) {
        return res.status(400).json({ code: responseCodes.VC.notFound.code }); //need to change the status code
      }
      return res.status(200).json({data: brandList})
    },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      if (req.file){
          const { url } = await s3.uploadFileToS3(req.file);
          req.body.image = url; 
      }
      const value = await joi
        .object({
          company_name: joi.string().trim().optional(),
          image: joi.string().trim().optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.VC.invalidBody.code });
        });
      if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.VC.updated.code });
      }
      let data = {};
      if (Object.hasOwnProperty.bind(value)('company_name')) {
          const isAlreadyExist = await Vehicle.findOne({
              where: {company_name:{ 
                  [Op.like] : '%' + value.company_name + '%' }}
          })
          if(isAlreadyExist){
              return res.status(400).json({ code: responseCodes.VC.alreadyExists.code });
          }
        data.company_name = value.company_name;
      }
      if (Object.hasOwnProperty.bind(value)('image')) {
        data.image = value.image;
      }
      await Vehicle.update(data, { where: { id } });
      return res.status(200).json({ code: responseCodes.VC.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const answerName = await Vehicle.destroy({
        where: {
          id,
        },
      });
      if (answerName < 1) {
        return res.status(400).json({ code: responseCodes.VC.notFound.code }); //need to change the status code
      }
      return res.status(200).json({ code: responseCodes.VC.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
