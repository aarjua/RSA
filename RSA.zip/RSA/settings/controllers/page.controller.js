const {
    Sequelize: { Op },
  } = require("../config/db.config");
  const { Page } = require("../models");
  const { responseCodes } = require("../config");
  const joi = require("joi");
  module.exports = {
    get: async (req, res) => {
        try {
        const {type:pageType} =req.params
          const pages = await Page.findOne({
            where:{type:pageType}
          });
           if(!pages){
              return res.status(200).json("")
           }
          return res.status(200).json(pages);
        } catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }
      },   
      add:  async (req, res) => {
        try{
           const value = await joi.object({
           title: joi.string().trim().required(),
           description: joi.string().trim().required(),
           type: joi.string().trim().required(),
           }).validateAsync(req.body).catch(err => {
            console.log('err:',err)
            return res.status(400).json({ code: responseCodes.PG.invalidBody.code }); 
        })
        
         const isTypeAlreadyExist = await Page.findOne({
          where:{type:value.type}
         })
         if ( isTypeAlreadyExist ) {
          return res.status(400).json({ code: responseCodes.PG.alreadyExists.code });
         }
        await Page.create(value)
        return res.status(201).json({ code: responseCodes.PG.created.code });
        } catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }

      },
      update : async (req, res) => {
        try{
           const { id :typeId } =req.params;
           const value =  await joi.object({
            title: joi.string().trim().optional(),
            description:  joi.string().optional(),
            type: joi.boolean().optional(),
           }).validateAsync(req.body).catch(err => {
             console.log('err:', err)
             return res.status(400).json({ code: responseCodes.PG.invalidBody.code });
           })
           if (!Object.keys(value).length) {
            //INFO: If there is nothing to update send success response.
            return res.json({ code: responseCodes.PG.updated.code });
        }   
        let data = {};
        if(value.hasOwnProperty("title") ){
          data.title = value.title
        }
         if(value.hasOwnProperty("description")){
          data.description = value.description
         }
         if(value.hasOwnProperty("type")){
          data.type = value.type
         }
         await Page.update(
          data,
          {where:{id:typeId}}
        )
        return res.status(200).json({ code: responseCodes.PG.updated.code })
        }  catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }
      },
      delete:  async (req, res) => {
        try {
          const { id:typeId } = req.params
          const pageType = await Page.destroy({
            where:{
                id: typeId
            }
          });
           if(pageType < 1){
              return res.status(400).json({ code: responseCodes.PG.notFound.code }); //need to change the status code
           }
          return res.status(200).json({ code: responseCodes.PG.deleted.code});
        } catch (err) {
          console.error("err:", err);
          return res
            .status(500)
            .json({ code: responseCodes.SE.internalError.code });
        }
      },

  };
  