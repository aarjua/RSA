const {
    Sequelize: { Op },
  } = require("../config/db.config");
  const { VehicleType ,Vehicle, VehicleModel} = require("../models");
  const { responseCodes } = require("../config");
  const joi = require("joi");
  const { s3 } = require("../services");
  module.exports = {
    add: async (req, res) => {
      try {
            const value = await joi
          .object({
            vehicle_id: joi.string().uuid().required(),
            vehicle_type_id: joi.string().uuid().required() ,
            model:joi.string().trim().required(),
            seat:joi.number().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.VC.invalidBody.code });
          });
        const isAlreadyExist = await VehicleModel.findOne({
          where: { vehicle_id:value.vehicle_id,
            vehicle_type_id:value.vehicle_type_id,
             model: { [Op.like] :'%' + value.model + '%' },
          }
        });
        if (isAlreadyExist) {
          return res
            .status(400)
            .json({ code: responseCodes.VC.alreadyExists.code });
        }
        await VehicleModel.create(value);
        return res.status(201).json({ code: responseCodes.VC.created.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    getAll: async (req, res) => {
        try {
         const page = parseInt(req.query.page) || 1;
          const perPage = parseInt(req.query.perPage) || 10;
          const offset = (page - 1) * perPage;
      
          const sortBy = req.query.sortBy
          const orderBy =req.query.orderBy
          const searchString = req.query.search;
          const companyNameFilter = req.query.company_name;
          const typeNameFilter = req.query.type;
          const statusFilter = req.query.status;
      
          const whereCondition = {};
          if (searchString!== undefined ) {
            whereCondition[Op.or] = [
              {
                '$vehicletypes.type$': {
                  [Op.like]: `%${searchString}%`,
                },
              },
              {
                '$vehicletypes.vehiclemodels.model$': {
                  [Op.like]: `%${searchString}%`,
                },
              },
              {
                ['$company_name$']: {
                  [Op.like]: `%${searchString}%`,
                },
              },
            ];
            
          }
         
          if (companyNameFilter) {
            whereCondition['$company_name$'] = companyNameFilter;
          }
          if (typeNameFilter) {
            whereCondition['$vehicletypes.type$'] = typeNameFilter;
          }
          if (statusFilter !== undefined) {
            whereCondition.status = statusFilter === 'true' ? true : false;
          }
          let orderByCond = [["company_name",'ASC']];
          if (sortBy && orderBy) { 
           if (sortBy === "company_name") {
              orderByCond = [["company_name", sortBy,orderBy]];
            }
            else if(sortBy === "type"){
            orderByCond  =[[{ model:VehicleType, as: "vehicletypes" }, sortBy, orderBy]];
          }
          else if(sortBy === "model"){
            orderByCond  =[[{ model: VehicleType.VehicleModel, as: "vehicleModels" }, sortBy, orderBy]];
          } 
          }
         
         let list = await Vehicle.findAll({
            attributes: ['id', 'company_name', 'image'],
            include: [
              {
                model: VehicleType,
                as: 'vehicletypes',
                through:{
                  model:VehicleModel,
                  as: 'vehiclemodels',
                  attributes:['id', 'model','seat']},
                attributes: ['id', 'type',],
              },
            ],

            where: whereCondition,
            offset,
            limit: perPage,
            order:orderByCond
          });
          
      
        
          if (!list) {
            return res.status(200).json([]);
          }
          const totalRecordsCount = await Vehicle.count({
            attributes: [],
            include: [
              {
                model: VehicleType,
                as: 'vehicletypes',
                through:{
                  model:VehicleModel,
                  as: 'vehiclemodels',
                  attributes:[]},
                attributes: [],
              },
            ],
            where: whereCondition,
          });
          
      
          return res.status(200).json({ data:list , totalRecordsCount});
        
      } catch (err) {
          console.error("err:", err);
          return res.status(500).json({ code: responseCodes.SE.internalError.code });
        }
      },  
    update: async (req, res) => {
      try {
        const { id } = req.params;
        const value = await joi
          .object({
            type: joi.string().trim().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.VC.invalidBody.code });
          });
        if (!Object.keys(value).length) {
          //INFO: If there is nothing to update send success response.
          return res.json({ code: responseCodes.VC.updated.code });
        }
        let data = {};
        const isAlreadyExist = await VehicleModel.findOne({
          where: { vehicle_id:value.vehicle_id,
            vehicle_type_id:value.vehicle_type_id,
             model: { [Op.like] :'%' + value.model + '%' },
          }
        });
        if (isAlreadyExist){
            return res.status(400).json({ code: responseCodes.VC.alreadyExists.code });
        }
        if (value.hasOwnProperty("model")) {
          data.model = value.model;
        }
        data.vehicle_id = value.vehicle_id;
        data.vehicle_type_id = value.vehicle_type_id;
        await VehicleType.update(data, { where: { id:id } });
        return res.status(200).json({ code: responseCodes.VC.updated.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    delete: async (req, res) => {
      try {
        const { id } = req.params;
        const answerName = await VehicleModel.destroy({
          where: {
            id:id,
          },
        });
        if (answerName < 1) {
          return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
        }
        return res.status(200).json({ code: responseCodes.IN.deleted.code });
      } catch (err) {
        console.error("err:", err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    toggleVehicle: async (req ,res) => {
      try {
       let { id } = req.params;
        let vehicleStatus = await VehicleModel.findOne({
           where: { id: id },
           attributes: ['status']
       });
       if(!vehicleStatus){
        return res.status(400).json({ code: responseCodes.VC.notFound.code })
       }
       if(vehicleStatus.dataValues.status == true){
         await VehicleModel.update(
           { status: false },
           {where: { id : id}, 
         })
       }
        else {
         await VehicleModel.update(
           { status: true },
           {where: { id : id}, 
         })
        } 
        let updatedStatus = await VehicleModel.findOne({
         where: { id: id },
         attributes: ['status']
     });
        return res.status(200).json({ code: responseCodes.IN.updated.code })
      } catch (err) {
       console.error("err:", err);
       return res
         .status(500)
         .json({ code: responseCodes.SE.internalError.code });
     }
   },
  };
  