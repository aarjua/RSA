module.exports = {
    logColors: {
        red: `\x1b[31m%s\x1b[0m`
    },
    userTypes: {
        admin: 'admin',
        managementFunctionUser: 'mt_fn_user',
    },
    userStatus: {
        created: 'created',
        activated: 'activated',
        deactivated: 'deactivated'
    },
    jwtTokenTypes: {
        accessToken: 'access_token',
        refreshToken: 'refresh_token',
        mailToken: 'mail_token'
    },
    language: { //TODO: name should be languages
        english: 'EN',
        german: 'DE'
    },
    snsTopics: {
        newUser: 'new-user'
    },
    enviroment:{
        staging: 'staging',
        UAT: 'UAT',
        live: 'live'
    }
}