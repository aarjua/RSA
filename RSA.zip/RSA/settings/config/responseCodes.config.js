/**
 * SM - System
 * AU - Auth
 * UR - User
 */

module.exports = {
  /**
   * SE - System
   */
  SE: {
    internalError: {
      code: "SE500",
      message: "internal server error",
    },
    invalidEncryptedBody: {
      code: "SE501",
      message: "invalid encrypted body or couldn't decrypt the request body",
    },
  },
  /**
   * CM -Country
   */
  CM: {
    notFound: {
      code: "CM404",
      message: " country name not found",
    },
  },
  /**
   * AU -Authentication
   */
  AU: {
    invalidToken: {
      code: "AU411",
      message: "invalid token",
    },
  },
  /**
   * CA- Category
   */
  CA: {
    created: {
      code: "CA200",
      message: "created",
    },
    invalidBody: {
      code: "CA400",
      message: "body invalid",
    },
    categoryAlreadyExist: {
      code: "CA401",
      message: "category already exist",
    },
    notFound: {
      code: "CA403",
      message: "category not found",
    },
    invalidQuery: {
      code: "AU410",
      message: "query invalid",
    },
    deleted: {
      code: "CA201",
      message: "category deleted successfully",
    },
    updated: {
      code: "CA202",
      message: "category updated successfully",
    },
  },
  /**
   * OF- Offer Master
   */
  OF: {
    created: {
      code: "OF200",
      message: "created",
    },
    invalidBody: {
      code: "OF400",
      message: "body invalid",
    },
    categoryAlreadyExist: {
      code: "OF401",
      message: "category already exist",
    },
    notFound: {
      code: "OF403",
      message: "category not found",
    },
    invalidQuery: {
      code: "OF410",
      message: "query invalid",
    },
    deleted: {
      code: "OF201",
      message: "category deleted successfully",
    },
    updated: {
      code: "OF202",
      message: "category updated successfully",
    },
  },
  /**
   * PG - Page
   */
  PG: {
    notFound: {
      code: "PG403",
      message: "not found",
    },
    invalidBody: {
      code: "PG400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "PG401",
      message: "type already exists",
    },
    created: {
      code: "PG200",
      message: "created",
    },
    updated: {
      code: "PG201",
      message: "updated",
    },
    deleted: {
      code: "PG202",
      message: "deleted",
    },
  },
  /**
   * IN - Interest
   */
  IN: {
    notFound: {
      code: "IN403",
      message: "not found",
    },
    invalidBody: {
      code: "IN400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "IN401",
      message: "already exists",
    },
    created: {
      code: "IN200",
      message: "created",
    },
    updated: {
      code: "IN201",
      message: "updated",
    },
    deleted: {
      code: "IN202",
      message: "deleted",
    },
    appDataNotFound: {
      code: "IN204",
      message: "app data not found",
    },
    appalreadyExists: {
      code: "IN402",
      message: "app setting already exists",
    },
  },
  /**
   * ES - Email Settings
   */
  ES: {
    notFound: {
      code: "ES403",
      message: "not found",
    },
    invalidBody: {
      code: "ES400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "ES401",
      message: "already exists",
    },
    created: {
      code: "ES200",
      message: "created",
    },
    updated: {
      code: "ES201",
      message: "updated",
    },
    deleted: {
      code: "ES202",
      message: "deleted",
    },
  },
  /**
   * U - System User
   */
  UR: {
    created: {
      code: "SU201",
      message: "created",
    },
    notFound: {
      code: "SU404",
      message: "system user not found",
    },
    validations: {
      invalidBody: {
        code: "SU400",
        message: "body invalid",
      },
      exists: {
        code: "SU409",
        message: "already exists",
      },
    },
    updated: {
      code: "SU200",
      message: "updated",
    },
  },

  //Price catalogue
  PC: {
    notFound: {
      code: "PC404",
      message: "price catalogue is not found",
    },
    invalidBody: {
      code: "PC400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "PC401",
      message: "already exists",
    },
    created: {
      code: "PC200",
      message: "created",
    },
    updated: {
      code: "PC201",
      message: "updated",
    },
    deleted: {
      code: "PC202",
      message: "deleted",
    },
  },

  //Vehicle catalogue
  VC: {
    notFound: {
      code: "VC403",
      message: "not found",
    },
    invalidBody: {
      code: "VC400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "VC401",
      message: "already exists",
    },
    created: {
      code: "VC200",
      message: "created",
    },
    updated: {
      code: "VC201",
      message: "updated",
    },
    deleted: {
      code: "VC202",
      message: "deleted",
    },
  },
  // Country Names
  CN: {
    invalidBody: {
      code: "CN400",
      message: "body invalid",
    },
  },
  // Cities Names
  CI: {
    invalidBody: {
      code: "CI400",
      message: "body invalid",
    },
  },
  // Rate for distances
  RD: {
    notFound: {
      code: "RD403",
      message: "not found",
    },
    invalidBody: {
      code: "RD400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "RD401",
      message: "already exists",
    },
    created: {
      code: "RD200",
      message: "created",
    },
    updated: {
      code: "RD201",
      message: "updated",
    },
    deleted: {
      code: "RD202",
      message: "deleted",
    },
  },
  // Peak Hours
  PH: {
    notFound: {
      code: "PH403",
      message: "not found",
    },
    invalidBody: {
      code: "PH400",
      message: "body invalid",
    },
    alreadyExists: {
      code: "PH401",
      message: "already exists",
    },
    created: {
      code: "PH200",
      message: "created",
    },
    updated: {
      code: "PH201",
      message: "updated",
    },
    deleted: {
      code: "PH202",
      message: "deleted",
    },
  },
};

(() => {
  const codes = new Set();

  const checkCodesUniqueness = (obj) => {
    for (const key in obj) {
      const code = obj[key].code;
      const message = obj[key].message;

      if (code !== undefined) {
        if (codes.has(code)) {
          throw new Error(`Duplicate code found: ${code}.`);
        } else {
          codes.add(code);
        }
      }

      if (message !== undefined && /[A-Z]/.test(message)) {
        throw new Error(`Capital letters found in message: ${message}`);
      }

      if (typeof obj[key] === "object") {
        checkCodesUniqueness(obj[key]);
      }
    }
  };

  checkCodesUniqueness(module.exports);
})();
