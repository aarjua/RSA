"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("mobile_settings", {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      distance_unit: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      base_fare: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      free_wait_time: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      wait_charges: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      is_tax_percentage: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      tax_amount: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_country_applicable: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      is_driver_penalty_percentage: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      driver_penalty_amount: {
        type: Sequelize.DOUBLE,
        allowNull: true,
      },
      allow_cancel_rides_by_driver: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      is_passenger_penalty_percentage: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      passenger_penalty_amount: {
        type: Sequelize.DOUBLE,
        allowNull: true,
      },
      allow_cancel_rides_by_passenger: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      start_date: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      end_date: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      country_id: {
        type: Sequelize.UUID,
        references: {
          model: "countries",
          key: "id",
        },
      },
      city_id: {
        type: Sequelize.UUID,
        references: {
          model: "cities",
          key: "id",
        },
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("mobile_settings");
  },
};
