'use strict';

/** @type {import('sequelize').Sequelize } */
const Sequelize = require('sequelize');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.removeColumn('vehicle_types', 'vehicle_id');
  },

  async down(queryInterface, Sequelize) {
  await queryInterface.addColumn('vehicle_types', 'vehicle_id', {
  type: Sequelize.UUID,
  references: {
    model: "vehicles",
    key: "id",
  },
  onDelete: 'CASCADE'
    });
  }

};