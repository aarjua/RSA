'use strict';

/** @type {import('sequelize').Sequelize } */
const Sequelize = require('sequelize');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.removeColumn('vehicle_types', 'seat');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.addColumn('vehicle_types', 'seat', {
      type: Sequelize.NUMBER, // Use INTEGER instead of NUMBER
      allowNull: true,
    });
  }
};