'use strict';

/** @type {import('sequelize-cli').Migration} */
const { enviroment } = require("../config/enums.config");
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('email_settings', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
    },
    enviroment: {
      type: Sequelize.ENUM(...Object.values(enviroment)),
      allowNull: false
    },
    send_from: {
        type: Sequelize.STRING,
        allowNull: false,
    },
    send_grid_key: {
      type: Sequelize.STRING,
      allowNull: false,
  },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('email_settings');
  }
};
