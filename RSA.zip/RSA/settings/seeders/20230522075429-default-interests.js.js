'use strict';
const console = require("../config").logs('yap:seeder');
const { Interest } =require("../models");
const defaultInterests = [
  "Animation",
  "Visual Art",
  "Writing",
  "Photography",
  "Video Editing"
]
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    try {
      const createdInterests = [];
      for (const name of defaultInterests) {
        const [func, created] = await Interest.findOrCreate({ where: { name } });
        if (created) {
          createdInterests.push(func);
        }
      }
      console.log(`Created ${createdInterests.length} interests.`);
    } catch (error) {
      console.error("Error creating interests:", error);
    }
      },


  async down (queryInterface, Sequelize) {
    try {
      const deletedInterestCount = await Interest.destroy({ where: { name: defaultInterests } });
      console.log(`Deleted ${deletedInterestCount} interests.`);
    } catch (error) {
      console.error("Error deleting interests:", error);
    }
  }
};
