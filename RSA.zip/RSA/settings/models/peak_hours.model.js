const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const Cities = require("./cities.model");
const Country = require("./countries.model");

const PeakHours = sequelize.define(
  "peak_hours",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    from: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    to: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    rate: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);
Country.hasMany(PeakHours, { as: "peak_hours", foreignKey: "country_id" });
PeakHours.belongsTo(Country, {
  foreignKey: "country_id",
});
Cities.hasMany(PeakHours, {
  as: "peak_hours",
  foreignKey: "city_id",
});
PeakHours.belongsTo(Cities, { foreignKey: "city_id" });
module.exports = PeakHours;
