module.exports = {
  Category: require("./category.model"),
  Country: require("./countries.model"),
  Cities: require("./cities.model"),
  RateDistances: require("./rate_distances.model"),
  PeakHours: require("./peak_hours.model"),
  MobileSettings: require("./mobile_settings.model"),
  Page: require("./page.model"),
  VehicleColour: require("./vehicle.colour.model"),
  Vehicle: require("./vehicle.model"),
  VehicleType: require("./vehicle.type.model"),
  VehicleModel: require("./vehicle.model.model"),
  VehicleFuel: require("./vehicle.fuel.model"),
  PriceMaster: require("./price.master.model"),
  Offer: require("./offer.model"),
  EmailSetting: require("./email_settings")
};
