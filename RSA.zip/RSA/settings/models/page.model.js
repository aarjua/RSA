const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");

const Page = sequelize.define('page', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      title: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.TEXT,
      },
      type: {
        type: DataTypes.STRING,
        allowNull: false,
      },
},
    {
        timestamps: true,
        createdAt: "created_at",
        updatedAt: "updated_at",
        underscored: true
    });

module.exports = Page;