const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");

const VehicleColours = sequelize.define('vehicle_colour', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  colour: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  colour_code: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  image: {
    type: DataTypes.STRING,
    allowNull: false,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

module.exports = VehicleColours;