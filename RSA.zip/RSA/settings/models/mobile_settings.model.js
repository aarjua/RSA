const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const City = require("./cities.model");
const Country = require("./countries.model");

const MobileSettings = sequelize.define(
  "mobile_settings",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    distance_unit: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    base_fare: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    free_wait_time: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    wait_charges: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_tax_percentage: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    tax_amount: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_country_applicable: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    is_driver_penalty_percentage: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    driver_penalty_amount: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    allow_cancel_rides_by_driver: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    is_passenger_penalty_percentage: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    passenger_penalty_amount: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    allow_cancel_rides_by_passenger: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    start_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    end_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

City.hasMany(MobileSettings, {
  foreignKey: "city_id",
  as: "cities",
});
MobileSettings.belongsTo(City, {
  foreignKey: "city_id",
  as: "city",
});
Country.hasMany(MobileSettings, {
  foreignKey: "country_id",
  as: "countries",
});
MobileSettings.belongsTo(Country, {
  foreignKey: "country_id",
  as: "country",
});
module.exports = MobileSettings;
