const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const VehicleType = require("./vehicle.type.model");
const Vehicle = require("./vehicle.model")
const VehicleModel = sequelize.define('vehicle_model', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  vehicle_id: {
    type: DataTypes.UUID,
    references: {
      model: "vehicles",
      key: "id",
    },
    onDelete: 'CASCADE'
  },
  vehicle_type_id: {
    type: DataTypes.UUID,
    references: {
      model: "vehicle_types",
      key: "id",
    },
    onDelete: 'CASCADE'
  },
  model: {
    type: DataTypes.STRING
  },
  seat: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  status: {
    type: DataTypes.BOOLEAN,
    defaultValue: 1,
  },
  

},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

// Vehicle.hasMany(VehicleModel, { foreignKey: 'vehicle_id',as:'vehicle '});
// VehicleModel.belongsTo(Vehicle, { foreignKey: 'id', as: 'models' });
// VehicleType.hasMany(VehicleModel, { foreignKey: 'vehicle_type_id',as: 'vehiclemodel' });
// VehicleModel.belongsTo(VehicleType, { foreignKey: 'id', as: 'types' });

Vehicle.belongsToMany(VehicleType, { through: VehicleModel, foreignKey: 'vehicle_id', as: 'vehicletypes' });
VehicleType.belongsToMany(Vehicle, { through: VehicleModel, foreignKey: 'vehicle_type_id', as: 'vehiclemodels' });

module.exports = VehicleModel;