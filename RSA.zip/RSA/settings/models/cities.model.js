const Country = require("./countries.model");
const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const Cities = sequelize.define(
  "cities",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    country_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: "countries",
        key: "id",
      },
      onUpdate: "RESTRICT",
      onDelete: "CASCADE",
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);
Country.hasMany(Cities, { as: "country", foreignKey: "country_id" });
Cities.belongsTo(Country, { foreignKey: "country_id", as: "country" });
module.exports = Cities;
