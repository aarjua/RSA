const {
    db: {
      sequelize,
      Sequelize: { DataTypes },
    },
  } = require("../config");
  const { enviroment } = require("../config/enums.config");
  
  const EmailSetting = sequelize.define(
    "email_settings",
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        enviroment: {
          type: DataTypes.ENUM(...Object.values(enviroment)),
          allowNull: false
        },
        send_from: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        send_grid_key: {
          type: DataTypes.STRING,
          allowNull: false,
      },
    },
    {
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );

  module.exports = EmailSetting;
  