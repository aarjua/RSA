const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const Vehicle = require("./vehicle.model");

const VehicleType = sequelize.define('vehicle_type', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  type: {
    type: DataTypes.STRING
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

// Vehicle.hasMany(VehicleType, { as: "vehicletypes", foreignKey: "vehicle_id" });
// VehicleType.belongsTo(Vehicle, { foreignKey: 'vehicle_id' });

// Vehicle.hasMany(VehicleType, { as: 'types' });
// VehicleType.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });
module.exports = VehicleType;
