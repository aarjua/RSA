const joi = require("joi");

const emailSettingsDtos = joi.object({
  enviroment: joi.string().required(),
  send_from: joi.string().required(),
  send_grid_key: joi.string().required(),
});


module.exports = { emailSettingsDtos};
