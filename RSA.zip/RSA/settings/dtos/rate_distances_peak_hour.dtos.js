const joi = require("joi");

const rateDistancesPeakHourDtos = joi.object({
  from: joi.string().required(),
  to: joi.string().required(),
  rate: joi.string().required(),
});

module.exports = { rateDistancesPeakHourDtos };
