const joi = require("joi");

const mobileSettingsDtos = joi.object({
  country_id: joi.string().uuid().required(),
  city_id: joi.string().uuid().optional(),
  is_country_applicable: joi.boolean().required(),
  distance_unit: joi.string().required(),
  base_fare: joi.string().required(),
  free_wait_time: joi.string().required(),
  wait_charges: joi.string().required(),
  is_tax_percentage: joi.boolean().required(),
  tax_amount: joi.string().required(),
  is_driver_penalty_percentage: joi.boolean().required(),
  driver_penalty_amount: joi.number().required(),
  allow_cancel_rides_by_driver: joi.number().required(),
  is_passenger_penalty_percentage: joi.boolean().required(),
  passenger_penalty_amount: joi.number().required(),
  allow_cancel_rides_by_passenger: joi.number().required(),
});

const mobileSettingsPaginationDtos = joi.object({
  limit: joi.number(),
  page: joi.number(),
  search: joi.string().optional(),
  country_id: joi.string().optional(),
  city_id: joi.string().optional(),
  is_active: joi.string().optional(),
});

const toggleStatusDtos = joi.object({
  id: joi.string().uuid().required(),
});

const getRecommendationPriceDtos = joi.object({
  start_city_name: joi.string(),
  start_city_address: joi.string().optional(),
  start_point_latitude: joi.string().optional(),
  start_point_longitude: joi.string().optional(),
  start_time: joi.date().required(),
  country: joi.string().required(),
  distance: joi.number().required(),
  total_stop_over: joi.number().optional(),
});

const reversePriceCalculationDtos = joi.object({
  price_master_id: joi.string().uuid().required(),
  total_amount: joi.number().required(),
});

module.exports = {
  mobileSettingsDtos,
  mobileSettingsPaginationDtos,
  toggleStatusDtos,
  getRecommendationPriceDtos,
  reversePriceCalculationDtos,
};
