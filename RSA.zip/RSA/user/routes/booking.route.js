const express = require("express");
const router = express.Router();
const BookingController = require("../controllers/booking.controller");


router.patch("/secret-pin/:id", BookingController.checkSecretPin);
router.post("/:profile_id", BookingController.add);
router.patch("/update/:id", BookingController.update);
router.route("/:id/status").patch(BookingController.toggleBlockedStatus);
router.patch("/block-unblock/:id/:status", BookingController.toggleActiveStatus);
router.route("/passenger/create_booking").post(BookingController.createPassengerBooking)
router.route("/passenger/create_booking_history").post(BookingController.createBookingHistory)
router.route("/")
  .get(BookingController.getAll)
router.route("/:id")
  .get(BookingController.get)
  .delete(BookingController.delete)

module.exports = router;
