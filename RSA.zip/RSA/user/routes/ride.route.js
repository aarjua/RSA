const express = require("express");
const router = express.Router();
const RideController = require("../controllers/ride.controller");


router.post("/:profile_id", RideController.add);
router.patch("/update/:id", RideController.update);
router.route("/:id/:status").patch(RideController.toggleActiveStatus);
router.patch("/block-unblock/:id/status", RideController.toggleBlockedStatus)
router.post("/fetch/availableRideList", RideController.getAvailbleRidelist)
router.post("/fetch/getAvailbleRidelistforTesting", RideController.getAvailbleRidelistforTesting)
router.route("/")
  .get(RideController.getAll)
  // .post(RideController.add);
router.route("/:id")
  .get(RideController.get)
  // .patch(RideController.update)
  .delete(RideController.delete)

router.post("/report/driver",RideController.reportDriver)
module.exports = router;
