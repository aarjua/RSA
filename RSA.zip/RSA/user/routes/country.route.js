const express = require("express");
const router = express.Router();
const { CountryController } = require("../controllers");

router.route("/").get(CountryController.getAll);

module.exports = router;
