const express = require("express");
const router = express.Router();
const { ProfileController, UserProfileController } = require("../controllers");
const {
  auth: { auth },
  multerMiddleware,
} = require("../middlewares");

router.get("/response-code", ProfileController.responseCode);
router.get("/get_user_bank_details_list/:user_id", ProfileController.userBankDetailsList);
router.patch("/update_user_bank_details/:user_id", ProfileController.updateUserBankDetails);
router.delete("/delete_user_bank_details/:user_id", ProfileController.deleteUserBankDetails);
router.route("/self")
  .get(auth(), ProfileController.getSelf)

router.route("/")
  .get(ProfileController.getAll)
  .post(ProfileController.add)
router.route("/relatedInterest")
  .get(auth(), ProfileController.relatedInterests);
router.route("/:id")
  .get(ProfileController.get)
  .patch(ProfileController.update)
  .delete(ProfileController.delete)
  .put(ProfileController.updateInterest)

router.route("/profile-pic-update").post([auth(), multerMiddleware.uploadSingle("image")], ProfileController.profileUpdate);
router.route('/getInterest/:id').get(ProfileController.getInterest);
router.route("/self").get(auth(), ProfileController.getSelf);

router.route("/").get(ProfileController.getAll).post(ProfileController.add);
router
  .route("/updateProfile/:id")
  .patch(
    multerMiddleware.uploadSingle("thumbnail"),
    ProfileController.profileUrl
  );

router.route("/add-car/:profile_id").post(auth(),ProfileController.addCarDetail)
router.route("/update-car/:id").patch(auth(),ProfileController.updateCarDetail)
router.route("/get-car/:profile_id").get(auth(),ProfileController.getCarDetail)
router.route("/update-rc/:id").patch([auth(), multerMiddleware.uploadSingle("image"), ],ProfileController.updateRC)
router.route("/delete-rc/:id").patch(auth(),ProfileController.deleteRC)
router.route("/delete-vehicle/:id").delete(auth(),ProfileController.deleteVehicle)

router.route("/add-doc/:profile_id").post([auth(), multerMiddleware.uploadSingle("image"), ],ProfileController.addDoc)
router.route("/update-doc/:id").patch([auth(), multerMiddleware.uploadSingle("image"), ],ProfileController.updatedoc)
router.route("/get-doc/:profile_id").get(auth(),ProfileController.getUserDoc)
router.route("/delete-doc/:id").delete(auth(),ProfileController.deleteUserDoc)
router.route("/update-rc-status/:id/:status").patch( ProfileController.toggleRCStatus)
router.route("/update-doc-status/:id/:status").patch(auth(), ProfileController.toggleDocStatus)
router.route("/update-profile-status/:id/:status").patch(ProfileController.toggleProfileStatus)
router.route("/update-role-status/:id/:status").patch( ProfileController.updatefinalRoleStatus)
router.route("/add-user-prefrense/:profile_id").patch(auth(),ProfileController.addUserPrefrense)
router.route("/get-user-prefrense/:profile_id/").get(auth(),ProfileController.getUserPrefrense)

router.route("/add-address").post(auth(), ProfileController.addAddressDetail)
router.route("/get_passenger_booking_list/:userId").get(ProfileController.getPassengerBookingList)

router.route("/is_liked_disliked/:profile_id")
  .post(auth(), UserProfileController.add);
// router.route("/like-dislike/:profile_id/count") 
//   .get(auth(),UserProfileController.get);
router.route("/report/:profile_id")
  .post(auth(), UserProfileController.addReport)
router.route("/is_followed/:profile_id")
  .post(auth(), UserProfileController.follow);
router.route("/reports/get-reports")
  .get(auth(), UserProfileController.getReport)
router.route("/is_followed/:profile_id")
  .get(auth(), UserProfileController.profileFollowed);

  router.route("/add-user-bank-details/:user_id")
  .post(auth(), ProfileController.addUserBankDetails);
  
module.exports = router;

