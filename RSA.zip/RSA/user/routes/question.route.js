const express = require("express");
const router = express.Router();
const QuestionController = require("../controllers/question.controller");
const {
  auth: { auth },
  multerMiddleware,
} = require("../middlewares");

router.get("/last-sequence", QuestionController.getLatestPosition);
router.patch("/:id/status", QuestionController.toggleActiveStatus);
router
  .route("/")
  .get(QuestionController.getAll)
  .post(
    [auth(), multerMiddleware.uploadSingle("icon")],
    QuestionController.add
  );
router
  .route("/:id")
  .get(QuestionController.get)
  .patch(
    [auth(), multerMiddleware.uploadSingle("icon")],
    QuestionController.update
  )
  .delete(QuestionController.delete);

module.exports = router;
