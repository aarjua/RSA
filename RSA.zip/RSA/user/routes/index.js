var express = require("express");
var router = express.Router();

router.get("/hc", (req, res) =>  res.json({ data: "abc" }));

router.use("/profiles", require("./profile.route"));
router.use("/countries", require("./country.route"));
router.use("/questions", require("./question.route"));
router.use("/rides", require("./ride.route"));
router.use("/bookings", require("./booking.route"));
module.exports = router;
