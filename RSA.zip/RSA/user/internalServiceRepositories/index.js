module.exports = {
  internalPaymentServiceRepository: require("./internalPaymentServiceRepository")
};
