const {
  env: { PAYMENT_SERVICE_URL },
} = require("../config");
const {
  makeRestCall,
  RestClientMethodEnum,
} = require("../restClientService/restClientService");
const axios = require("axios");
const { decryptResponseBody } = require("../services/crypto.service");

module.exports = {
  getPassengerRidePayment: async (ride_id) => {
    try {
      const url = PAYMENT_SERVICE_URL + "/payments/" + ride_id;
      const response = await makeRestCall(
        RestClientMethodEnum.GET,
        url,
        null,
        null
      );
      return response;
    } catch (err) {
      throw err;
    }
  },
  updateRefundStatus: async (ride_id, profile_id, passenger_booking_id) => {
    try {
      const url = PAYMENT_SERVICE_URL + "/payments//update-refund-status";
      const response = await makeRestCall(
        RestClientMethodEnum.PATCH,
        url,
        null,
        {
          ride_id,
          profile_id,
          passenger_booking_id,
        }
      );
      return response;
    } catch (err) {
      throw err;
    }
  },
};
