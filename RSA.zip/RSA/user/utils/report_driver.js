const reportDriverEnums = {
  SCAM: "scam",
  UNSAFE: "unsafe",
  PROFILE_RIDE_SUSPICIOUS: "profile_ride_suspicious",
  SUSPICIOUS_PAYMENT: "suspicious_payment",
  OTHER: "other",
};

module.exports = {
  reportDriverEnums,
};
