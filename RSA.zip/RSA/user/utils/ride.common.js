const listSorting = (list, sortBy = "ASC") => {
  return list.sort((a, b) => {
    if (sortBy == "ASC") {
      return a.driver_name.toLowerCase() < b.driver_name.toLowerCase() ? -1 : 1;
    } else {
      return b.driver_name.localeCompare(a.driver_name);
    }
  });
};

const getTokenFromHeader = (authHeader) => {
  const token = authHeader && authHeader.split(" ")[1];
  if (token == null) {
    throw new Error("Bearer token not present in the headers");
  }
  return token;
};

module.exports = { listSorting, getTokenFromHeader };
