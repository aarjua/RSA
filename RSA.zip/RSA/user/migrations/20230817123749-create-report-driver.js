"use strict";

const { reportDriverEnums } = require("../utils/report_driver");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("report_drivers", {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      passenger_user_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      ride_id: {
        type: Sequelize.UUID,
        allowNull: false,
        // references: {
        //   model: "offer_rides",
        //   key: "id",
        // },
        // onUpdate: "RESTRICT",
        // onDelete: "CASCADE",
      },
      reason: {
        type: Sequelize.ENUM,
        values: Object.values(reportDriverEnums),
        allowNull: true,
      },
      message: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("report_drivers");
  },
};
