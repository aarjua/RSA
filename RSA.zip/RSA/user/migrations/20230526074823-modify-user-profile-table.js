"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.removeColumn("profile-users", "is_disliked");
    await queryInterface.addColumn("profile-users", "is_disliked", {
      type: Sequelize.BOOLEAN,
      allowNull:true
    })
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.removeColumn("profile-users", "is_disliked", {
      type: Sequelize.BOOLEAN,
      allowNull:true
    })
  },
};
