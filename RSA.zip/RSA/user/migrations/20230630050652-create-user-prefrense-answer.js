'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('user_prefrense_answers', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      prefrense_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "user_prefrenses",
          key: "id",
        },
        onDelete: 'CASCADE'
      },
      // profile_id: {
      //   type: Sequelize.UUID,
      //   allowNull: false,
      //   references: {
      //     model: "profiles",
      //     key: "id",
      //   },
      // },
      // question_id: {
      //   type: Sequelize.UUID,
      //   allowNull: false,
      //   references: {
      //     model: "questions",
      //     key: "id",
      //   },
      // },
      answer_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "question_answers",
          key: "id",
        },
        onDelete: 'CASCADE'
      },
      start_range: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      end_range: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('user_prefrense_answers');
  }
};