'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    queryInterface.addColumn(
      'user_bank_details',
      'bank_address',
      {
        type: Sequelize.STRING,
        allowNull: true,
      },
    )
    
  },

  async down(queryInterface, Sequelize) {
    queryInterface.addColumn(
      'user_bank_details',
      'bank_address',
      {
        type: Sequelize.STRING,
        allowNull: true,
      }
    )
  }
};