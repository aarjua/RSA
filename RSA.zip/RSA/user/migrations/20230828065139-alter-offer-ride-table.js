'use strict';

/** @type {import('sequelize').Sequelize } */
const Sequelize = require('sequelize');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.removeColumn('offer_rides', 'invoice_id');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.addColumn('offer_rides', 'invoice_id', {
      type: Sequelize.INTEGER, // Use INTEGER instead of NUMBER
      allowNull: true,
    });
  }

};