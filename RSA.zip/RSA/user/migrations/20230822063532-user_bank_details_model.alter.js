'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    queryInterface.changeColumn(
      'user_bank_details',
      'account_no',
      {
        type: Sequelize.STRING,
        allowNull: false,
      },
    ),
    queryInterface.changeColumn(
      'user_bank_details',
      'bank_name',
      {
        type: Sequelize.STRING,
        allowNull: false,
      },
    )
  },

  async down(queryInterface, Sequelize) {
    queryInterface.changeColumn(
      'user_bank_details',
      'account_no',
      {
        type: Sequelize.STRING,
        allowNull: false,
      },
    ),
    queryInterface.changeColumn(
      'user_bank_details',
      'bank_name',
      {
        type: Sequelize.STRING,
        allowNull: false,
      },
    )
  }
};