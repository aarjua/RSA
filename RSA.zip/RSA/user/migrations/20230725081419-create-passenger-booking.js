'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('passenger_bookings', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      ride_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "offer_rides",
          key: "id",
        },
        onUpdate: 'RESTRICT',
        onDelete: 'CASCADE'
      },
      profile_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "profiles",
          key: "id",
        },
        onUpdate: 'RESTRICT',
        onDelete: 'CASCADE'
      },
      start_point_latitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      start_point_longitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      end_point_latitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      end_point_longitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      distance: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      start_time: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      end_time: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      total_passenger: {
        allowNull: true,
        type: Sequelize.INTEGER,
      },
      amount_per_person: {
        allowNull: true,
        type: Sequelize.INTEGER,
      },
      total_amount: {
        allowNull: true,
        type: Sequelize.INTEGER,
      },
      is_round_trip: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        defaultValue: 0,
      },
      booking_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: 1,
      },
      secret_pin: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      secret_pin_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue: 0,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        defaultValue: 1,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('passenger_bookings');
  }
};