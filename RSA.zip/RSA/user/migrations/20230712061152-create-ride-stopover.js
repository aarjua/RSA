'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('ride_stopovers', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      ride_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "offer_rides",
          key: "id",
        },
        onUpdate: 'RESTRICT',
        onDelete: 'CASCADE'
      },
      index: {
        type: Sequelize.NUMBER,
        allowNull: true,
      },
      city_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      city_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      latitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      longitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      price: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      distance: {
        type: Sequelize.NUMBER,
        allowNull: true,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('ride_stopovers');
  }
};