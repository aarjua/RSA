'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('user_vehicles', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      profile_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
            model: "profiles",
            key: "id",
          }, 
      },
      vehicle_no: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      vehicle_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      model_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      type_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      colour_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      offer_seat:{
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      model_year: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      rc: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      rc_name: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        defaultValue: 1,
      },
      rc_status: {
        type: Sequelize.NUMBER,
        allowNull: true,
        defaultValue: 0,
      },
      rc_date: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      rc_description: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('user_vehicles');
  }
};