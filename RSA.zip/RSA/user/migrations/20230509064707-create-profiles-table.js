"use strict";

const { profileType } = require("../config/enums.config");
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("profiles", {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false
        // defaultValue: Sequelize.UUIDV4,
        // primaryKey: true,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      // last_name: {
      //   type: Sequelize.STRING,
      //   allowNull: true,
      // },
      gender: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      dob: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      profile_type: {
        type: Sequelize.ENUM(...Object.values(profileType)),
        allowNull: false,
      },
      profile_detail: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      profile_url: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      requested_role: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      role_change_status: {
        type: Sequelize.NUMBER,
        allowNull: true,
        defaultValue: 0,
      },
      // country_id: {
      //   type: Sequelize.UUID,
      //   allowNull: false,
      //   references: {
      //     model: "countries",
      //     key: "id",
      //   },
      // },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("profiles");
  },
};
