"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("offer_rides", {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      profile_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "profiles",
          key: "id",
        },
      },
      user_vehicle_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: "user_vehicles",
          key: "id",
        },
        // onUpdate: 'RESTRICT',
        // onDelete: 'SET NULL'
      },
      start_city_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      start_city_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      start_point_latitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      start_point_longitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      end_city_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      end_city_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      end_point_latitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      end_point_longitude: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      country: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      available_seat: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      total_price: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      total_distance: {
        type: Sequelize.NUMBER,
        allowNull: true,
      },
      route_description: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_round_trip: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: 1,
      },
      ride_status: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        defaultValue: 1,
      },
      start_time: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      end_time: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      round_start_time: {
        allowNull: true,
        type: Sequelize.DATE,
      },
      round_end_time: {
        allowNull: true,
        type: Sequelize.DATE,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("offer_rides");
  },
};
