const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");

const Question = sequelize.define(
  "question",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    position: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    weghtage: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    answer_type: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    icon: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: 1,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

module.exports = Question;
