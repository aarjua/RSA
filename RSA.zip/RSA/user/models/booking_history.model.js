const { db: { sequelize, Sequelize: { DataTypes } } } = require("../config");
const PassengerBooking = require("./passenger_booking.model");

const BookingHistory = sequelize.define('booking_histrory', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  booking_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "passenger_bookings",
      key: "id",
    },
    onUpdate: 'RESTRICT',
    onDelete: 'CASCADE'
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  sub_title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  updated_time: {
    allowNull: false,
    type: DataTypes.DATE
  },
  status: {
    allowNull: false,
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

  // PassengerBooking.hasMany(BookingHistory, { as: "booking_history", foreignKey: "passenger_booking_id" });
  // BookingHistory.belongsTo(PassengerBooking, { as: "booking_history", foreignKey: 'passenger_booking_id' });

module.exports = BookingHistory;