const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const OfferRide = require("./offer_ride.model");
const Profile = require("./profile.model");

const PassengerBooking = sequelize.define('passenger_booking', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  ride_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "offer_rides",
      key: "id",
    },
    onUpdate: 'RESTRICT',
    onDelete: 'CASCADE'
  },
  profile_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "profiles",
      key: "id",
    },
    onUpdate: 'RESTRICT',
    onDelete: 'CASCADE'
  },
  start_city_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  start_city_address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  start_point_latitude: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  start_point_longitude: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  end_city_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  end_city_address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  end_point_latitude: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  end_point_longitude: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  distance: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  start_time: {
    allowNull: false,
    type: DataTypes.DATE
  },
  end_time: {
    allowNull: false,
    type: DataTypes.DATE
  },
  round_start_time: {
    allowNull: true,
    type: DataTypes.DATE
  },
  round_end_time: {
    allowNull: true,
    type: DataTypes.DATE
  },
  total_passenger: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  amount_per_person: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  total_amount: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  is_round_trip: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    defaultValue: 0,
  },
  booking_status: {
    type: DataTypes.NUMBER,
    allowNull: true,
    defaultValue: 1,
  },
  secret_pin: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  secret_pin_status: {
    type: DataTypes.NUMBER,
    allowNull: true,
    defaultValue: 0,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });



OfferRide.hasMany(PassengerBooking, { as: "passenger_bookings", foreignKey: "ride_id" });
PassengerBooking.belongsTo(OfferRide, { as: "ride_detail", foreignKey: 'ride_id' });
// PassengerBooking.belongsTo(Profile, { as: "passenger_detail", foreignKey: 'profile_id' });
module.exports = PassengerBooking;