const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const PassengerBooking = require("./passenger_booking.model");

const PassengerDetail = sequelize.define('passenger_detail', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  booking_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "passenger_bookings",
      key: "id",
    },
    onUpdate: 'RESTRICT',
    onDelete: 'CASCADE'
  },
  first_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  last_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  age: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  seat_location: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

PassengerBooking.hasMany(PassengerDetail, { as: "passenger_detail", foreignKey: "booking_id" });
PassengerDetail.belongsTo(PassengerBooking, { as: "passenger_detail", foreignKey: 'booking_id' });

module.exports = PassengerDetail;