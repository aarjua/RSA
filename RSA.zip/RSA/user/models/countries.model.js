const { db: { sequelize, Sequelize: { DataTypes } } } = require("../config");

const Country = sequelize.define('country', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    symbol: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    }
},
    {
        timestamps: true,
        createdAt: "created_at",
        updatedAt: "updated_at",
        underscored: true
    });

module.exports = Country;