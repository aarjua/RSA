const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");

const UserDocument = sequelize.define('user_document', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  profile_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "profiles",
      key: "id",
    },
  },
  first_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  last_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  document: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  document_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  document_description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_verified: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

module.exports = UserDocument;