
const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const { profileType } = require("../config/enums.config");
const Country = require("./countries.model");
const ProfileLikeDislike = require("./profile.like.dislike.model");
const OfferRide = require("./offer_ride.model");
const UserInterest = require("./user.interest.model");

const Profile = sequelize.define(
  "profile",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
      // defaultValue: DataTypes.UUIDV4,
      // primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    // last_name: {
    //   type: DataTypes.STRING,
    //   allowNull: true,
    // },
    gender: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    dob: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    profile_type: {
      type: DataTypes.ENUM(...Object.values(profileType)),
      allowNull: true,
    },
    profile_detail: {
      type: DataTypes.STRING
    },
    profile_url: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    requested_role: {
      type: DataTypes.UUID,
      allowNull: true,
    },
    role_change_status: {
      type: DataTypes.NUMBER,
      allowNull: true,
      defaultValue: 0,
    }
    // country_id: {
    //   type: DataTypes.UUID,
    //   allowNull: true,
    //   references: {
    //     model: "countries",
    //     key: "id",
    //   },
    // },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);
// OfferRide.belongsTo(Profile, {  foreignKey: "profile_id", sourceKey:"id", as: "organisation" });
// Profile.hasMany(OfferRide, {  foreignKey: "profile_id", sourceKey:"id", as: "management_organisation" });
// Profile.hasMany(OfferRide);
// Profile.belongsTo(OfferRide, { as: 'userallrides', constraints: false });
// Profile.hasOne(Country, { as: "country", foreignKey: 'id', sourceKey: 'country_id' });
// Profile.belongsTo(ProfileLikeDislike, { as: "profile-like-dislike", foreignKey: "profile_id" });
Profile.hasMany(ProfileLikeDislike, { as: "profile_like_dislike", foreignKey: 'profile_id', sourceKey: 'id' });

Profile.hasMany(UserInterest, { as: "UserInterest", foreignKey: 'profile_id', sourceKey: 'id' });
// Profile.belongsTo(OfferRide, { as: "UserRide", foreignKey: "profile_id" });
// OfferRide.hasMany(Profile, { as: "UserRide", foreignKey: 'profile_id', sourceKey: 'id' });
// Profile.associate = models => {
//   Profile.hasMany(models.OfferRide, { as: 'profiledetail', foreignKey: 'profile_id', sourceKey: 'id' });
//   // ... other associations ...
// };

module.exports = Profile;
