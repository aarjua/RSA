const {
    db: {
      sequelize,
      Sequelize: { DataTypes },
    },
    enums: {reports}
  } = require("../config");
  const Profile = require("./profile.model");
  
  const ProfileReport = sequelize.define(
    "profile-report",
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
          },
          profile_id: {
            type: DataTypes.UUID,
            allowNull: false,
            references: {
              model: "profiles",
              key: "id",
            },
          },
          reported_by: {
            type: DataTypes.UUID,
            allowNull: false
          },
          report: {
            type: DataTypes.ENUM(...Object.values(reports)),
            allowNull: false
          },
          additional_info: {
            type: DataTypes.STRING,
            allowNull: true
          },
    },
    {
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );
  
  ProfileReport.belongsTo(Profile, { as: "profile-report", foreignKey: "profile_id" });
  
  // Profile.hasMany(UserProfileStatus, { as: 'profile_status', foreignKey: 'profile_status_id' });
  
  module.exports = ProfileReport;
  