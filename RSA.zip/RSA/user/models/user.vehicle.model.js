const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const UserPrefrense = require("./user.prefrense.model");

const UserVehicle = sequelize.define('user_vehicle', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  profile_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "profiles",
      key: "id",
    },
  },
  vehicle_no: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  vehicle_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  model_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  type_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  colour_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  offer_seat: {
    type: DataTypes.NUMBER,
    allowNull: true,
  },
  model_year: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  rc: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  rc_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    defaultValue: 1,
  },
  rc_status: {
    type: DataTypes.NUMBER,
    allowNull: true,
    defaultValue: 0,
  },
  rc_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  rc_description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

  // UserVehicle.hasMany(UserPrefrense, { as: "uservehicles", foreignKey: "user_vehicle_id" });
//   UserVehicle.hasMany(UserPrefrense, { as: "uservehicles", foreignKey: "user_vehicle_id" });
// UserPrefrense.belongsTo(UserVehicle, { as: 'uservehicles', foreignKey: 'user_vehicle_id' });

module.exports = UserVehicle;