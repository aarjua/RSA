const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");

const UserBankDetail = sequelize.define('driver_bank_details', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  profile_id: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
        model: "profiles",
        key: "id",
      }, 
  },
  account_no: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  bank_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  bank_address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  ifsc: {
    type: DataTypes.STRING,
    allowNull: true,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

module.exports = UserBankDetail;