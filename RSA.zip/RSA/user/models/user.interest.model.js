const {
    db: {
      sequelize,
      Sequelize: { DataTypes },
    },
  } = require("../config");
  const Profile = require("./profile.model");

  const UserInterest = sequelize.define(
    "user_interests",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      profile_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: "profiles",
            key: "id",
          }, 
      },
      interest_id: {
        type: DataTypes.UUID,
        allowNull: false,
      },
    },
    {
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );

 

  module.exports = UserInterest;
  