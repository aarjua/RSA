const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../../auth/config");
const OfferRide = require("./offer_ride.model");

const RideStopver = sequelize.define(
  "ride_stopover",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    ride_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "offer_rides",
        key: "id",
      },
      onUpdate: "RESTRICT",
      onDelete: "CASCADE",
    },
    index: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
    city_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    city_address: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    latitude: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    longitude: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    price: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
    total_suggested_price: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    price_master_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    distance: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

OfferRide.hasMany(RideStopver, { as: "stopovers", foreignKey: "ride_id" });
RideStopver.belongsTo(OfferRide, { as: "stopovers", foreignKey: "ride_id" });
module.exports = RideStopver;
