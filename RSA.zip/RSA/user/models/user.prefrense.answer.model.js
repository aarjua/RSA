const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");

const UserPrefrense = require("./user.prefrense.model");
const QuestionAnswer = require("./question.answer.model");

const UserPrefrenseAnswer = sequelize.define(
  "user_prefrense_answer",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    prefrense_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "user_prefrenses",
        key: "id",
      },
      onDelete: 'CASCADE'
    },
    // profile_id: {
    //   type: DataTypes.UUID,
    //   allowNull: false,
    //   references: {
    //     model: "profiles",
    //     key: "id",
    //   },
    //   onUpdate: 'RESTRICT',
    //   onDelete: 'CASCADE'
    // },
    // question_id: {
    //   type: DataTypes.UUID,
    //   allowNull: false,
    //   references: {
    //     model: "questions",
    //     key: "id",
    //   },
    //   onUpdate: 'RESTRICT',
    //   onDelete: 'NULL'
    // },
    answer_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "question_answers",
        key: "id",
      },
      onDelete: 'CASCADE'
    },
    start_range: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    end_range: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

UserPrefrense.hasMany(UserPrefrenseAnswer, { as: "userprefrenseanswer", foreignKey: "prefrense_id" });
UserPrefrenseAnswer.belongsTo(UserPrefrense, { as: "userprefrenseanswer", foreignKey: 'prefrense_id' });

QuestionAnswer.hasMany(UserPrefrenseAnswer, { as: "useranswer", foreignKey: "answer_id" });
UserPrefrenseAnswer.belongsTo(QuestionAnswer, { as: 'useranswer', foreignKey: 'answer_id' });

module.exports = UserPrefrenseAnswer;
