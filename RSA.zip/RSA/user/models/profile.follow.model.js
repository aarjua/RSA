const {
    db: {
      sequelize,
      Sequelize: { DataTypes },
    },
  } = require("../config");
  const Profile = require("./profile.model")
  
  const ProfileFollow = sequelize.define(
    "profile-follow",
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
          },
        followed_profile: {
            type: DataTypes.UUID,
            allowNull: false,
            references: {
              model: "profiles",
              key: "id",
            },
          },
        followed_by: {
            type: DataTypes.UUID,
            allowNull: false,
            references: {
              model: "profiles",
              key: "id",
            },
          },
    },
    {
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );
  
  // ProfileFollow.belongsTo(Profile, { as: "profile-follow", foreignKey: "profile_id" });    
//belongTo
  
  module.exports = ProfileFollow;
  