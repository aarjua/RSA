const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../../auth/config");

const Profile = require("./profile.model");

const OfferRide = sequelize.define(
  "offer_ride",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    profile_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "profiles",
        key: "id",
      },
    },
    user_vehicle_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "user_vehicles",
        key: "id",
      },
      onUpdate: "RESTRICT",
      onDelete: "SET NULL",
    },
    start_city_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    start_city_address: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    start_point_latitude: {
      type: DataTypes.NUMBER,
      allowNull: false,
    },
    start_point_longitude: {
      type: DataTypes.NUMBER,
      allowNull: false,
    },
    end_city_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    end_city_address: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    end_point_latitude: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    end_point_longitude: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    country:{
      type: DataTypes.STRING,
      allowNull: true,
    },
    available_seat: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
    total_price: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
    total_suggested_price: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    price_master_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    total_distance: {
      type: DataTypes.NUMBER,
      allowNull: true,
    },
    route_description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_round_trip: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: 1,
    },
    ride_status: {
      type: DataTypes.NUMBER,
      allowNull: false,
      defaultValue: 0,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: 1,
    },
    start_time: {
      allowNull: false,
      type: DataTypes.DATE,
    },
    end_time: {
      allowNull: false,
      type: DataTypes.DATE,
    },
    round_start_time: {
      allowNull: true,
      type: DataTypes.DATE,
    },
    round_end_time: {
      allowNull: true,
      type: DataTypes.DATE,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

module.exports = OfferRide;
