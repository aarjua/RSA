const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const Question = require("./question.model");
// const Answer = require("../../settings/models/answer.model");

const QuestionAnswer = sequelize.define(
  "question_answer",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    question_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: "questions",
        key: "id",
      },
      onDelete: 'CASCADE'
    },
    range_title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    start_range: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    end_range: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: 1,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

Question.hasMany(QuestionAnswer, { as: "questionanswers", foreignKey: "question_id" });
QuestionAnswer.belongsTo(Question, { foreignKey: 'question_id' });

module.exports = QuestionAnswer;
