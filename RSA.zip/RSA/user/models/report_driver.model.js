const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const { reportDriverEnums } = require("../utils/report_driver");

const ReportDriver = sequelize.define(
  "report_driver",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    passenger_user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    ride_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "offer_rides",
        key: "id",
      },
      onUpdate: "RESTRICT",
      onDelete: "CASCADE",
    },
    reason: {
      type: DataTypes.ENUM,
      values: Object.values(reportDriverEnums),
      allowNull: true,
    },
    message: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

module.exports = ReportDriver;
