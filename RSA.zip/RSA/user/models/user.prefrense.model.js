const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");

const Question = require("./question.model");
const UserVehicle = require("./user.vehicle.model");

const UserPrefrense = sequelize.define(
  "user_prefrense",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    profile_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "profiles",
        key: "id",
      },
      onUpdate: 'RESTRICT',
      onDelete: 'CASCADE'
    },
    user_vehicle_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: "user_vehicles",
        key: "id",
      },
      onUpdate: 'RESTRICT',
      onDelete: 'SET NULL'
    },
    question_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: "questions",
        key: "id",
      },
      onUpdate: 'RESTRICT',
      onDelete: 'CASCADE'
    },
    type: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

// UserPrefrense.associate = function(models) {
//   UserVehicle.hasMany(models.UserPrefrense, {
//     foreignKey: "client_id"
//   });
// };

Question.hasMany(UserPrefrense, { as: "userquestion", foreignKey: "question_id" });
UserPrefrense.belongsTo(Question, { as: 'userquestion', foreignKey: 'question_id' });


// UserVehicle.hasMany(UserPrefrense, { as: "uservehicles", foreignKey: "user_vehicle_id" });
// UserPrefrense.belongsTo(UserVehicle, { as: 'uservehicles', foreignKey: 'user_vehicle_id' });

module.exports = UserPrefrense;
