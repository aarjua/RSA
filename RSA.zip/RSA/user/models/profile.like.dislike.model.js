const {
    db: {
      sequelize,
      Sequelize: { DataTypes },
    },
  } = require("../config");
  const Profile = require("./profile.model")
  
  const ProfileLikeDislike = sequelize.define(
    "profile-like-dislike",
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      like_unliked_by: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
          model: "profiles",
          key: "id",
        },
      },
      profile_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
          model: "profiles",
          key: "id",
        },
      },
      is_liked: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
    },
    {
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );
  
  // Profile.hasMany(ProfileLikeDislike, { as: "profile-like-dislike", foreignKey: 'profile_id', sourceKey: 'id' });
//belongTo
  
  module.exports = ProfileLikeDislike;
  