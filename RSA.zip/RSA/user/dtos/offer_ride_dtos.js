const joi = require("joi");
const offerRideAddUpdateDtos = joi.object({
  user_vehicle_id: joi.string().uuid().required(),
  start_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_point_latitude: joi.string().required(),
  start_point_longitude: joi.string().required(),
  end_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_point_latitude: joi.string().required(),
  end_point_longitude: joi.string().required(),
  country: joi.string().optional(),
  available_seat: joi.number().required(),
  total_price: joi.number().required(),
  total_suggested_price: joi.number().optional(),
  price_master_id: joi.string().uuid().optional(),
  total_distance: joi.number().required(),
  route_description: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  is_round_trip: joi.boolean().required(),
  start_time: joi.date().required(),
  end_time: joi.date().required(),
  round_start_time: joi.date().optional(),
  round_end_time: joi.date().optional(),
  ride_status: joi.number().required(),
  is_type: joi.string().optional(),
  routes: joi
    .array()
    .items(
      joi.object({
        index: joi.number().required(),
        city_name: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .optional(),
        city_address: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .optional(),
        latitude: joi.string().required(),
        longitude: joi.string().required(),
        price: joi.number().required(),
        total_suggested_price: joi.number().optional(),
        price_master_id: joi.string().uuid().optional(),
        distance: joi.number().required(),
      })
    )
    .optional(),
});

module.exports = { offerRideAddUpdateDtos };
