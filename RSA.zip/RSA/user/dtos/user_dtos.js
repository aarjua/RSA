const joi = require("joi");
const MUUserUpdateDtos = joi.object({
    name: joi.string().trim().allow(...[null, '']).optional(),
    city: joi.string().trim().allow(...[null, '']).optional(),
    zip_code: joi.string().trim().allow(...[null, '']).optional(),
    dob: joi.date().allow(null).allow("").optional(),
    gender: joi.string().trim().allow(...[null, '']).optional(),
    profile_type: joi.string().trim().optional(),
    profile_detail: joi.string().trim().allow(...[null, '']).optional(),
    address: joi.string().trim().allow(...[null, '']).optional(),
    profile: joi.string().trim().optional(),
    type: joi.string().trim().allow(...[null, '']).optional()
  })

const AUUserUpdateDtos = joi.object({
    name: joi.string().trim().allow(...[null, '']).optional(),
    city: joi.string().trim().allow(...[null, '']).optional(),
    zip_code: joi.string().trim().allow(...[null, '']).optional(),
    dob: joi.date().allow(null).allow("").optional(),
    gender: joi.string().trim().allow(...[null, '']).optional(),
    profile_type: joi.string().trim().optional(),
    profile_detail: joi.string().trim().allow(...[null, '']).optional(),
    address: joi.string().trim().allow(...[null, '']).optional(),
    profile: joi.string().trim().optional(),
    type: joi.string().trim().allow(...[null, '']).optional()
  })

module.exports = { AUUserUpdateDtos, MUUserUpdateDtos };