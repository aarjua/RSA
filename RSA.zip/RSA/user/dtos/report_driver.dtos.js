const joi = require("joi");
const { reportDriverEnums } = require("../utils/report_driver");
const reportDriverDtos = joi.object({
  profile_id: joi.string().uuid().optional(),
  user_id: joi.string().uuid().required(),
  ride_id: joi.string().uuid().required(),
  reason: joi
    .string()
    .valid(...Object.values(reportDriverEnums))
    .required(),
  message: joi.string().trim().allow(...[null, ""]).optional(),
});
module.exports = {
  reportDriverDtos,
};
