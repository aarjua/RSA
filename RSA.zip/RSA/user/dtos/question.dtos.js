const joi = require("joi");

const questionsDtos = joi.object({
  title: joi.string().required(),
  position: joi.string().required(),
  weghtage: joi.string().required(),
  answer_type: joi.string().uuid().required(),
  icon: joi.string().optional(),
  answers: joi.array().items(
    joi.object({
      range_title: joi.string().required(),
      start_range: joi.string().required(),
      end_range: joi.string().required(),
    })
  ),
});

module.exports = { questionsDtos };
