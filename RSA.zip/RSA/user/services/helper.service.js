const console = require("../config/logs.config")('yap:services:helper');
const haversine = require('haversine-distance');
const { OfferRide, Profile, UserVehicle, UserPrefrense, PassengerBooking, UserDocument } = require("../models");
const {
    Sequelize: { Op, literal },
    sequelize,
} = require("../config/db.config");

// module.exports = {
//     replaceObjectEmptyStringKeysWithNull: (obj) => replaceEmptyStringWithNull(obj),
//     filterPrefrensRecord: (rides, user_prefrense) => filterPrefrensRecord(rides, user_prefrense),
//     filterDataWithinRange: (data, startlat, startlon, endlat, endlon, rangeKm, is_round_trip, formattedDateStartTime, tenHoursInMilliseconds) => filterDataWithinRange(data, startlat, startlon, endlat, endlon, rangeKm, is_round_trip, formattedDateStartTime, tenHoursInMilliseconds),
//     sortDataWithinRange: (data, startlat, startlon, endlat, endlon, rangeKm) => sortDataWithinRange(data, startlat, startlon, endlat, endlon, rangeKm),
// }
module.exports = {
    replaceEmptyStringWithNull: (obj) => {
        if (obj === null || obj === undefined) {
            return null;
        } else if (Array.isArray(obj)) {
            return obj.map(replaceEmptyStringWithNull);
        } else if (typeof obj === 'object') {
            if (obj instanceof Date) {
                return obj;
            } else {
                return Object.keys(obj).reduce((acc, key) => {
                    acc[key] = replaceEmptyStringWithNull(obj[key]);
                    return acc;
                }, {});
            }
        } else if (obj === '') {
            return null;
        } else {
            return obj;
        }
    },

    filterDataWithinRange: (data, startlat, startlon, endlat, endlon, rangeKm, is_round_trip, formattedDateStartTime, tenHoursInMilliseconds) => {
        const matchedData = data.filter((item) => {
            const RangeInKiloMeters = rangeKm * 1000;
            if ((item.start_time >= new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds)) &&
                (item.start_time <= new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds))) {

                // Check if the distance between the main start time and the given lat/lon is within range
                const mainDistancestartPoint = haversine(
                    { latitude: startlat, longitude: startlon },
                    { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
                );

                const mainDistanceEndPointCondOne = haversine(
                    { latitude: endlat, longitude: endlon },
                    { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
                );


                const mainStartPointWithinRange = mainDistancestartPoint <= RangeInKiloMeters;
                const mainEndPointWithinRange = mainDistanceEndPointCondOne <= RangeInKiloMeters;

                if (mainStartPointWithinRange && mainEndPointWithinRange) {
                    item.close_to_arrival = mainDistancestartPoint
                    item.close_to_departure = mainDistanceEndPointCondOne
                    console.log("start distance ", mainDistancestartPoint, mainDistanceEndPointCondOne, item)

                    return true; // If the main item is within range, keep it in the result
                }



                if (item.stopovers && item.stopovers.length > 0) {
                    const stopoverWithinRange = item.stopovers.some((stopover) => {

                        const stopoverDistanceFromStartPoint = haversine(
                            { latitude: startlat, longitude: startlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );

                        const stopoverDistanceFromEndPoint = haversine(
                            { latitude: endlat, longitude: endlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        console.log("stop over distance", stopoverDistanceFromStartPoint, "endpoint", stopoverDistanceFromEndPoint)

                        const stopOverDisctanceforEndRout = stopoverDistanceFromEndPoint <= RangeInKiloMeters;
                        const stopOverDisctanceforStartRoute = stopoverDistanceFromStartPoint <= RangeInKiloMeters;
                        if (mainStartPointWithinRange && stopOverDisctanceforEndRout) {
                            item.close_to_arrival = mainDistancestartPoint
                            item.close_to_departure = stopoverDistanceFromEndPoint
                            console.log("start distance stop over first", mainStartPointWithinRange, stopOverDisctanceforEndRout)
                            return true;
                        } else if (stopOverDisctanceforStartRoute && mainEndPointWithinRange) {
                            item.close_to_arrival = stopoverDistanceFromStartPoint
                            item.close_to_departure = mainDistanceEndPointCondOne
                            console.log("start distance stop over 2", stopoverDistanceFromStartPoint, mainDistanceEndPointCondOne)
                            return true
                        } else {
                            return false
                        }


                    });
                    console.log("stopover +++ ", stopoverWithinRange)
                    if (stopoverWithinRange) {
                        return stopoverWithinRange
                    }

                    var stopoverDistanceFromStartPointForRoute;
                    var stopoverDistanceFromEndPointForRoute;
                    const stopoverWithinRangeForRouteToRouteForStart = item.stopovers.find((stopover) => {
                        stopoverDistanceFromStartPointForRoute = haversine(
                            { latitude: startlat, longitude: startlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        // return stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters;
                        if (stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters) {

                            return true
                        } else {
                            return false
                        }
                    });

                    const stopoverWithinRangeForRouteToRouteForEnd = item.stopovers.find((stopover) => {
                        stopoverDistanceFromEndPointForRoute = haversine(
                            { latitude: endlat, longitude: endlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        // return stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters ;
                        if (stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters) {
                            return true
                        } else {
                            return false
                        }
                    });

                    // console.log("start distance stop over 3+++", stopoverWithinRangeForRouteToRouteForStart, stopoverWithinRangeForRouteToRouteForEnd)

                    if (stopoverWithinRangeForRouteToRouteForStart && stopoverWithinRangeForRouteToRouteForEnd) {
                        if (stopoverWithinRangeForRouteToRouteForStart.dataValues.index < stopoverWithinRangeForRouteToRouteForEnd.dataValues.index) {
                            // console.log("start distance stop over 3", stopOverDisctanceforStartRoute, mainEndPointWithinRange)
                            item.close_to_arrival = stopoverDistanceFromStartPointForRoute
                            item.close_to_departure = stopoverDistanceFromEndPointForRoute
                            return true
                        }
                    }
                }
            }




            // Check if the distance between the main end time and the given lat/lon is within range
            // const mainDistanceEndPoint = haversine(
            //     { latitude: endlat, longitude: endlon },
            //     { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
            // );

            // const endPointRangeMeters = rangeKm * 1000;
            // const endPointMainWithinRange = mainDistanceEndPoint <= endPointRangeMeters;
            // if (endPointMainWithinRange) {
            //     console.log("end distance", mainDistanceEndPoint)

            //     const mainDistancestartPoint = haversine(
            //         { latitude: startlat, longitude: startlon },
            //         { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
            //     );

            //     item.close_to_departure = mainDistancestartPoint;
            //     item.close_to_arrival = mainDistanceEndPoint;
            //     return item; // If the main item is within range, keep it in the result
            // }




            // Check if there are stopovers and any of them are within range
            // if (item.stopovers && item.stopovers.length > 0) {
            //     const stopoverWithinRange = item.stopovers.some((stopover) => {
            //         const stopoverDistance = haversine(
            //             { latitude: endlat, longitude: endlon },
            //             { latitude: stopover.latitude, longitude: stopover.longitude }
            //         );
            //         console.log("stop over distance", stopoverDistance)
            //         const stopoverEndPointRangeMeters = rangeKm * 1000;
            //         return stopoverDistance <= stopoverEndPointRangeMeters;
            //     });
            //     return stopoverWithinRange;
            // }


            if (item.is_round_trip) {

                if ((item.round_start_time >= new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds)) &&
                    (item.round_start_time <= new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds))) {

                    const mainDistancestartPointForRound = haversine(
                        { latitude: startlat, longitude: startlon },

                        { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
                    );

                    const mainDistanceEndPointCondOneForRound = haversine(
                        { latitude: endlat, longitude: endlon },
                        { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
                    );

                    // const RangeInKiloMeters = rangeKm * 1000;
                    const mainStartPointWithinRangeForRound = mainDistancestartPointForRound <= RangeInKiloMeters;
                    const mainEndPointWithinRangeForRound = mainDistanceEndPointCondOneForRound <= RangeInKiloMeters;

                    if (mainStartPointWithinRangeForRound && mainEndPointWithinRangeForRound) {
                        console.log("start distance for reverse trip", mainDistancestartPointForRound, mainDistanceEndPointCondOneForRound)

                        return true; // If the main item is within range, keep it in the result
                    }



                    if (item.stopovers && item.stopovers.length > 0) {
                        const stopoverWithinRange = item.stopovers.some((stopover) => {

                            const stopoverDistanceFromStartPoint = haversine(
                                { latitude: endlat, longitude: endlon },
                                { latitude: stopover.latitude, longitude: stopover.longitude }
                            );

                            const stopoverDistanceFromEndPoint = haversine(
                                { latitude: startlat, longitude: startlon },
                                { latitude: stopover.latitude, longitude: stopover.longitude }
                            );
                            console.log("stop over distance for reverse trip", stopoverDistanceFromStartPoint, "endpoint", stopoverDistanceFromEndPoint)

                            const stopOverDisctanceforEndRout = stopoverDistanceFromEndPoint <= RangeInKiloMeters;
                            const stopOverDisctanceforStartRoute = stopoverDistanceFromStartPoint <= RangeInKiloMeters;

                            if (mainStartPointWithinRangeForRound && stopOverDisctanceforStartRoute) {
                                console.log("start distance stop over first for reverse", mainStartPointWithinRangeForRound, stopOverDisctanceforEndRout)
                                return true;
                            } else if (stopOverDisctanceforEndRout && mainEndPointWithinRangeForRound) {
                                console.log("start distance stop over 2 for reverse", stopoverDistanceFromStartPoint, stopOverDisctanceforEndRout)
                                return true
                            } else {
                                return false
                            }


                        });
                        console.log("stopover +++ ", stopoverWithinRange)
                        if (stopoverWithinRange) {
                            return stopoverWithinRange
                        }


                        const stopoverWithinRangeForRouteToRouteForStart = item.stopovers.find((stopover) => {
                            const stopoverDistanceFromStartPointForRoute = haversine(
                                { latitude: startlat, longitude: startlon },
                                { latitude: stopover.latitude, longitude: stopover.longitude }
                            );
                            // return stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters;
                            if (stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters) {
                                return true
                            } else {
                                return false
                            }
                        });

                        const stopoverWithinRangeForRouteToRouteForEnd = item.stopovers.find((stopover) => {
                            const stopoverDistanceFromEndPointForRoute = haversine(
                                { latitude: endlat, longitude: endlon },
                                { latitude: stopover.latitude, longitude: stopover.longitude }
                            );
                            // return stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters ;
                            if (stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters) {
                                return true
                            } else {
                                return false
                            }
                        });

                        console.log("start distance stop over 3+++ for reverse", stopoverWithinRangeForRouteToRouteForStart, stopoverWithinRangeForRouteToRouteForEnd)

                        if (stopoverWithinRangeForRouteToRouteForStart && stopoverWithinRangeForRouteToRouteForEnd) {
                            if (stopoverWithinRangeForRouteToRouteForStart.dataValues.index > stopoverWithinRangeForRouteToRouteForEnd.dataValues.index) {
                                // console.log("start distance stop over 3", stopOverDisctanceforStartRoute, mainEndPointWithinRange)
                                return true
                            }
                        }
                    }
                }

            }
            if (is_round_trip) {

                const mainDistancestartPointForRound = haversine(
                    { latitude: endlat, longitude: endlon },
                    { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
                );

                const mainDistanceEndPointCondOneForRound = haversine(
                    { latitude: startlat, longitude: startlon },
                    { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
                );

                const RangeInKiloMeters = rangeKm * 1000;
                const mainStartPointWithinRangeForRound = mainDistancestartPointForRound <= RangeInKiloMeters;
                const mainEndPointWithinRangeForRound = mainDistanceEndPointCondOneForRound <= RangeInKiloMeters;

                if (mainStartPointWithinRangeForRound && mainEndPointWithinRangeForRound) {
                    console.log("start distance for round trip", mainDistancestartPointForRound, mainDistanceEndPointCondOneForRound)

                    return true; // If the main item is within range, keep it in the result
                }



                if (item.stopovers && item.stopovers.length > 0) {
                    const stopoverWithinRange = item.stopovers.some((stopover) => {

                        const stopoverDistanceFromStartPoint = haversine(
                            { latitude: endlat, longitude: endlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );

                        const stopoverDistanceFromEndPoint = haversine(
                            { latitude: startlat, longitude: startlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        console.log("stop over distance", stopoverDistanceFromStartPoint, "endpoint", stopoverDistanceFromEndPoint)

                        const stopOverDisctanceforEndRout = stopoverDistanceFromEndPoint <= RangeInKiloMeters;
                        const stopOverDisctanceforStartRoute = stopoverDistanceFromStartPoint <= RangeInKiloMeters;

                        if (mainStartPointWithinRangeForRound && stopOverDisctanceforEndRout) {
                            console.log("start distance stop over first", mainStartPointWithinRange, stopOverDisctanceforEndRout)
                            return true;
                        } else if (stopOverDisctanceforStartRoute && mainEndPointWithinRangeForRound) {
                            console.log("start distance stop over 2", stopoverDistanceFromStartPoint, mainDistanceEndPointCondOne)
                            return true
                        } else {
                            return false
                        }


                    });
                    console.log("stopover +++ ", stopoverWithinRange)
                    if (stopoverWithinRange) {
                        return stopoverWithinRange
                    }


                    const stopoverWithinRangeForRouteToRouteForStart = item.stopovers.find((stopover) => {
                        const stopoverDistanceFromStartPointForRoute = haversine(
                            { latitude: startlat, longitude: startlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        // return stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters;
                        if (stopoverDistanceFromStartPointForRoute <= RangeInKiloMeters) {
                            return true
                        } else {
                            return false
                        }
                    });

                    const stopoverWithinRangeForRouteToRouteForEnd = item.stopovers.find((stopover) => {
                        const stopoverDistanceFromEndPointForRoute = haversine(
                            { latitude: endlat, longitude: endlon },
                            { latitude: stopover.latitude, longitude: stopover.longitude }
                        );
                        // return stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters ;
                        if (stopoverDistanceFromEndPointForRoute <= RangeInKiloMeters) {
                            return true
                        } else {
                            return false
                        }
                    });

                    console.log("start distance stop over 3+++", stopoverWithinRangeForRouteToRouteForStart, stopoverWithinRangeForRouteToRouteForEnd)

                    if (stopoverWithinRangeForRouteToRouteForStart && stopoverWithinRangeForRouteToRouteForEnd) {
                        if (stopoverWithinRangeForRouteToRouteForStart.dataValues.index > stopoverWithinRangeForRouteToRouteForEnd.dataValues.index) {
                            // console.log("start distance stop over 3", stopOverDisctanceforStartRoute, mainEndPointWithinRange)
                            return true
                        }
                    }
                }
            }




            // if (is_round_trip) {
            //     // Check if the distance between the main start time and the given lat/lon is within range for round trip 
            //     const mainDistancestartPointRound = haversine(
            //         { latitude: endlat, longitude: endlon },
            //         { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
            //     );

            //     const startPointRangeMetersRound = rangeKm * 1000;
            //     const mainStartPointWithinRangeRound = mainDistancestartPointRound <= startPointRangeMetersRound;
            //     if (mainStartPointWithinRangeRound) {
            //         console.log("start distance for round trip", mainDistancestartPointRound)
            //         return true; // If the main item is within range, keep it in the result
            //     }

            //     // Check if the distance between the main end time and the given lat/lon is within range for round trip
            //     const mainDistanceEndPointRound = haversine(
            //         { latitude: startlat, longitude: startlon },
            //         { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
            //     );

            //     const endPointRangeMetersRound = rangeKm * 1000;
            //     const endPointMainWithinRangeRound = mainDistanceEndPointRound <= endPointRangeMetersRound;
            //     if (endPointMainWithinRangeRound) {
            //         console.log("end distance for round trip", mainDistanceEndPointRound)
            //         return true; // If the main item is within range, keep it in the result
            //     }

            //     // Check if there are stopovers and any of them are within range
            //     if (item.stopovers && item.stopovers.length > 0) {
            //         const stopoverWithinRangeRound = item.stopovers.some((stopover) => {
            //             const stopoverDistanceRound = haversine(
            //                 { latitude: startlat, longitude: startlon },
            //                 { latitude: stopover.latitude, longitude: stopover.longitude }
            //             );
            //             console.log("stop over distance for round trip", stopoverDistanceRound)
            //             const stopoverEndPointRangeMetersRound = rangeKm * 1000;
            //             return stopoverDistanceRound <= stopoverEndPointRangeMetersRound;
            //         });
            //         return stopoverWithinRangeRound;
            //     }

            // }
            return false; // If neither the main item nor its stopovers are within range, exclude it from the result
        });
        // const sortData = sortDataWithinRange(matchedData, startlat, startlon, endlat, endlon, rangeKm)

        return matchedData;
    },

    sortDataWithinRange: (data, startlat, startlon, endlat, endlon, rangeKm) => {
        const matchedData = data.filter((item) => {
            // Check if the distance between the main start time and the given lat/lon is within range
            const mainDistancestartPoint = haversine(
                { latitude: startlat, longitude: startlon },
                { latitude: item.start_point_latitude, longitude: item.start_point_longitude }
            );

            const mainDistanceEndPoint = haversine(
                { latitude: endlat, longitude: endlon },
                { latitude: item.end_point_latitude, longitude: item.end_point_longitude }
            );


            if (item.stopovers && item.stopovers.length > 0) {
                const stopoverWithinRange = item.stopovers.filter((stopover) => {
                    const stopoverDistance = haversine(
                        { latitude: endlat, longitude: endlon },
                        { latitude: stopover.latitude, longitude: stopover.longitude }
                    );
                    const stopoverDistanceFromStart = haversine(
                        { latitude: startlat, longitude: startlon },
                        { latitude: stopover.latitude, longitude: stopover.longitude }
                    );
                    stopover.dataValues.close_to_departure = stopoverDistanceFromStart;
                    stopover.dataValues.close_to_arrival = stopoverDistance;
                    return stopover;
                });
                return stopoverWithinRange;
            }

            item.close_to_departure = mainDistancestartPoint;
            item.close_to_arrival = mainDistanceEndPoint;
            return item; // If the main item is within range, keep it in the result
        });
        return matchedData;
    },

    // function filterPrefrensRecord(rides, user_prefrense) {
    //     let finlRideData = [];
    //     console.log(typeof user_prefrense)
    //     const mappedData = rides.map((item) => {

    //         for (let preference of item.vehicle_detail.prefrences) {

    //             for (let userPreference of user_prefrense) {

    //                 if (userPreference.question_id === preference.question_id) {
    //                     userPreference.answers_id === preference.userprefrenseanswer[0].answer_id
    //                 } else {

    //                 }
    //             }

    //             // let matchingUserPreference = user_prefrense.find((userPreference) => {
    //             //     if (userPreference.question_id === preference.question_id) {
    //             //         userPreference.answers_id === preference.userprefrenseanswer[0].answer_id
    //             //     }
    //             // })
    //             console.log("matchingUserPreference", matchingUserPreference)
    //             // if (matchingUserPreference)

    //         }
    //     });
    //     console.log("mappeddata", mappedData)
    // }

    filterPrefrensRecord: (rides, user_prefrense) => {
        let finalRideData = [];
        const rideList = []

        let forRemoveData = []
        for (let i = 0; i < rides.length; i++) {
            const ride = rides[i];
            const vehiclePrefrences = ride.vehicle_detail.prefrences;

            const matchingPrefrences = vehiclePrefrences.filter(pref => {
                const userPref = user_prefrense.find(up => up.question_id == pref.question_id);
                if (userPref) {
                    const matchingAnswer = pref.userprefrenseanswer.find(ua => ua.answer_id == userPref.answers_id);
                    if (matchingAnswer) {
                        if (pref.userquestion.answer_type == "f3d6b9a8-21c4-4b5e-8f7d-0e9a5b3c2d1f") {
                            console.log("userPref.start_range >= matchingAnswer.dataValues.start_set_range && userPref.end_range <= matchingAnswer.dataValues.end_set_range")
                            // if (userPref.end_range >= matchingAnswer.dataValues.start_set_range && userPref.end_range <= matchingAnswer.dataValues.end_set_range) {
                            if (userPref.start_range >= matchingAnswer.dataValues.start_set_range && userPref.end_range <= matchingAnswer.dataValues.end_set_range) {
                                return true
                            } else {
                                forRemoveData.push(ride.id)
                                return false
                            }

                        } else {
                            return true
                        }

                    } else {
                        forRemoveData.push(ride.id)
                        return false
                    }
                } else {
                    return true
                }
                // return false;
            });

        }
        finalRideData = rides.filter(ride => !forRemoveData.includes(ride.id));
        finalRideData.filter((element) => {
            const isDuplicate = rideList.some(item => item.id === element.id);
            if (!isDuplicate) {
                rideList.push(element);
                return true;
            }
            return false;
        });
        return rideList
    },

    generateOTP: async () => {
        return Math.floor(1000 + Math.random() * 9000);
    },

    generateDriverDeatilObject: async (profile_id, user_vehicle_id) => {
        let profile = await Profile.findOne({
            where: {
                id: profile_id,
            },
        });

        let userRidesCount = await OfferRide.findAll({
            where: {
                profile_id: profile_id,
                ride_status: {
                    [Op.in]: [1, 2],
                },
            },
        });

        let vehicle = await UserVehicle.findOne({
            where: {
                id: user_vehicle_id,
            },
        });
        if (vehicle !== undefined) {
            var prefrenses_where = {
                profile_id: profile_id,
                user_vehicle_id: user_vehicle_id,
            };
        } else {
            var prefrenses_where = { profile_id: profile_id };
        }

        var prefrenseData = await UserPrefrense.findAll({
            // attributes: ["id", "question_id"],
            where: prefrenses_where,
            include: [
                {
                    association: "userquestion",
                    where: { is_active: true },
                    attributes: [
                        "id",
                        "title",
                        "position",
                        "weghtage",
                        "answer_type",
                        "icon",
                    ],
                    require: true,
                },
                {
                    association: "userprefrenseanswer",
                    attributes: [
                        "id",
                        "answer_id",
                        ["end_range", "end_set_range"],
                        ["start_range", "start_set_range"],
                    ],
                    include: [
                        {
                            association: "useranswer",
                            where: { is_active: true },
                            attributes: ["id", "range_title", "start_range", "end_range"],
                            // attributes: ["id"],
                            require: true,
                        },
                    ],
                },
            ],
        });

        const userverified = await UserDocument.count({
            where: {
                [Op.and]: [
                    {
                        profile_id: profile_id,
                    },
                    {
                        is_verified: 2,
                    },
                ],
            },
        });

        // TODO get dynamic drivers ratings and reviews
        let ratings = 4;
        let reviews = 10;

        let driver_detail = {
            driver_name: profile ? profile.dataValues.name : "",
            driver_image: profile ? profile.dataValues.profile_url : "",
            dob: profile ? profile.dataValues.dob : "",
            profile_detail: profile ? profile.dataValues.profile_detail : "",
            profile_type: profile ? profile.dataValues.profile_type : "",
            created_at: profile ? profile.dataValues.created_at : "",
            user_id: profile ? profile.dataValues.user_id : "",
            isGovtIdVerified: userverified ? true : false,
            ridesCount: userRidesCount.length ? userRidesCount.length : 0,
            reviews,
            ratings,
        };

        let vehicle_detail = {
            vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
            vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
            model_id: vehicle ? vehicle.dataValues.model_id : "",
            type_id: vehicle ? vehicle.dataValues.type_id : "",
            colour_id: vehicle ? vehicle.dataValues.colour_id : "",
            prefrences: prefrenseData ? prefrenseData : [],
        };

        return {
            driver_detail,
            vehicle_detail
        }
    },
    generatePassengerDeatilObject: async (profile_id) => {
        let profile = await Profile.findOne({
            where: {
                id: profile_id,
            },
        });

        let passenger_detail = {
            passager_name: profile ? profile.dataValues.name : "",
            passager_image: profile ? profile.dataValues.profile_url : "",
            dob: profile ? profile.dataValues.dob : "",
            profile_detail: profile ? profile.dataValues.profile_detail : "",
            profile_type: profile ? profile.dataValues.profile_type : "",
            created_at: profile ? profile.dataValues.created_at : "",
            user_id: profile ? profile.dataValues.user_id : "",
        };

        return {
            passenger_detail
        }
    },
    mapBookingToPaymentsForRide: (payments, bookings) => {
// console.log("payments",payments)
        const mappedAccounts = bookings.map((booking) => {
            const matchingPayment = payments.find((payment) => payment.ride_id == booking.ride_id && payment.profile_id == booking.profile_id);
            booking.payment_detail = matchingPayment ? matchingPayment : {}

            if (booking.ride_detail.dataValues.passenger_bookings.length > 0) {
                for (let passenger of booking.ride_detail.dataValues.passenger_bookings) {
                    const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == passenger.dataValues.ride_id && payment.profile_id == passenger.dataValues.profile_id);
                    passenger.dataValues.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount: {}
                }
            }
            // console.log("booking",booking)
            return booking;
        });
        return mappedAccounts;

    },
}