module.exports = {
    crypto: require("./crypto.service"),
    helper: require("./helper.service"),
    token: require("./token.service"),
    s3: require("./s3.service"),
    push: require("./push.notification.service")
    // mail: require("./mail.service"),
    // file: require("./file.service"),
    // awsMethod: require("./s3.service")
}