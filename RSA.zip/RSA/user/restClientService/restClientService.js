const axios = require("axios");
const { decryptResponseBody } = require("../services/crypto.service");

const RestClientMethodEnum = {
  GET: "GET",
  PATCH: "PATCH",
  POST: "POST",
  DELETE: "DELETE",
};
module.exports = {
  makeRestCall: async (method, url, config, body) => {
    try {
      const headers = config?.headers;
      const res = await axios.request({
        ...config,
        headers,
        url,
        data: body,
        method: method,
      });
      const response = decryptResponseBody(res.headers["iv"], res.data);
      return response.data;
      
    } catch (err) {
      console.log(`MakeRestClientCall ${url}, ${method} error: `, err);
      return err.response ? err.response : undefined;
    }
  },
  RestClientMethodEnum,
};
