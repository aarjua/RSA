module.exports = {
    logColors: {
        red: `\x1b[31m%s\x1b[0m`
    },
    userTypes: {
        admin: 'admin',
        managementFunctionUser: 'mt_fn_user',
    },
    userStatus: {
        created: 'created',
        activated: 'activated',
        deactivated: 'deactivated'
    },
    answerType: {
        singleSelect: 'c5d4a8e3-10a2-4a7b-bb1e-9c0f6e876543',
        twoeSelect: 'f3d6b9a8-21c4-4b5e-8f7d-0e9a5b3c2d1f',
        multiSelect: 'e2f4c6d8-3a1b-4c5d-9e8f-0a1b2c3d4e5f',
        range: 'd9c8b7a6-4e5d-3c2b-1a9f-8e7d6c5b4a3',
    },
    roles: {
        passenger: 'b4ce3bb1-18cd-46f4-8ad0-99ebb84bb60f',
        driver: 'c7468e01-7b57-4b43-8c7a-78b6986e8d6d',
        passengerWithDriver:'a87a54db-7350-4b5e-89f1-168386915e9b'
    },
    jwtTokenTypes: {
        accessToken: 'access_token',
        refreshToken: 'refresh_token',
        mailToken: 'mail_token'
    },
    language: { //TODO: name should be languages
        english: 'EN',
        german: 'DE'
    },
    profileType :{
        public:'public',
        private:'private'
    },
    profileStatus: {
        like: 'like',
        dislike: 'dislike'
    },
    snsTopics: {
        newUser: 'new-user'
    },
    reportsList: [
            {
                id: "reports:misinformation",
                name: "Misinformation"
            },
            {
                id: "reports:spam-misleading",
                name: "Spam or Misleading"
            },
            {
                id: "reports:violent-repulsive-content",
                name: "Violent or Repulsive Content"
            },
            {
                id: "reports:infringes-my-right",
                name: "Infringes my Right"
            },
    ],
    reports: {
        Misinformation: "Misinformation",
        Spam: "Spam or Misleading",
        ViolentOrRepulsiveContent: "Violent or Repulsive Content",
        InfringesMyRight: "Infringes my Right"
    },
}