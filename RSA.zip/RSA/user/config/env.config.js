const console = require("./logs.config")('yap:auth:env');
const dotenv = require("dotenv");
const path = require("path");

// Load environment variables from parent folder .env file.
const envPath = path.resolve(__dirname, `../../${process.env.NODE_ENV || 'development'}.env`);
console.log('user envPath:', envPath)
dotenv.config({ path: envPath });

// Load environment variables from .env file in this service directory
const envPathLocal = path.resolve(__dirname, `../${process.env.NODE_ENV || 'development'}.env`);
console.log('user envPathLocal:', envPathLocal)
dotenv.config({ path: envPathLocal });

const joi = require("joi");

const environmentVariablesSchema = joi.object({
    NODE_ENV: joi.string().trim().allow(...['development', 'testing', 'staging', 'production']).required(),
    PORT: joi.number().default(3002),
    ENDPOINT: joi.string().uri().trim().optional(),
    DB_HOST: joi.string().trim().required(),
    DB_NAME: joi.string().trim().required(),
    DB_USER: joi.string().trim().required(),
    DB_PASS: joi.string().trim().required(),
    DB_PORT: joi.number().default(3306),
    DB_DIALECT: joi.string().trim().default('mysql'),
    PAYMENT_SERVICE_URL: joi.string().uri().trim().required(),
    SETTING_SERVICE_URL: joi.string().uri().trim().required(),
    DATA_ENCRYPTION_KEY: joi.string().trim().required(),
    RESPONSE_ENCRYPTION_KEY: joi.string().trim().required(),
    JWT_ACCESS_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_ACCESS_TOKEN_SECRET shouldn't be equal to JWT_REFRESH_TOKEN_SECRET and JWT_MAIL_TOKEN_SECRET
        if (value === process.env.JWT_REFRESH_TOKEN_SECRET || value === process.env.JWT_MAIL_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_REFRESH_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_REFRESH_TOKEN_SECRET shouldn't be equal to JWT_ACCESS_TOKEN_SECRET and JWT_MAIL_TOKEN_SECRET
        if (value === process.env.JWT_ACCESS_TOKEN_SECRET || value === process.env.JWT_MAIL_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_MAIL_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_MAIL_TOKEN_SECRET shouldn't be equal to JWT_ACCESS_TOKEN_SECRET and JWT_REFRESH_TOKEN_SECRET
        if (value === process.env.JWT_ACCESS_TOKEN_SECRET || value === process.env.JWT_REFRESH_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_ACCESS_TOKEN_VALIDITY: joi.string().default('30m'),
    JWT_REFRESH_TOKEN_VALIDITY: joi.string().default('1d'),
    JWT_MAIL_TOKEN_VALIDITY: joi.string().default('5m'),
    ALLOWED_ORIGINS: joi.string().default(''),
    REQUEST_RATE_LIMIT: joi.number().default(120),
    REQUEST_RATE_LIMIT_DURATION: joi.number().default(60000),
    CMS_URL: joi.string().uri().required(),
    LOGIN_ATTEMPTS_MAX_COUNT: joi.number().default(3),
    AWS_ID: joi.string().trim().required(),
    AWS_ACCOUNT_ID: joi.string().trim().optional(),
    AWS_SECRET_KEY: joi.string().trim().required(),
    AWS_REGION: joi.string().trim().required(),
}).unknown();

const { error, value: environmentVariables } = environmentVariablesSchema.validate(process.env);
if (error) { console.error(`Environment variables validation error: ${error.message}`); process.exit(); }

module.exports = {
    ...environmentVariables,
    local: {
        username: environmentVariables.DB_USER,
        password: environmentVariables.DB_PASS,
        database: environmentVariables.DB_NAME,
        host: environmentVariables.DB_HOST,
        dialect: environmentVariables.DB_DIALECT,
        logging: false,
    }
};