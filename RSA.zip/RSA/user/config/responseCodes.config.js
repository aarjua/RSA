/**
 * SM - System
 * AU - Auth
 * UR - User
 * PF
 */

module.exports = {
  /**
   * SE - System
   */
  SE: {
    internalError: {
      code: "SE500",
      message: "internal server error",
    },
    invalidEncryptedBody: {
      code: "SE501",
      message: "invalid encrypted body or couldn't decrypt the request body",
    },
  },
  /**
   * CM -Country
   */
  CM: {
    notFound: {
      code: "CM404",
      message: "country name not found",
    },
  },
  /**
   * UI -UserInterest
   */
  UI: {
    notFound: {
      code: "UI202",
      message: "interests not found for this user",
    },
  },
  /**
   * PF - Profile
   */
  PF: {
    validations: {
      invalidBody: {
        code: "PF400",
        message: "body invalid",
      },
      invalidQuery: {
        code: "PF401",
        message: "query invalid",
      },
    },
    created: {
      code: "PF201",
      message: "created",
    },
    updated: {
      code: "PF202",
      message: "user updated",
    },
    deleted: {
      code: "PF204",
      message: "user deleted",
    },
    notFound: {
      code: "PF404",
      message: "user profile not found",
    },
    notCreated: {
      code: "PF405",
      message: " user not ceated",
    },
    forgetPasswordTimeLimit: {
      code: "PF406",
      message: "already sent , please try after 15 mins.",
    },
    vehicleUpdate: {
      code: "PF407",
      message: "vehicle details updated",
    },
    vehicleRcUpdate: {
      code: "PF412",
      message: "vehicle document updated",
    },
    vehicleCreated: {
      code: "PF408",
      message: "vehicle added",
    },
    vehicleNotFound: {
      code: "PF409",
      message: "vehicle details not found",
    },
    duplicateVehicleFound: {
      code: "PF411",
      message: "duplicate vehicle no found",
    },
    addressCreated: {
      code: "PF410",
      message: "user address added",
    },
    docCreated: {
      code: "PF413",
      message: "user document added",
    },
    docNotFound: {
      code: "PF414",
      message: "document not found",
    },
    docUpdated: {
      code: "PF415",
      message: "document updated",
    },
    vehicleRcDelete: {
      code: "PF416",
      message: "vehicle document deleted",
    },
    docDeleted: {
      code: "PF417",
      message: "document deleted",
    },
    prefrensesAdded: {
      code: "PF418",
      message: "user prefrenses added",
    },
    rcStatusUpdated: {
      code: "PF419",
      message: "vehicle status changed",
    },
    docStatusUpdated: {
      code: "PF420",
      message: "user document status changed",
    },
    vehicleDeleted: {
      code: "PF421",
      message: "user vehicle deleted",
    },
    profileStatusUpdated: {
      code: "PF423",
      message: "profile status changed",
    },
    profileNotUpdated: {
      code: "PF424",
      message: "user profile not updated",
    },
    docNotverified: {
      code: "PF425",
      message: "user document not verified",
    },
    vehicleNotverified: {
      code: "PF426",
      message: "user vehicle not verified",
    },
    roleStatusUpdated: {
      code: "PF427",
      message: "role updated",
    },
    userBankDetailsAdded: {
      code: "PF428",
      message: "user bank details added",
    },
    userBankDetailsNotFound: {
      code: "PF429",
      message: "user bank details not found",
    },
    userBankDetailsUpdated: {
      code: "PF430",
      message: "user bank details updated",
    },
    userBankDetailsDeleted: {
      code: "PF431",
      message: "user bank details deleted",
    },
    usersBankDetailsList: {
      code: "PF432",
      message: "user's bank details  list",
    },
  },
  /**
   * PF - Profile
   */
  QA: {
    validations: {
      invalidBody: {
        code: "QA400",
        message: "body invalid",
      },
      invalidQuery: {
        code: "QA401",
        message: "query invalid",
      },
      exists: {
        code: "QA409",
        message: "already exists",
      },
    },
    created: {
      code: "QA201",
      message: "created",
    },
    updated: {
      code: "QA202",
      message: "question updated",
    },
    deleted: {
      code: "QA204",
      message: "question deleted",
    },
    notFound: {
      code: "QA404",
      message: "question not found",
    },
    notCreated: {
      code: "QA405",
      message: " question not ceated",
    },
    forgetPasswordTimeLimit: {
      code: "QA406",
      message: "already sent , please try after 15 mins.",
    },
    vehicleUpdate: {
      code: "QA407",
      message: "question details updated",
    },
    vehicleCreated: {
      code: "QA408",
      message: "vehicle added",
    },
    vehicleNotFound: {
      code: "QA410",
      message: "vehicle details not added",
    },
  },
  /**
   * RA - Ride
   */
  RA: {
    validations: {
      invalidBody: {
        code: "RA400",
        message: "body invalid",
      },
      invalidQuery: {
        code: "RA401",
        message: "query invalid",
      },
      exists: {
        code: "RA409",
        message: "ride already exit for this date/time duration",
      },
      notModified: {
        code: "RA412",
        message: "ride should not be modified,please connect admin",
      },
    },
    created: {
      code: "RA201",
      message: "ride is created",
    },
    updated: {
      code: "RA202",
      message: "ride has been updated",
    },
    deleted: {
      code: "RA204",
      message: "ride deleted",
    },
    notFound: {
      code: "RA404",
      message: "ride not found",
    },
    notCreated: {
      code: "RA405",
      message: " ride not ceated",
    },
    forgetPasswordTimeLimit: {
      code: "RA406",
      message: "already sent , please try after 15 mins.",
    },
    vehicleUpdate: {
      code: "RA407",
      message: "ride details updated",
    },
    vehicleCreated: {
      code: "RA408",
      message: "vehicle added",
    },
    vehicleNotFound: {
      code: "RA410",
      message: "vehicle details not added",
    },
    rideStatusUpdated: {
      code: "RA411",
      message: "ride status updated",
    },
  },
  /**
   * PB - Passenger Bookings
   */
  PB: {
    validations: {
      invalidBody: {
        code: "PB400",
        message: "body invalid",
      },
      invalidQuery: {
        code: "PB401",
        message: "query invalid",
      },
      exists: {
        code: "PB409",
        message: "booking already exit for this date/time duration",
      },
    },
    created: {
      code: "PB201",
      message: "booking is created",
    },
    updated: {
      code: "PB202",
      message: "booking updated",
    },
    deleted: {
      code: "PB204",
      message: "booking deleted",
    },
    notFound: {
      code: "PB404",
      message: "booking not found",
    },
    notCreated: {
      code: "PB405",
      message: "booking not ceated",
    },
    forgetPasswordTimeLimit: {
      code: "PB406",
      message: "already sent , please try after 15 mins.",
    },
    vehicleUpdate: {
      code: "PB407",
      message: "question details updated",
    },
    vehicleCreated: {
      code: "PB408",
      message: "vehicle added",
    },
    vehicleNotFound: {
      code: "PB410",
      message: "vehicle details not added",
    },
    rideStatusUpdated: {
      code: "PB411",
      message: "booking status updated",
    },
    seatNotFound: {
      code: "PB412",
      message: "sorry , seat already booked. please choose another seat.",
    },
    seatReserved: {
      code: "PB413",
      message: "seat booked successfully.",
    },
    paymentFailed: {
      code: "PB414",
      message: "payment unsuccessfully.",
    },
    secretPinMatched: {
      code: "PB415",
      message: "secret pin matched successfully.",
    },
    secretPinNotMatched: {
      code: "PB416",
      message: "secret pin not matched.",
    },
    secretPinAlreayUsed: {
      code: "PB417",
      message: "secret pin already used",
    },
    secretPinExpired: {
      code: "PB418",
      message: "secret pin expired",
    },
  },
  /*
   PR 
   */
  PR: {
    created: {
      code: "PR201",
      message: "created",
    },
    notFound: {
      code: "PR404",
      message: "system user not found",
    },
    validations: {
      invalidBody: {
        code: "PR400",
        message: "body invalid",
      },
      exists: {
        code: "PR409",
        message: "already exists",
      },
    },
    profileList: {
      code: "PR203",
      message: "profile list",
    },
    profileLiked: {
      code: "PR202",
      message: "profile liked",
    },
    profileDisliked: {
      code: "PR204",
      message: "profile disliked",
    },
    profileAlreadyReported: {
      code: "PR206",
      message: "profile already reported",
    },
    profileReported: {
      code: "PR207",
      message: "profile reported",
    },
    updated: {
      code: "PR200",
      message: "updated",
    },
    alreadyLikedDisliked: {
      code: "PR205",
      message: "already like disliked",
    },
    profileFollowed: {
      code: "PR208",
      message: "profile followed",
    },
    profileUnFollowed: {
      code: "PR209",
      message: "profile unfollowed",
    },
    profileNotFollowed: {
      code: "PR210",
      message: "profile not followed",
    },
  },
  /**
   * AU - Auth
   */
  AU: {
    validations: {
      invalidBody: {
        code: "AU400",
        message: "body invalid",
      },
    },
    invalidToken: {
      code: "AU401",
      message: "invalid token",
    },
    invalidEmailOrPassword: {
      code: "AU402",
      message: "invalid email or password",
    },
    unathourizedAccess: {
      code: "AU403",
      message: "unauthorized access",
    },
    accountNotActive: {
      code: "AU405",
      message: "account not active",
    },
    verificationEmailSent: {
      code: "AU201",
      message: "verification email sent",
    },
    resetPasswordSuccess: {
      code: "AU202",
      message: "reset password success",
    },
    accountActivatedSuccess: {
      code: "AU203",
      message: "account activated success",
    },
    accountAlreadyActivated: {
      code: "AU204",
      message: "account already activated success",
    },
    contactSupportSuccess: {
      code: "AU205",
      message: "contact support mail sent",
    },
    accountBlocked: {
      code: "AU406",
      message: "account has been blocked due to max number of login attempts",
    },
    accountBlockedSuccessfully: {
      code: "AU206",
      message: "account has been blocked/unblocked successfully for login",
    },
  },
  /**
   * U - System User
   */
  UR: {
    created: {
      code: "SU201",
      message: "created",
    },
    notFound: {
      code: "SU404",
      message: "system user not found",
    },
    validations: {
      invalidBody: {
        code: "SU400",
        message: "body invalid",
      },
      exists: {
        code: "SU409",
        message: "already exists",
      },
    },
    updated: {
      code: "SU200",
      message: "updated",
    },
  },
  /**
   * Report a driver
   */
  RD: {
    exists: {
      code: "RD400",
      message: "reported driver is already exist",
    },
  },
};

(() => {
  const codes = new Set();

  const checkCodesUniqueness = (obj) => {
    for (const key in obj) {
      const code = obj[key].code;
      const message = obj[key].message;

      if (code !== undefined) {
        if (codes.has(code)) {
          throw new Error(`Duplicate code found: ${code}.`);
        } else {
          codes.add(code);
        }
      }

      if (message !== undefined && /[A-Z]/.test(message)) {
        throw new Error(`Capital letters found in message: ${message}`);
      }

      if (typeof obj[key] === "object") {
        checkCodesUniqueness(obj[key]);
      }
    }
  };

  checkCodesUniqueness(module.exports);
})();
