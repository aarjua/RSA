const console = require("../config/logs.config")(
  "yap:users:controllers:profile"
);
const joi = require("joi");
const { s3 } = require("../services");
//const { decryptResponseBody, encryptRequestBody }  = require("../services")
const { crypto } = require("../services");
const {
  Profile,
  OfferRide,
  Country,
  UserInterest,
  UserAddress,
  UserVehicle,
  UserDocument,
  UserPrefrense,
  UserPrefrenseAnswer,
  UserBankDetail,
  PassengerBooking,
} = require("../models");
const {
  responseCodes,
  enums: { roles },
  db: {
    Sequelize: { Op },
    sequelize,
  },
} = require("../config");
const { parse } = require("yamljs");
var _ = require("lodash");
const { AUUserUpdateDtos, MUUserUpdateDtos } = require("../dtos/user_dtos");
const controllers = require("../../auth/controllers");

module.exports = {
  getAll: async (req, res) => {
    try {
      console.log(req.query);
      const query = await joi
        .object({
          search: joi.string(),
          type: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi
            .string()
            .valid(...Object.keys(Profile.rawAttributes))
            .default("created_at"),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
          users: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PF.validations.invalidQuery.code });
        });

      if (!query) return;

      const {
        search,
        limit,
        page,
        sortBy = "created_at",
        orderBy = "ASC",
        profiles,
        type,
        users,
      } = query;

      const where = {
        // ...(profiles ? { id: { [Op.or]: profiles.split(",") } } : {}),
        // ...(users ? { user_id: { [Op.or]: users.split(",") } } : {}),
        // [Op.and]: [search ? { name: { [Op.like]: `%${search}%` } } : {}],
        // ...(type == "driver" && {
        //   role_change_status: {
        //     [Op.in]: [0, 1, 2,3],
        //   },
        // }),
        ...(profiles ? { id: { [Op.or]: profiles.split(",") } } : {}),
        ...(users ? { user_id: { [Op.or]: users.split(",") } } : {}),
        ...(search ? { name: { [Op.like]: `%${search}%` } } : {}),

        // ...(search ? {
        //   [Op.and]: [
        //     // [Op.or]: [
        //       { name: { [Op.like]: `%${search}%` } },
        //       // { email: { [Op.like]: `%${search}%` } },
        //       // { contact: { [Op.like]: `%${search}%` } }
        //     // ]
        //   ]
        // } : {})
        // ...(search ? { name: { [Op.like]: `%${search}%` } } : {}),
        // ...(search ? { [Op.and]: [{ name: { [Op.like]: `%${search}%` } }] } : {}),
      };
      // where.[Op.and]=
      //  console.log("search+++", search, where)
      const where_address = {
        is_active: 1,
        ...(users ? { user_id: { [Op.or]: users.split(",") } } : {}),
      };
      const [data, count, address] = await Promise.all([
        Profile.findAll({
          where,
          // include: [
          //   {
          //     association: "country",
          //     attributes: ["id", "name"],
          //   },
          // ],
          attributes: [
            "id",
            "name",
            "user_id",
            "profile_url",
            "profile_type",
            "requested_role",
            "role_change_status",
          ],
          order: [
            [sortBy, orderBy],
            // sortBy === "country.name"
            //   ? ["country", "name", orderBy]
            //   : [sortBy, orderBy],
          ],
          ...(limit && page && { limit: parseInt(limit) }),
          ...(limit &&
            page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
        }),
        Profile.count({ where }),
        UserAddress.findAll({
          where_address,
          attributes: ["id", "user_id", "address", "zip_code", "city"],
        }),
      ]);
      for (let dt of data) {
        const userDoc = await UserDocument.findAll({
          where: { profile_id: dt.id },
        });
        dt.dataValues.govtIdCount = userDoc.length > 0 ? true : false;
      }

      const mappedAddress = data.map((dt) => {
        const matchingProfilesAddress = address.filter(
          (add) => add.user_id === dt.user_id
        );
        return {
          ...dt.dataValues,
          profilesAddress:
            matchingProfilesAddress.length > 0 ? matchingProfilesAddress : null,
        };
      });

      return res.status(200).json({ data: mappedAddress, count });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  profileUrl: async (req, res) => {
    try {
      const { id } = req.params;
      // let file ;
      if (req.file) {
        const { url } = (req.body.profile_url = await s3.uploadFileToS3(
          req.file
        ));
        req.body.profile_url = url;
        //  file = await s3.uploadFileToS3(req.file);
      }

      const value = await joi
        .object({
          profile_url: joi.string(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.CP.invalidBody.code });
        });

      const profileUrl = await Profile.update(
        { profile_url: value.profile_url },
        {
          where: {
            [Op.or]: [{ id }, { user_id: id }],
          },
        }
      );
      return res.status(200).json(profileUrl);
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  get: async (req, res) => {
    try {
      const { id } = req.params;

      const profile = await Profile.findOne({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        // include: [
        //   {
        //     association: "country",
        //     attributes: ["id", "name"],
        //   },
        //   {
        //     association: "profile_like_dislike",
        //     attributes: ["id", "is_liked","like_unliked_by"]
        //   },
        // ],
        attributes: [
          "id",
          "name",
          "user_id",
          "profile_type",
          "profile_detail",
          "gender",
          "dob",
          "profile_url",
          "requested_role",
          "role_change_status",
        ],
      });

      // if (!profile) {
      //   return res.status(404).json({ code: responseCodes.PF.notFound.code });
      // }

      const address = await UserAddress.findAll({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        attributes: ["id", "city", "zip_code", "address", "is_active"],
      });

      let fullprofile;
      if (profile) {
        const vehicle = await UserVehicle.count({
          where: {
            [Op.or]: [{ id }, { profile_id: profile.dataValues.id }],
          },
        });

        const vehicleverified = await UserVehicle.count({
          where: {
            [Op.and]: [
              {
                [Op.or]: [{ id }, { profile_id: profile.dataValues.id }],
              },
              {
                rc_status: 2,
              },
            ],
          },
        });
        const userDoc = await UserDocument.count({
          where: {
            [Op.or]: [{ id }, { profile_id: profile.dataValues.id }],
          },
        });
        const userverified = await UserDocument.count({
          where: {
            [Op.and]: [
              {
                [Op.or]: [{ id }, { profile_id: profile.dataValues.id }],
              },
              {
                is_verified: 2,
              },
            ],
          },
        });
        fullprofile = profile;
        if (address) {
          // console.log(fullprofile, "fullprofile+++")
          fullprofile.dataValues.address = address;
        }
        console.log(vehicle);
        // if(vehicle){
        fullprofile.dataValues.vehicleCount = vehicle;
        fullprofile.dataValues.isVehicleVerified = vehicleverified
          ? true
          : false;
        fullprofile.dataValues.govtIdCount = userDoc;
        fullprofile.dataValues.isGovtIdVerified = userverified ? true : false;

        // }
      } else {
        fullprofile = {};
      }

      return res.json(fullprofile);
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  add: async (req, res) => {
    try {
      console.log(req.body, "body+++");
      const value = await joi
        .object({
          user_id: joi.string().uuid().required(),
          name: joi.string().trim(),
          dob: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          city: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          zip_code: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          address: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          profile: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          // user_interest: joi.array().optional()
          // profile_type: joi.string().trim(),
          // profile_url: joi.string().trim(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PF.validations.invalidBody.code });
        });

      // if (value.country_id) {
      //   const country = await Country.count({
      //     where: { id: value.country_id },
      //   });
      //   if (country < 1) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.validations.notFound.code });
      //   }
      // }
      console.log("value", value);
      const profile = await Profile.create({
        user_id: value.user_id,
        name: value.name,
        dob: value.dob,
        profile_url: value.profile ? value.profile : "",
      });
      await UserAddress.create({
        user_id: value.user_id,
        city: value.city,
        zip_code: value.zip_code,
        address: value.address,
      });

      return res.status(201).json({ id: profile.id });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;

      const getProfile = await Profile.findOne({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
      });

      if (!getProfile) {
        return res.status(200).json({ code: responseCodes.PF.notFound.code });
      }

      const passengerBookingInfoByProfileId = await PassengerBooking.findAll({
        where: {
          profile_id: getProfile.id,
        },
      });

      if(passengerBookingInfoByProfileId.length > 0 ){
        passangerBooked.forEach(async (booking)=> {
          await booking.update({ booking_status: 3});
        })
      }
      await UserAddress.destroy({
        where: {
          user_id: id,
        },
      });
      await UserPrefrense.destroy({
        where: {
          profile_id: id,
        },
      });
      await UserVehicle.destroy({
        where: {
          profile_id: id,
        },
      });
      await UserDocument.destroy({
        where: { profile_id: id },
      });

      const deletedProfile = await Profile.destroy({
        where: { id },
      });

      return res.status(200).json({ code: responseCodes.PF.deleted.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getSelf: async (req, res) => {
    try {
      const { id } = req.user;

      const profile = await Profile.findOne({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        // include: [
        //   {
        //     association: "country",
        //     attributes: ["id", "name"],
        //   },
        // ],
        attributes: ["id", "name", "gender", "dob", "user_id"],
      });

      if (!profile)
        return res.status(404).json({ code: responseCodes.PF.notFound.code });

      return res.json(profile);
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      if (req.body.type == "MU") {
        var body = await MUUserUpdateDtos.validateAsync(req.body).catch(
          (err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.PF.validations.invalidBody.code });
          }
        );
      } else {
        var body = await AUUserUpdateDtos.validateAsync(req.body).catch(
          (err) => {
            console.log("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.PF.validations.invalidBody.code });
          }
        );
      }

      if (!Object.keys(body).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.PF.updated.code });
      }

      let profileget = await Profile.findOne({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        attributes: ["id"],
      });

      if (profileget) {
        let addressget = await UserAddress.findOne({
          where: {
            [Op.or]: [{ id }, { user_id: id }],
          },
        });
        let updateobj = {};
        let updateaddressobj = {};
        if (body.name !== undefined) {
          updateobj.name = body.name;
        }
        if (body.dob !== undefined) {
          updateobj.dob = body.dob;
        }
        if (body.gender !== undefined) {
          updateobj.gender = body.gender;
        }
        if (body.profile_detail !== undefined) {
          updateobj.profile_detail = body.profile_detail;
        }
        if (body.profile !== undefined) {
          updateobj.profile_url = body.profile;
        } else {
          updateobj.profile_url = profileget.dataValues.profile_url;
        }
        if (body.profile_type) {
          updateobj.profile_type = body.profile_type;
        }
        await Profile.update(updateobj, {
          where: {
            [Op.or]: [{ id }, { user_id: id }],
          },
        });

        if (body.city !== undefined) {
          updateaddressobj.city = body.city;
        }
        if (body.zip_code !== undefined) {
          updateaddressobj.zip_code = body.zip_code;
        }
        if (body.address !== undefined) {
          updateaddressobj.address = body.address;
        }
        if (addressget) {
          await addressget.update(updateaddressobj);
        } else {
          updateaddressobj.user_id = id;
          const [address, addcreated] = await UserAddress.findOrCreate({
            where: {
              [Op.or]: [{ id }, { user_id: id }],
            },
            attributes: ["id"],
            defaults: updateaddressobj,
          });
        }

        const passengerBookingInfoByProfileId = await PassengerBooking.findAll({
          where: {
            profile_id: profileget.id,
          },
        });
  
        if(passengerBookingInfoByProfileId.length > 0 ){
          passengerBookingInfoByProfileId.forEach(async (booking)=> {
            await booking.update({ booking_status: 3});
          })
        }

        return res.json({ code: responseCodes.PF.updated.code });
      }

      const [profile, created] = await Profile.findOrCreate({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        attributes: ["id"],
        defaults: {
          user_id: id,
          name: body.name,
          dob: body.dob,
          gender: body.gender,
          profile_detail: body.profile_detail,
          profile_url: body.profile,
        },
      });
      const [address, addcreated] = await UserAddress.findOrCreate({
        where: {
          [Op.or]: [{ id }, { user_id: id }],
        },
        attributes: ["id"],
        defaults: {
          user_id: id,
          city: body.city,
          zip_code: body.zip_code,
          address: body.address,
        },
      });
      if (created) return res.json({ code: responseCodes.PF.updated.code });

      // if (body.hasOwnProperty("country_id")) {
      //   const country = await Country.count({ where: { id: body.country_id } });
      //   if (country < 1) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.validations.notFound.code });
      //   }
      // }

      return res.json({ code: responseCodes.PF.updated.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateInterest: async (req, res) => {
    try {
      const id = req.params.id;
      await UserInterest.destroy({
        where: { profile_id: id },
      });
      let { userInterests = [] } = req.body;
      for (const ids of userInterests) {
        await UserInterest.create({ interest_id: ids, profile_id: id });
      }
      return res.status(200).json({ code: responseCodes.PF.updated.code });
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getInterest: async (req, res) => {
    try {
      const id = req.params.id;
      const data = await UserInterest.findAll({
        where: { profile_id: id },
        attributes: ["interest_id"],
      });
      return res.status(200).json({ data });
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  relatedInterests: async (req, res) => {
    try {
      const query = await joi
        .object({
          limit: joi.number(),
          page: joi.number(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PF.validations.invalidQuery.code });
        });
      limit = parseInt(req.query.limit) || 15;
      page = parseInt(req.query.page) || 1;
      const offset = (page - 1) * parseInt(limit);
      if (!query) return;
      const id = req.user.id;
      let profileId = await Profile.findOne({
        where: { user_id: id },
        attributes: ["id"],
      });
      const intersets = await UserInterest.findAll({
        where: { profile_id: profileId.dataValues.id },
        attributes: ["interest_id"],
      });
      if (!intersets) {
        return res.status(200).json({ code: responseCodes.UI.notFound });
      }
      const interestIds = intersets.map(
        (interest) => interest.dataValues.interest_id
      );

      const relatedProfiles = await UserInterest.findAll({
        attributes: ["profile_id"],
        where: {
          interest_id: {
            [Op.in]: interestIds,
          },
          profile_id: {
            [Op.notIn]: [profileId.dataValues.id],
          },
        },
        group: ["profile_id"],
      });
      const relatedProfileIds = relatedProfiles.map(
        (relatedProfile) => relatedProfile.dataValues.profile_id
      );

      const data = await Profile.findAll({
        where: { id: { [Op.in]: relatedProfileIds } },
        include: [{ association: "UserInterest", attributes: ["interest_id"] }],
        order: [["created_at", "DESC"]],
        limit,
        page,
        offset,
      });
      const details = data.map((ele) => ele.dataValues);
      // const relatedUsers = await Profile.findAll({
      //   attributes: ["user_id"],
      //   where: {
      //     id: {
      //       [Op.or] :{
      //      [Op.in]: relatedProfileIds,
      //       [Op.notIn]: [id]
      //       }
      //     },
      //   },
      // });
      // const relatedUserIds = relatedUsers.map(
      //   (relatedUser) => relatedUser.dataValues.user_id
      // );

      return res.status(200).json(details);
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addCarDetail: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      // if (req.file) {
      //   const { url } = await s3.uploadFileToS3(req.file);
      //   req.body.rc = url;
      //   console.log("url", url, req.body.rc)
      //   //  file = await s3.uploadFileToS3(req.file);
      // }

      const value = await joi
        .object({
          vehicle_no: joi.string().trim().required(),
          brand_id: joi.string().uuid().required(),
          type_id: joi.string().uuid().required(),
          model_id: joi.string().uuid().required(),
          colour_id: joi.string().uuid().required(),
          // fuel_id: joi.string().uuid().required(),
          offer_seat: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          // rc: joi.string().trim().allow(...[null, '']),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const vehicleData = await UserVehicle.findOne({
        where: { vehicle_no: value.vehicle_no },
      });
      if (vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.duplicateVehicleFound.code });
      }
      let created = await UserVehicle.create({
        profile_id: profile_id,
        vehicle_no: value.vehicle_no,
        vehicle_id: value.brand_id,
        type_id: value.type_id,
        model_id: value.model_id,
        colour_id: value.colour_id,
        // fuel_id: value.fuel_id,
        offer_seat: value.offer_seat,
        // rc: value.rc
      });

      await UserVehicle.update(
        {
          is_active: 0,
        },
        {
          where: {
            id: {
              [Op.notIn]: [created.id],
            },
          },
        }
      );
      // await Profile.update({ role_change_status: 1 }, { where: { id: profile_id } });
      return res
        .status(200)
        .json({ code: responseCodes.PF.vehicleCreated.code, id: created.id });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getCarDetail: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const vehicleData = await UserVehicle.findAll({
        where: { profile_id: profile_id },
      });

      if (!vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.vehicleNotFound.code });
      }
      return res.status(200).json({ data: vehicleData });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateCarDetail: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          // profile_id: joi.string().uuid().required(),
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const value = await joi
        .object({
          brand_id: joi.string().uuid().allow(...[null, '']).optional(),
          type_id: joi.string().uuid().allow(...[null, '']).optional(),
          model_id: joi.string().uuid().allow(...[null, '']).optional(),
          colour_id: joi.string().uuid().allow(...[null, '']).optional(),
          offer_seat: joi.string().trim().allow(...[null, '']).optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const vehicleData = await UserVehicle.findOne({
        where: {
          id: id
        },
      });
      if (!vehicleData) {
        return res
          .status(400)
          .json({
            code: responseCodes.PF.vehicleNotFound.code,
            description: err,
          });
      }
      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: vehicleData.dataValues.profile_id
        }
      })
      
      offeredRideByThisUser.forEach(async (ride)=> {
        const passangerBooked = await PassengerBooking.findAll({
          where:{
            ride_id: ride.id
          }
        })
        passangerBooked.forEach(async (booking)=> {
          await booking.update({ booking_status: 3});
        })
        await ride.update({ ride_status: 0});
      })
       await UserVehicle.update({
          vehicle_id: value.brand_id,
          type_id: value.type_id,
          model_id: value.model_id,
          colour_id: value.colour_id,
          offer_seat: value.offer_seat,
        }, {
          where: {
            id: id
          }
        });

      return res.status(200).json({ code: responseCodes.PF.vehicleUpdate.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateRC: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.rc = url;
      }
      const value = await joi
        .object({
          rc_name: joi.string().optional(),
          rc: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          rc_date: joi
            .date()
            .allow(...[null, ""])
            .optional(),
          rc_description: joi
            .string()
            .allow(...[null, ""])
            .optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const vehicleData = await UserVehicle.findOne({
        where: { id: id },
      });
      if (!vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.vehicleNotFound.code });
      }
      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: vehicleData.dataValues.profile_id
        }
      })
      
      offeredRideByThisUser.forEach(async (ride)=> {
        const passangerBooked = await PassengerBooking.findAll({
          where:{
            ride_id: ride.id
          }
        })
        passangerBooked.forEach(async (booking)=> {
          await booking.update({ booking_status: 3});
        })
        await ride.update({ ride_status: 0});
      })

      await UserVehicle.update({
        rc_name:value.rc_name,
        rc: value.rc,
        rc_date: value.rc_date,
        rc_description: value.rc_description,
        rc_status: 1,
      },{
        where: {
          id: id,
        }
      }
      );
      await Profile.update(
        { requested_role: roles.driver, role_change_status: 1 },
        { where: { id: vehicleData.profile_id } }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PF.vehicleRcUpdate.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteRC: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const vehicleData = await UserVehicle.findOne({
        where: { id: id },
      });
      if (!vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.vehicleNotFound.code });
      }

      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: vehicleData.dataValues.profile_id,
        },
      });

      offeredRideByThisUser.forEach(async (ride) => {
        const passangerBooked = await PassengerBooking.findAll({
          where: {
            ride_id: ride.id,
          },
        });
        passangerBooked.forEach(async (booking) => {
          await booking.update({ booking_status: 3 });
        });
        await ride.update({ ride_status: 0 });
      });
      await UserVehicle.update(
        {
          rc: "",
          rc_date: "",
          rc_description: "",
          rc_status: 0,
        },
        {
          where: {
            id: id,
          },
        }
      );
      await Profile.update(
        { requested_role: "", role_change_status: 0 },
        { where: { id: vehicleData.profile_id } }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PF.vehicleRcDelete.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteVehicle: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const vehicleData = await UserVehicle.findOne({
        where: { id: id },
      });
      if (!vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.vehicleNotFound.code });
      }
      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: vehicleData.dataValues.profile_id
        }
      })
      
      offeredRideByThisUser.forEach(async (ride)=> {
        const passangerBooked = await PassengerBooking.findAll({
          where:{
            ride_id: ride.id
          }
        })
        passangerBooked.forEach(async (booking)=> {
          await booking.update({ booking_status: 3});
        })
        await ride.update({ ride_status: 0});
      })

      await vehicleData.destroy();
      return res
        .status(200)
        .json({ code: responseCodes.PF.vehicleDeleted.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleRCStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const vehicleData = await UserVehicle.findOne({
        where: { id: id },
      });
      if (!vehicleData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.vehicleNotFound.code });
      }

      // if (status == 2) {
      //   const profile = await Profile.findOne({
      //     where: { id: vehicleData.profile_id },
      //   });
      //   if (!profile) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.notFound.code });
      //   }
      //   if (profile.name == "") {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.profileNotUpdated.code });
      //   }
      //   const docData = await UserDocument.count({
      //     where: { profile_id: vehicleData.profile_id, is_verified: 2 },
      //   });
      //   if (docData <= 0) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.docNotverified.code });
      //   }
      // }

      await UserVehicle.update(
        { rc_status: status },
        {
          where: { id: id },
        }
      );
      // await Profile.update({ role_change_status: status }, { where: { id: vehicleData.profile_id } });
      return res
        .status(200)
        .json({ code: responseCodes.PF.rcStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleProfileStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const profileData = await Profile.findOne({
        where: { id: id },
      });
      if (!profileData) {
        return res.status(400).json({ code: responseCodes.PF.notFound.code });
      }
      // if (status == 2) {
      //   const uservehicle = await UserVehicle.count({
      //     where: { profile_id: id, rc_status: 2 },
      //   });
      //   if (uservehicle <= 0) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.vehicleNotverified.code });
      //   }
      //   const docData = await UserDocument.count({
      //     where: { profile_id: id, is_verified: 2 },
      //   });
      //   if (docData <= 0) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.docNotverified.code });
      //   }
      // }
      await Profile.update(
        { role_change_status: status, profile_type: "public" },
        { where: { id: profileData.id } }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PF.profileStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updatefinalRoleStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const profileData = await Profile.findOne({
        where: { id: id },
      });
      if (!profileData) {
        return res.status(400).json({ code: responseCodes.PF.notFound.code });
      }
      if (profileData.name == "") {
        return res
          .status(400)
          .json({ code: responseCodes.PF.profileNotUpdated.code });
      }
      if (status == 2) {
        const uservehicle = await UserVehicle.count({
          where: { profile_id: id, rc_status: 2 },
        });
        if (uservehicle <= 0) {
          return res
            .status(400)
            .json({ code: responseCodes.PF.vehicleNotverified.code });
        }
        const docData = await UserDocument.count({
          where: { profile_id: id, is_verified: 2 },
        });
        if (docData <= 0) {
          return res
            .status(400)
            .json({ code: responseCodes.PF.docNotverified.code });
        }
      }

      await Profile.update(
        {
          role_change_status: status,
          requested_role: "",
          profile_type: "public",
        },
        { where: { id: profileData.id } }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PF.roleStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addDoc: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.document = url;
        console.log("url", url, req.body.document);
        //  file = await s3.uploadFileToS3(req.file);
      }
      console.log("res body+++", req.body, req.file);
      const value = await joi
        .object({
          document: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          // document: joi.string().trim().required(),
          document_date: joi
            .date()
            .allow(...[null, ""])
            .optional(),
          first_name: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          last_name: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          document_description: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      // const vehicleData = await UserVehicle.findOne({
      //   where: { id: id },
      // });
      // if (!vehicleData) {
      //   return res
      //     .status(400)
      //     .json({ code: responseCodes.PF.vehicleNotFound.code });
      // }

      await UserDocument.create({
        profile_id: profile_id,
        first_name: value.first_name,
        last_name: value.last_name,
        document: value.document,
        document_date: value.document_date,
        document_description: value.document_description,
      });
      // await Profile.update({ role_change_status: 1 }, { where: { id: vehicleData.profile_id } });
      return res.status(200).json({ code: responseCodes.PF.docCreated.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updatedoc: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        req.body.document = url;
        console.log("url", url, req.body.document);
        //  file = await s3.uploadFileToS3(req.file);
      }
      const value = await joi
        .object({
          document: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          document_date: joi
            .date()
            .allow(...[null, ""])
            .optional(),
          first_name: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          last_name: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
          document_description: joi
            .string()
            .trim()
            .allow(...[null, ""])
            .optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const userDocData = await UserDocument.findOne({
        where: { id: id },
      });
      if (!userDocData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.docNotFound.code });
      }

      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: userDocData.dataValues.profile_id
        }
      })
      offeredRideByThisUser.forEach(async (ride)=> {
        const passangerBooked = await PassengerBooking.findAll({
          where:{
            ride_id: ride.id
          }
        })
        passangerBooked.forEach(async (booking)=> {
          await booking.update({ booking_status: 3});
        })
        await ride.update({ ride_status: 0});
      })
      await userDocData.update(value);
      // await Profile.update({ role_change_status: 1 }, { where: { id: vehicleData.profile_id } });
      return res.status(200).json({ code: responseCodes.PF.docUpdated.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getUserDoc: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const userDocData = await UserDocument.findAll({
        where: { profile_id },
      });
      if (!userDocData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.docNotFound.code });
      }

      return res.status(200).json({ data: userDocData });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleDocStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const userDocData = await UserDocument.findAll({
        where: { id },
      });
      if (!userDocData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.docNotFound.code });
      }

      // if (status == 2) {
      //   const profile = await Profile.findOne({
      //     where: { id: userDocData.profile_id },
      //   });
      //   if (!profile) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.notFound.code });
      //   }
      //   if (profile.name == "") {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.profileNotUpdated.code });
      //   }
      //   const uservehicle = await UserVehicle.count({
      //     where: { profile_id: userDocData.profile_id, is_verified: 2 },
      //   });
      //   if (uservehicle <= 0) {
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.PF.vehicleNotverified.code });
      //   }
      // }

      await UserDocument.update(
        { is_verified: status },
        {
          where: { id: id },
        }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PF.docStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteUserDoc: async (req, res) => {
    try {
      const { id } = await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const userDocData = await UserDocument.findOne({
        where: { id: id },
      });

      if (!userDocData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.docNotFound.code });
      }

      const offeredRideByThisUser = await OfferRide.findAll({
        where: {
          profile_id: userDocData.dataValues.profile_id,
        },
      });
      offeredRideByThisUser.forEach(async (ride) => {
        const passangerBooked = await PassengerBooking.findAll({
          where: {
            ride_id: ride.id,
          },
        });
        passangerBooked.forEach(async (booking) => {
          await booking.update({ booking_status: 3 });
        });
        await ride.update({ ride_status: 0 });
      });

      await userDocData.destroy();
      // await Profile.update({ role_change_status: 1 }, { where: { id: vehicleData.profile_id } });
      return res.status(200).json({ code: responseCodes.PF.docDeleted.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addUserPrefrense: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const value = await joi
        .object({
          user_prefrense: joi.array().items(
            joi.object({
              question_id: joi
                .string()
                .uuid()
                .allow(...[null, ""]),
              vehicle_id: joi
                .string()
                .uuid()
                .allow(...[null, ""])
                .optional(),
              answers: joi.array().items(
                joi.object({
                  id: joi
                    .string()
                    .uuid()
                    .allow(...[null, ""]),
                  start_range: joi.number().optional(),
                  end_range: joi.number().optional(),
                })
              ),
            })
          ),
          type: joi
            .string()
            .trim()
            .allow(...[null, ""]),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      const vehicleData = await UserVehicle.findAll({
        where: { profile_id },
      });
      // if (!vehicleData) {
      //   return res
      //     .status(400)
      //     .json({ code: responseCodes.PF.vehicleNotFound.code });
      // }
      // let ques_array = [];i
      if (req.body.type == "all") {
        if (req.body.user_prefrense.length) {
          const getuserPref = await UserPrefrense.findAll({
            where: { profile_id: profile_id },
          });
          if (getuserPref.length) {
            await UserPrefrense.destroy({
              where: { profile_id: profile_id },
            });
          }
          if (vehicleData.length) {
            for (let vehicle of vehicleData) {
              for (let row of req.body.user_prefrense) {
                var created = await UserPrefrense.create({
                  profile_id: profile_id,
                  user_vehicle_id: vehicle.id,
                  question_id: row.question_id,
                  type: req.body.type,
                });
                if (row.answers.length) {
                  for (let ans of row.answers) {
                    await UserPrefrenseAnswer.create({
                      prefrense_id: created.id,
                      answer_id: ans.id,
                      start_range: ans.start_range,
                      end_range: ans.end_range,
                    });
                  }
                }
              }
              // value.user_prefrense.map((row) => {
              //   return ques_array.push({
              //     profile_id: profile_id,
              //     vehicle_id: vehicle.id,
              //     question_id: row.question_id
              //   })
              // })
            }
            // let allrows = await UserPrefrense.bulkCreate(ques_array)
            // if (value.answers.length) {

            //   const roleAllowances = allrows.map((row) => {
            //     return {
            //       role_type: roleTypes.leadingRole,
            //       substitute_role_id: row.id,
            //       expense_allowance: value.leading_roles_expenses[0].expense_allowance,
            //       start_date: value.leading_roles_expenses[0].start_date,
            //       end_date: value.leading_roles_expenses[0].end_date,
            //     };
            //   });
            // }
          } else {
            for (let row of req.body.user_prefrense) {
              var created = await UserPrefrense.create({
                profile_id: profile_id,
                // vehicle_id: vehicle.id,
                question_id: row.question_id,
                type: req.body.type,
              });
              if (row.answers.length) {
                for (let ans of row.answers) {
                  await UserPrefrenseAnswer.create({
                    prefrense_id: created.id,
                    answer_id: ans.id,
                    start_range: ans.start_range,
                    end_range: ans.end_range,
                  });
                }
              }
            }
          }
        } else {
          return res
            .status(400)
            .send({ code: responseCodes.PF.validations.invalidBody.code });
        }
      } else {
        const getuserVehiclePref = await UserPrefrense.findAll({
          where: {
            profile_id: profile_id,
            user_vehicle_id: req.body.user_prefrense[0].vehicle_id,
          },
        });
        if (getuserVehiclePref.length) {
          // getuserVehiclePref.destroy();
          UserPrefrense.destroy({
            where: {
              profile_id: profile_id,
              user_vehicle_id: req.body.user_prefrense[0].vehicle_id,
            },
          });
        }
        for (let row of req.body.user_prefrense) {
          var created = await UserPrefrense.create({
            profile_id: profile_id,
            user_vehicle_id: row.vehicle_id,
            question_id: row.question_id,
            type: req.body.type,
          });
          if (row.answers.length) {
            for (let ans of row.answers) {
              await UserPrefrenseAnswer.create({
                prefrense_id: created.id,
                answer_id: ans.id,
                start_range: ans.start_range,
                end_range: ans.end_range,
              });
            }
          }
        }
      }

      return res
        .status(200)
        .json({ code: responseCodes.PF.prefrensesAdded.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getUserPrefrense: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });

      const { vehicle_id } = await joi
        .object({
          vehicle_id: joi.string().uuid(),
        })
        .validateAsync(req.query);

      if (vehicle_id !== undefined) {
        var where = { profile_id, user_vehicle_id: vehicle_id };
        // where.vehicle_id = req.body.vehicle_id
      } else {
        var where = { profile_id };
      }
      console.log("where", where, vehicle_id);
      const prefrenseData = await UserPrefrense.findAll({
        where,
        // group: ['vehicle_id'],
        // attributes: [[sequelize.literal('DISTINCT vehicle_id'), ]],
        include: [
          // {
          //   model: UserVehicle,
          //   // as : "uservehicle",
          //   // association: "uservehicles",
          //   attributes: ["id", "vehicle_no"],
          // },
          {
            association: "userquestion",
            attributes: [
              "id",
              "title",
              "position",
              "position",
              "answer_type",
              "icon",
            ],
          },
          {
            association: "userprefrenseanswer",
            attributes: [
              "id",
              "answer_id",
              ["start_range", "start_set_range"],
              ["end_range", "end_set_range"],
            ],
            include: [
              {
                association: "useranswer",
                attributes: ["id", "range_title", "start_range", "end_range"],
              },
            ],
          },
        ],
      });

      const vehicleData = await UserVehicle.findAll({
        where: { profile_id: profile_id },
      });

      const mappedAddress = prefrenseData.map((dt) => {
        const matchingProfilesAddress = vehicleData.filter(
          (add) => add.id === dt.user_vehicle_id
        );
        if (matchingProfilesAddress.length) {
          return {
            ...dt.dataValues,
            uservehicle: {
              id: matchingProfilesAddress[0].id,
              vehicle_no: matchingProfilesAddress[0].vehicle_no,
            },
          };
        } else {
          return {
            ...dt.dataValues,
            uservehicle: {},
          };
        }
      });
      let productcat1 = [];
      let productcat = _.chain(mappedAddress)
        .groupBy("uservehicle.id")
        .map((value, key) => {
          var vehicleno = "";
          let datavalue = JSON.stringify(value);
          let obj = JSON.parse(datavalue);

          vehicleno = obj[0].uservehicle.vehicle_no;

          productcat1.push({
            vehicle_no: vehicleno,
            id: key,
            vehicle_prefrense: value,
          });
          return productcat1;
        })
        .value();

      return res.status(200).json({ data: productcat1 });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  profileUpdate: async (req, res) => {
    try {
      const id = req.user.id;
      let image;
      if (req.file) {
        const { url } = await s3.uploadFileToS3(req.file);
        image = url;
      }
      console.log("userid", req.user.id, id);
      const profileData = await Profile.findOne({
        where: {
          user_id: id,
        },
      });
      if (!profileData) {
        return res.status(400).json({ code: responseCodes.PF.notFound.code });
      }

      await Profile.update({ profile_url: image }, { where: { user_id: id } });
      return res.status(200).json({ code: responseCodes.PF.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addAddressDetail: async (req, res) => {
    try {
      const id = req.user.id;

      const value = await joi
        .object({
          address: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          zip_code: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          city: joi
            .string()
            .trim()
            .allow(...[null, ""]),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({
              code: responseCodes.PF.validations.invalidBody.code,
              description: err,
            });
        });
      await UserAddress.create({
        user_id: id,
        address: value.address,
        zip_code: value.zip_code,
        city: value.city,
      });

      return res
        .status(200)
        .json({ code: responseCodes.PF.addressCreated.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  responseCode: async (req, res) => {
    try {
      const responseList = [];
      for (const category in responseCodes) {
        for (const key in responseCodes[category]) {
          if (key === "validations") {
            // Check if 'validations' key exists
            const validations = responseCodes[category][key];

            for (const validationKey in validations) {
              const code = validations[validationKey].code;
              const message = validations[validationKey].message;

              responseList.push({ code, message });
            }
          } else {
            const code = responseCodes[category][key].code;
            const message = responseCodes[category][key].message;

            responseList.push({ code, message });
          }
        }
      }

      return res.json({ data: responseList });
    } catch (err) {
      console.log(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getPassengerBookingList: async (req, res) => {
    try {
      const { userId } = req.params;

      const profile = await Profile.findOne({
        where: {
          user_id: userId,
        },
        attributes: ["id", "name", "gender", "dob", "user_id"],
      });

      if (!profile)
        return res.status(404).json({ code: responseCodes.PF.notFound.code });

      const passengerBookingInfoByProfileId = await PassengerBooking.findAll({
        where: {
          profile_id: profile.id,
        },
      });
      return res.json({ data: passengerBookingInfoByProfileId });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addUserBankDetails: async (req, res) => {
    try {
      const { user_id: id } = req.params;
      const profile = await Profile.findOne({
        where: {
          id: id,
        },
      });
      const value = await joi
        .object({
          bank_name: joi.string().trim(),
          account_no: joi.string().trim(),
          bank_code: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          bank_address: joi
            .string()
            .trim()
            .allow(...[null, ""]),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PF.validations.invalidBody.code });
        });

      if (!profile) {
        return res.status(404).json({ code: responseCodes.PF.notFound.code });
      } else {
        try {
          let userObj = {
              profile_id: profile.dataValues.id,
            bank_name:  crypto.encryptResponseBody(value.bank_name).body,
            account_no:  crypto.encryptResponseBody(value.account_no).body,
            bank_code:  crypto.encryptResponseBody(value.bank_code).body,
            bank_address:  crypto.encryptResponseBody(value.bank_address).body,
          }
          const data = await UserBankDetail.create(userObj);
          return res
            .status(200)
            .json({ code: responseCodes.PF.userBankDetailsAdded.code });
        } catch (error) {
          console.log("error", error);
        }
      }
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  userBankDetailsList: async (req, res) => {
    try {
      const { user_id: id } = req.params;
      const data = await UserBankDetail.findAll({
        where: {profile_id : id},
        attributes: [
          "id",
          "name",
          "profile_id",
          "bank_name",
          "bank_code",
          "account_no",
          "bank_address"
        ],
      });
      if (!data) {
        return res.status(404).json({ code: responseCodes.PF.notFound.code });
      }
      const userdata = [];
      data.map(async (item, index) => {
        let r = {
          id: item.id,
          profile_id: item.profile_id,
          bank_code: crypto.decryptRequestBody(item.bank_code),
          bank_name: crypto.decryptRequestBody(item.bank_name),
          account_no: crypto.decryptRequestBody(item.account_no),
          bank_address: crypto.decryptRequestBody(item.bank_address),
        };
        userdata.push(r);
      });
      return res
        .status(200)
        .json(userdata);
    } catch (error) {
      console.log("error", error);
    }
  },
  updateUserBankDetails: async (req, res) => {
    try {
      const { user_id: id } = req.params;
      const value = await joi
        .object({
          bank_name: joi.string().trim(),
          account_no: joi.string().trim(),
          bank_code: joi
            .string()
            .trim()
            .allow(...[null, ""]),
          bank_address: joi
            .string()
            .trim()
            .allow(...[null, ""]),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PF.validations.invalidBody.code });
        });
      const userBankData = await UserBankDetail.findOne({
        where: { id: id },
      });

      if (!userBankData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.userBankDetailsNotFound.code });
      }

      let userObjdata = {
        bank_name: crypto.encryptResponseBody(value.bank_name).body,
        account_no: crypto.encryptResponseBody(value.account_no).body,
        bank_code: crypto.encryptResponseBody(value.bank_code).body,
        bank_address: crypto.encryptResponseBody(value.bank_address).body,
      };

      const updateUserdetails = await UserBankDetail.update(userObjdata, {
        where: { id },
      });
      return res
        .status(200)
        .json({ code: responseCodes.PF.userBankDetailsUpdated.code });
    } catch (error) {
      console.error(error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteUserBankDetails: async (req, res) => {
    try {
      const { user_id: id } = req.params;

      const userBankData = await UserBankDetail.findOne({
        where: { id: id },
      });

      if (!userBankData) {
        return res
          .status(400)
          .json({ code: responseCodes.PF.userBankDetailsNotFound.code });
      }

      const deletedUserBankdetails = await UserBankDetail.destroy({
        where: { id },
      });
      return res
        .status(200)
        .json({ code: responseCodes.PF.userBankDetailsDeleted.code });
    } catch (error) {
      console.error(error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  }
};
