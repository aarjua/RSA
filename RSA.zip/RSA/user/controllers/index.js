module.exports = {
  CountryController: require("./countries.controller"),
  ProfileController: require("./profile.controller"),
  UserProfileController: require("./user.profile.controller"),
  QuestionController: require("./question.controller"),
  RideController: require("./ride.controller"),
  BookingController: require("./booking.controller"),
};
