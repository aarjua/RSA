const console = require("../config/logs.config")(
  "rsa:users:controllers:profile"
);
const {
  OfferRide,
  RideStopver,
  PassengerBooking,
  PassengerDetail,
  Profile,
  BookingHistory
} = require("../models");
const joi = require("joi");
const { responseCodes } = require("../config");
const {
  Sequelize: { Op },
} = require("../config/db.config");
const {
  helper: {
    generateOTP,
    generateDriverDeatilObject,
    generatePassengerDeatilObject,
    mapBookingToPaymentsForRide,
  },
} = require("../services");
var _ = require("lodash");
const moment = require("moment");
const {
  internalPaymentServiceRepository: {
    getPassengerRidePayment,
    updateRefundStatus,
  },
} = require("../internalServiceRepositories");

const schema = joi.object({
  ride_id: joi.string().uuid().required(),
  profile_id: joi.string().uuid().optional(),
  id: joi.string().uuid().optional(),
  start_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_point_latitude: joi.string().required(),
  start_point_longitude: joi.string().required(),
  end_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_point_latitude: joi.string().required(),
  end_point_longitude: joi.string().required(),
  distance: joi.number().required(),
  start_time: joi.date().required(),
  end_time: joi.date().optional(),
  is_round_trip: joi.boolean().required(),
  round_start_time: joi.date().optional(),
  round_end_time: joi.date().optional(),
  total_passenger: joi.number().required(),
  amount_per_person: joi.number().required().precision(2),
  total_amount: joi.number().required().precision(2),
  price_master_id: joi.string().uuid().optional(),
  payment_type: joi.string().optional(),
  booking_status: joi.number().optional().default(1),
  passenger_detail: joi
    .array()
    .items(
      joi.object({
        first_name: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .required(),
        last_name: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .optional(),
        age: joi.string().required(),
        seat_location: joi.string().optional(),
      })
    )
    .optional(),
});
const historySchema = joi.object({
  booking_id: joi.string().uuid().required(),
  title: joi.string().required(),
  sub_title: joi.string().required(),
});

module.exports = {
  get: async (req, res) => {
    try {
      const { id } = req.params;

      let booking = await PassengerBooking.findOne({
        where: {
          id,
        },
        include: [
          {
            association: "ride_detail",
            include: [
              {
                association: "stopovers",
              },
              {
                association: "passenger_bookings",
              },
            ],
          },
        ],
      });

      if (!booking)
        return res.status(400).json({ code: responseCodes.RA.notFound.code });

        booking = booking.dataValues;


      let bookingHistories = await BookingHistory.findAll({
        where: {
          booking_id: id,
        },
        order: [['created_at', 'DESC']]
      });

      booking.booking_histories = bookingHistories.length ? bookingHistories : []

      // const data = await getPassengerRidePayment(booking_data.ride_id);
      // const payments = data;

      // booking_data = mapBookingToPaymentsForRide(payments, [booking_data]);
      // let booking = booking_data[0];

      if (booking.ride_detail.dataValues.passenger_bookings.length) {
        for (let passengerBooking of booking.ride_detail.dataValues
          .passenger_bookings) {
          let passengerBookingObject = await generatePassengerDeatilObject(
            passengerBooking.profile_id
          );
          passengerBooking.dataValues.passenger_detail = passengerBookingObject
            ? passengerBookingObject.passenger_detail
            : {};
        }
      }

      let driverObject = await generateDriverDeatilObject(
        booking.ride_detail.profile_id,
        booking.ride_detail.user_vehicle_id
      );
      let passengerObject = await generatePassengerDeatilObject(
        booking.profile_id
      );

      booking.passenger_detail = passengerObject
        ? passengerObject.passenger_detail
        : {};

      booking.ride_detail.dataValues.driver_detail = driverObject
        ? driverObject.driver_detail
        : {};
      booking.ride_detail.dataValues.vehicle_detail = driverObject
        ? driverObject.vehicle_detail
        : {};
      return res.status(200).json({ data: booking });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      const {
        search,
        limit,
        page,
        sortBy = "created_at",
        orderBy = "DESC",
        booking_status,
        type,
        is_active,
        profiles,
        rides,
      } = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi
            .string()
            .valid(
              "driver_name , vehicle_no",
              ...Object.keys(PassengerBooking.rawAttributes)
            )
            .default("created_at"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          booking_status: joi.string(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
          rides: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query);
        console.log(booking_status, "booking status");
      let where = {
        ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        ...(rides ? { ride_id: { [Op.or]: rides.split(",") } } : {}),
        ...(type
          ? {
            ...(type == 1
              ? { end_time: { [Op.gte]: new Date() } }
              : { end_time: { [Op.lt]: new Date() } }),
          }
          : {}),
        ...(typeof is_active === "boolean" && { is_active }),
        [Op.and]: [
          search
            ? {
              [Op.or]: [
                // {
                //   "ride_detail.start_city_name": { [Op.like]: `%${search}%` },
                // },
                // {
                //   "ride_detail.start_city_address": {
                //     [Op.like]: `%${search}%`,
                //   },
                // },
                // { "ride_detail.end_city_name": { [Op.like]: `%${search}%` } },
                // {
                //   "ride_detail.end_city_address": {
                //     [Op.like]: `%${search}%`,
                //   },
                // },
              ],
            }
            : {},
        ],
        // is_active: 1
      };
      let Payment_where = {};
      if (booking_status && booking_status == "waiting") {
        where.booking_status = { [Op.in]: [1] };
      } else if (booking_status && booking_status == "accepted") {
        where.booking_status = { [Op.in]: [2, 4] };
      } else if (booking_status && booking_status == "rejected") {
        where.booking_status = { [Op.in]: [3, 5] };
      } else if (booking_status && booking_status == "payment_success") {
        Payment_where.payment_status = { [Op.in]: [1] };
      } else if (booking_status && booking_status == "payment_fail") {
        Payment_where.payment_status = { [Op.in]: [2] };
      }

      let bookings = await PassengerBooking.findAll({
        where,
        include: [
          {
            association: "ride_detail",
            include: [
              {
                association: "stopovers",
              },
              {
                association: "passenger_bookings",
              },
            ],
          },
        ],
        ...(sortBy != "driver_name" && sortBy != "vehicle_no"
          ? { order: [[sortBy, orderBy]] }
          : {}),
        ...(limit && page && { limit: parseInt(limit) }),
        ...(limit &&
          page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
      });

      bookings = bookings.map((item) => item.dataValues);

      for (let booking of bookings) {
        if (booking.ride_detail.dataValues.passenger_bookings.length) {
          for (let passengerBooking of booking.ride_detail.dataValues
            .passenger_bookings) {
            let passengerBookingObject = await generatePassengerDeatilObject(
              passengerBooking.profile_id
            );
            passengerBooking.dataValues.passenger_detail =
              passengerBookingObject
                ? passengerBookingObject.passenger_detail
                : {};
          }
        }

        let driverObject = await generateDriverDeatilObject(
          booking.ride_detail.profile_id,
          booking.ride_detail.user_vehicle_id
        );
        let passengerObject = await generatePassengerDeatilObject(
          booking.profile_id
        );

        booking.passenger_detail = passengerObject
          ? passengerObject.passenger_detail
          : {};

        booking.ride_detail.dataValues.driver_detail = driverObject
          ? driverObject.driver_detail
          : {};
        booking.ride_detail.dataValues.vehicle_detail = driverObject
          ? driverObject.vehicle_detail
          : {};
      }
      const count = await PassengerBooking.count({
        where: {
          ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        },
      });
      if (type == 2) {
        bookings = _.chain(bookings)
          .groupBy((item) => moment(item.created_at).format("YYYY-MM"))
          .map((value, key) => ({
            date: moment(value[0].created_at).format("YYYY-MM-DD HH:mm:ss"),
            data: value,
          }))
          .value();
      }

      return res.status(200).json({ data: bookings, count });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  add: async (req, res) => {
    try {
      let ride = await OfferRide.findOne({
        where: {
          id: req.body.ride_id,
        },
      });

      if (!ride) {
        return res.status(400).json({ code: responseCodes.RA.notFound.code });
      }

      const profiledata = await Profile.findOne({
        where: {
          id: ride.profile_id
        },
      });
      let activePassengerBookings = await PassengerBooking.findAll({
        where: {
          ride_id: req.body.ride_id,
          is_active: true,
          booking_status: {
            [Op.notIn]: [6],
          },
        },
        include: [
          {
            association: "ride_detail",
          },
        ],
      });
      let totalPassenger = 0;
      let availableSeats = ride.available_seat;

      if (activePassengerBookings.length) {
        const activePassengerBookingsWithSuccesSTatus = activePassengerBookings.filter(
          (booking) => booking.is_active === true && (booking.booking_status == 1 || booking.booking_status == 2 || booking.booking_status == 4)
        )

        totalPassenger = activePassengerBookingsWithSuccesSTatus.reduce(
          (sum, booking) => sum + booking.total_passenger,
          0
        );
        availableSeats = availableSeats - totalPassenger;
      }
      return res
        .status(200)
        .json({ data: { availableSeats: availableSeats, ride: ride, user_id: profiledata ? profiledata?.user_id : "" } });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      console.error("error:");
      const { error, value } = schema.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res
          .status(400)
          .json({ code: responseCodes.PB.validations.invalidBody.code });
      }
      const { id } = req.params;

      const booking = await PassengerBooking.findOne({ where: { id } });
      if (!booking) {
        return res.status(404).json({ code: responseCodes.PB.notFound.code });
      }

      await booking.update(value);

      if (value.passenger_detail && value.passenger_detail.length) {
        await PassengerDetail.destroy({ where: { booking_id: id } });
        let passenger_array = value.passenger_detail.map((passenger) => {
          return {
            booking_id: id,
            first_name: passenger.first_name,
            last_name: passenger.last_name,
            age: passenger.age,
            seat_location: passenger.seat_location,
          };
        });
        await PassengerDetail.bulkCreate(passenger_array);
      }
      return res.json({ code: responseCodes.PB.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const ride = await OfferRide.findOne({ where: { id: req.params.id } });
      if (!ride) {
        return res.status(404).json({ code: responseCodes.QA.notFound.code });
      }
      await OfferRide.destroy({ where: { id: req.params.id } });
      await RideStopver.destroy({
        where: {
          ride_id: req.params.id,
        },
      });
      return res.status(200).json({ code: responseCodes.RA.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleActiveStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res.status(400).json({
            code: responseCodes.PB.validations.invalidBody.code,
            description: err,
          });
        });
      const booking = await PassengerBooking.findOne({
        where: {
          id: id,
        },
      });
      if (!booking) {
        return res.status(400).json({ code: responseCodes.PB.notFound.code });
      }

      let otpCode;
      // status will be 1= waiting, 2 = accepted by driver 3 = rejected by driver , 4 = accepted by admin , 5 = rejected by admin , 6 = cancel by passenger
      if (status == 2 || status == 4) {
        otpCode = await generateOTP();
      }
      if (status == 6) {
        const { ride_id, profile_id, id } = booking.dataValues;
        await updateRefundStatus(ride_id, profile_id, id);
      }
      await PassengerBooking.update(
        {
          booking_status: status,
          secret_pin: otpCode ? otpCode : booking.secret_pin,
          secret_pin_status: otpCode ? 1 : booking.secret_pin_status,
        },
        {
          where: { id: id },
        }
      );
      return res
        .status(200)
        .json({ code: responseCodes.PB.rideStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleBlockedStatus: async (req, res) => {
    try {
      await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.PB.validations.invalidBody.code });
        });
      let id = req.params.id;
      const booking = await PassengerBooking.findOne({
        where: {
          id: id,
        },
        attributes: ["is_active"],
      });
      if (!booking) {
        return res.status(200).json({ code: responseCodes.PB.notFound.code });
      }
      if (booking.dataValues.is_active == true) {
        await PassengerBooking.update(
          { is_active: false },
          {
            where: { id: req.params.id },
          }
        );
      } else {
        await PassengerBooking.update(
          { is_active: true },
          {
            where: { id: req.params.id },
          }
        );
      }
      return res
        .status(200)
        .json({ code: responseCodes.PB.rideStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  checkSecretPin: async (req, res) => {
    try {
      const { id } = req.params;
      const { secret_pin } = await joi
        .object({
          secret_pin: joi.number().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res.status(400).json({
            code: responseCodes.PB.validations.invalidBody.code,
            description: err,
          });
        });
      const booking = await PassengerBooking.findOne({
        where: {
          [Op.and]: [{ id: id }, { is_active: true }],
        },
      });
      if (!booking) {
        return res.status(400).json({ code: responseCodes.PB.notFound.code });
      }
      if (booking.dataValues.secret_pin_status === 2) {
        return res
          .status(400)
          .json({ code: responseCodes.PB.secretPinAlreayUsed.code });
      }
      if (new Date() >= new Date(
        booking.dataValues.end_time.getTime() + 8 * 60 * 60 * 1000
      )) {
        return res
          .status(400)
          .json({ code: responseCodes.PB.secretPinExpired.code });
      }
      if (secret_pin === booking.dataValues.secret_pin) {
        await PassengerBooking.update(
          {
            secret_pin_status: 2,
          },
          {
            where: {
              [Op.and]: [{ id: id }, { is_active: true }],
            },
          }
        );
        return res
          .status(200)
          .json({ code: responseCodes.PB.secretPinMatched.code });
      }
      return res
        .status(400)
        .json({ code: responseCodes.PB.secretPinNotMatched.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  createPassengerBooking: async (req, res) => {
    try {
      const { error, value } = schema.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }
      const profiledata = await Profile.findOne({
        where: {
          id: value.profile_id
        },
      });

      let passengerBookingObject = {
        id: value.id,
        ride_id: value.ride_id,
        profile_id: value.profile_id,
        start_city_name: value.start_city_name,
        start_city_address: value.start_city_address,
        start_point_latitude: value.start_point_latitude,
        start_point_longitude: value.start_point_longitude,
        end_city_name: value.end_city_name,
        end_city_address: value.end_city_address,
        end_point_latitude: value.end_point_latitude,
        end_point_longitude: value.end_point_longitude,
        distance: value.distance,
        start_time: value.start_time,
        end_time: value.end_time,
        is_round_trip: value.is_round_trip,
        total_passenger: value.total_passenger,
        amount_per_person: value.amount_per_person,
        total_amount: value.total_amount,
        booking_status: value.booking_status
      };
      if (value.is_round_trip) {
        passengerBookingObject.round_start_time = value.round_start_time;
        passengerBookingObject.round_end_time = value.round_end_time;
      }
      await PassengerBooking.create(passengerBookingObject);
      return res.status(201).json({ code: responseCodes.PB.created.code, user_id: profiledata ? profiledata?.user_id : "" });
    } catch (err) {
      console.log("availableSeats", err)
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  createBookingHistory: async (req, res) => {
    try {
      const { error, value } = historySchema.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }


      let bookingHistoryObject = {
        booking_id: value.booking_id,
        title: value.title,
        sub_title: value.sub_title,
        updated_time: new Date(),
        status: 1

      };
      console.log(bookingHistoryObject, "bookingHistoryObject")
      await BookingHistory.create(bookingHistoryObject);
      return res.status(201).json({ code: responseCodes.PB.created.code });
    } catch (err) {
      console.log(err)
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
