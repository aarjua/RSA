const { Question, QuestionAnswer } = require("../models");
const joi = require("joi");
const { responseCodes } = require("../config");
const {
  Sequelize: { Op },
} = require("../config/db.config");
const { questionsDtos } = require("../dtos/question.dtos");
const { s3 } = require("../services");

module.exports = {
  get: async (req, res) => {
    try {
      const { id } = req.params;

      let question = await Question.findOne({
        where: {
          id,
        },
        include: [
          {
            association: "questionanswers",
          },
        ],
      });

      if (!question)
        return res.status(400).json({ code: responseCodes.QA.notFound.code });
      question = question.dataValues;
      return res.status(200).json({ data: question });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      const {
        search,
        limit,
        page,
        sortBy = "weghtage",
        orderBy = "ASC",
        is_active,
      } = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi
            .string()
            .valid("title", "weghtage", "position")
            .default("weghtage"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          is_active: joi.boolean(),
        })
        .validateAsync(req.query);
      let instances = await Question.findAll({
        where: {
          ...(typeof is_active === "boolean" && { is_active }),
          [Op.and]: [
            search
              ? {
                  [Op.or]: [
                    { title: { [Op.like]: `%${search}%` } },
                    { weghtage: { [Op.like]: `%${search}%` } },
                  ],
                }
              : {},
          ],
        },
        include: [
          {
            association: "questionanswers",
          },
        ],
        order: [[sortBy, orderBy]],
        ...(limit && page && { limit: parseInt(limit) }),
        ...(limit &&
          page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
      });

      instances = instances.map((item) => item.dataValues);
      const count = await Question.count({
        where: { ...(typeof is_active === "boolean" && { is_active }) },
      });
      return res.status(200).json({ data: instances, count });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  add: async (req, res) => {
    try {
      const { error, value } = questionsDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res
          .status(400)
          .json({ code: responseCodes.QA.validations.invalidBody.code });
      }
      const questionTitle = await Question.findOne({
        where: {
          [Op.and]: [{ title: value.title }],
        },
        paranoid: true,
      });
      if (questionTitle) {
        return res
          .status(400)
          .json({ code: responseCodes.QA.validations.exists.code });
      }
      const questionSequence = await Question.findOne({
        where: {
          [Op.and]: [{ position: value.position }],
        },
        paranoid: true,
      });
      const questionStartPosition = value.position;
      const questionEndPosition = (await Question.count()) + 1;
      if (!questionSequence) {
        const { url } = await s3.uploadFileToS3(req.file);
        var question = await Question.create({
          title: value.title,
          position: value.position,
          weghtage: value.weghtage,
          answer_type: value.answer_type,
          icon: url,
        });
        if (question) {
          if (value.answers.length) {
            let answers = value.answers.map((answer) => {
              return {
                question_id: question.id,
                range_title: answer.range_title,
                start_range: +answer.start_range,
                end_range: +answer.end_range,
              };
            });
            await QuestionAnswer.bulkCreate(answers);
          }
        }
      } else {
        await Question.increment("position", {
          by: 1,
          where: {
            position: {
              [Op.between]: [questionStartPosition, questionEndPosition],
            },
          },
        });
        const { url } = await s3.uploadFileToS3(req.file);
        var question = await Question.create({
          title: value.title,
          position: +value.position,
          weghtage: +value.weghtage,
          icon: url,
        });
        if (question) {
          if (value.answers.length) {
            let answers = value.answers.map((answer) => {
              return {
                question_id: question.id,
                answer_id: answer.id,
                range_title: answer.range_title,
                start_range: +answer.start_range,
                end_range: +answer.end_range,
              };
            });
            await QuestionAnswer.bulkCreate(answers);
          }
        }
      }
      return res.status(201).json({ code: responseCodes.QA.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      console.error("error:");
      const { error, value } = questionsDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res
          .status(400)
          .json({ code: responseCodes.QA.validations.invalidBody.code });
      }
      const { id } = req.params;

      const question = await Question.findOne({ where: { id } });
      if (!question) {
        return res.status(404).json({ code: responseCodes.QA.notFound.code });
      }

      const sameQuestionWithNameExists = await Question.findOne({
        where: { title: value.title, id: { [Op.ne]: id } },
        attributes: ["id", "title", "position"],
      });
      if (sameQuestionWithNameExists) {
        return res
          .status(400)
          .json({ code: responseCodes.QA.validations.exists.code });
      }

      const questionSequence = await Question.findOne({
        where: { position: value.position },
      });
      if (question.id != questionSequence.id) {
        const oldQuestionPosition = Number(question.dataValues.position);
        const currentQuestionPosition = Number(+value.position);

        if (oldQuestionPosition > currentQuestionPosition) {
          await Question.increment("position", {
            by: 1,
            where: {
              position: {
                [Op.between]: [currentQuestionPosition, oldQuestionPosition],
              },
            },
          });
        } else {
          await Question.decrement("position", {
            by: 1,
            where: {
              position: {
                [Op.between]: [oldQuestionPosition, currentQuestionPosition],
              },
            },
          });
        }
      }
      let url;
      if(req.file){
        url = await s3.uploadFileToS3(req.file);
        await question.update({ ...value,icon: url.url });
      }
      else{
        await question.update({ ...value,...(value.icon && { icon: url.url })});
      }
      await QuestionAnswer.destroy({ where: { question_id: id } });
      if (value.answers.length) {
        let answers = value.answers.map((answer) => {
          return {
            question_id: id,
            answer_id: answer.id,
            range_title: answer.range_title,
            start_range: +answer.start_range,
            end_range: +answer.end_range,
          };
        });
        await QuestionAnswer.bulkCreate(answers);
      }

      return res.json({ code: responseCodes.QA.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const question = await Question.findOne({ where: { id: req.params.id } });
      if (!question) {
        return res.status(404).json({ code: responseCodes.QA.notFound.code });
      }

      const roleStartPosition = Number(question.dataValues.position) + 1;
      const roleEndPosition = await Question.count();

      await Question.decrement("position", {
        by: 1,
        where: {
          position: {
            [Op.between]: [roleStartPosition, roleEndPosition],
          },
        },
      });

      await Question.destroy({ where: { id: req.params.id } });
      await QuestionAnswer.destroy({
        where: {
          question_id: req.params.id,
        },
      });
      return res.status(200).json({ code: responseCodes.QA.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getLatestPosition: async (req, res) => {
    try {
      const result = await Question.findOne({
        order: [["position", "DESC"]],
        attributes: ["position"],
      });
      if (result && result.position) {
        const { position } = result;
        return res.json({ position: position ? Number(position) : 1 });
      } else {
        return res.json({ position: 1 });
      }
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleActiveStatus: async (req, res) => {
    try {
      await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.QA.validations.invalidBody.code });
        });
      let quesId = req.params.id;
      const question = await Question.findOne({
        where: {
          id: quesId,
        },
        attributes: ["is_active"],
      });
      if (!question) {
        return res.status(200).json({ code: responseCodes.QA.notFound.code });
      }
      if (question.dataValues.is_active == true) {
        await Question.update(
          { is_active: false },
          {
            where: { id: req.params.id },
          }
        );
        await QuestionAnswer.update(
          { is_active: false },
          {
            where: { question_id: req.params.id },
          }
        );
      } else {
        await Question.update(
          { is_active: true },
          {
            where: { id: req.params.id },
          }
        );
        await QuestionAnswer.update(
          { is_active: true },
          {
            where: { question_id: req.params.id },
          }
        );
      }
      return res.status(200).json({ code: responseCodes.QA.created.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
