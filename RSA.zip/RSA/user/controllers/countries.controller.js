const {
  Sequelize: { Op },
} = require("../config/db.config");
const { Country } = require("../models");
const { responseCodes } = require("../config");

module.exports = {
  getAll: async (req, res) => {
    try {
      const countryList = await Country.findAll({order: [
        ['currency_name', 'ASC'],
    ]},);
      
      return res.status(200).json(countryList);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
