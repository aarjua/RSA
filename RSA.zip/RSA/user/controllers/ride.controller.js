const console = require("../config/logs.config")(
  "rsa:users:controllers:profile"
);
const {
  OfferRide,
  RideStopver,
  Profile,
  UserVehicle,
  UserPrefrense,
  UserDocument,
  PassengerBooking,
  ReportDriver,
} = require("../models");
const joi = require("joi");
const { responseCodes } = require("../config");
const {
  Sequelize: { Op, literal },
  sequelize,
} = require("../config/db.config");
const {
  helper: {
    filterDataWithinRange,
    sortDataWithinRange,
    filterPrefrensRecord,
    generateDriverDeatilObject,
    generatePassengerDeatilObject,
  },
} = require("../services");
const { offerRideAddUpdateDtos } = require("../dtos/offer_ride_dtos");
const { listSorting, getTokenFromHeader } = require("../utils/ride.common");
const { reportDriverDtos } = require("../dtos/report_driver.dtos");
const { validateAndDecodeAccessToken } = require("../services/token.service");

module.exports = {
  get: async (req, res) => {
    try {
      const { id } = req.params;

      let rides = await OfferRide.findOne({
        where: {
          id,
        },
        include: [
          {
            association: "passenger_bookings",
            include: [
              {
                association: "passenger_detail",
              },
            ],
          },
          {
            association: "stopovers",
          },
        ],
      });

      if (!rides)
        return res.status(400).json({ code: responseCodes.RA.notFound.code });

      rides = rides.dataValues;
      for (let ride of [rides]) {
        if (ride.passenger_bookings.length) {
          for (let passengerBooking of ride.passenger_bookings) {
            let passengerBookingObject = await generatePassengerDeatilObject(
              passengerBooking.profile_id
            );
            passengerBooking.dataValues.passenger_detail =
              passengerBookingObject
                ? passengerBookingObject.passenger_detail
                : {};
          }
        }
        let driverObject = await generateDriverDeatilObject(
          ride.profile_id,
          ride.user_vehicle_id
        );
        const passengerBookingInfoByRideId = await PassengerBooking.findAll({
          where: {
            ride_id: rides.id,
          },
        });
        ride.driver_detail = driverObject ? driverObject.driver_detail : {};
        ride.vehicle_detail = driverObject ? driverObject.vehicle_detail : {};
        ride.is_ride_booked = passengerBookingInfoByRideId.length > 0;
      }

      // const passengerBookingInfoByRideId = await PassengerBooking.findAll({
      //   where: {
      //     ride_id: rides.id,
      //   },
      // });
      // rides.is_ride_booked = passengerBookingInfoByRideId.length > 0;
      // let profile = await Profile.findOne({
      //   where: {
      //     id: rides.profile_id,
      //   },
      // });
      // let vehicle = await UserVehicle.findOne({
      //   where: {
      //     id: rides.user_vehicle_id,
      //   },
      // });

      // if (vehicle) {
      //   var prefrenses_where = {
      //     profile_id: rides.profile_id,
      //     user_vehicle_id: rides.user_vehicle_id,
      //   };
      // } else {
      //   var prefrenses_where = { profile_id: rides.profile_id };
      // }

      // let userRidesCount = await OfferRide.findAll({
      //   where: {
      //     profile_id: rides.profile_id,
      //     ride_status: {
      //       [Op.in]: [1, 2],
      //     },
      //   },
      // });

      // const userverified = await UserDocument.count({
      //   where: {
      //     [Op.and]: [
      //       {
      //         profile_id: rides.profile_id,
      //       },
      //       {
      //         is_verified: 2,
      //       },
      //     ],
      //   },
      // });
      // var prefrenseData = await UserPrefrense.findAll({
      //   where: prefrenses_where,
      //   include: [
      //     {
      //       association: "userquestion",
      //       where: { is_active: true },
      //       attributes: [
      //         "id",
      //         "title",
      //         "position",
      //         "weghtage",
      //         "answer_type",
      //         "icon",
      //       ],
      //       require: true,
      //     },
      //     {
      //       association: "userprefrenseanswer",
      //       attributes: [
      //         "id",
      //         "answer_id",
      //         ["end_range", "end_set_range"],
      //         ["start_range", "start_set_range"],
      //       ],
      //       include: [
      //         {
      //           association: "useranswer",
      //           where: { is_active: true },
      //           attributes: ["id", "range_title", "start_range", "end_range"],
      //           require: true,
      //         },
      //       ],
      //     },
      //   ],
      // });

      // // TODO get dynamic drivers ratings and reviews

      // let ratings = 4;
      // let reviews = 10;

      // let driver_detail = {
      //   driver_name: profile ? profile.dataValues.name : "",
      //   driver_image: profile ? profile.dataValues.profile_url : "",
      //   dob: profile ? profile.dataValues.dob : "",
      //   profile_detail: profile ? profile.dataValues.profile_detail : "",
      //   created_at: profile ? profile.dataValues.created_at : "",
      //   user_id: profile ? profile.dataValues.user_id : "",
      //   isGovtIdVerified: userverified ? true : false,
      //   ridesCount: userRidesCount.length ? userRidesCount.length : 0,
      //   reviews,
      //   ratings,
      // };

      // let vehicle_detail = {
      //   vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
      //   vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
      //   model_id: vehicle ? vehicle.dataValues.model_id : "",
      //   type_id: vehicle ? vehicle.dataValues.type_id : "",
      //   colour_id: vehicle ? vehicle.dataValues.colour_id : "",
      //   prefrences: prefrenseData ? prefrenseData : [],
      // };

      // rides.driver_detail = driver_detail;
      // rides.vehicle_detail = vehicle_detail;
      return res.status(200).json({ data: rides });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      const {
        search,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = req.query;
      let where = {
        ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        ...(type
          ? {
              ...(type == 1
                ? { end_time: { [Op.gte]: new Date() } }
                : { end_time: { [Op.lt]: new Date() } }),
            }
          : {}),
        ...(is_active && { is_active: is_active === "true" ? true : false }),
        ...(ride_status && { ride_status }),
      };
      let limit, page, offset;
      if (search) {
        limit = 0;
        offset = 0;
        page = 1;
      } else {
        limit = parseInt(req.query.limit);
        offset = (parseInt(req.query.page) - 1) * parseInt(req.query.limit);
        page = req.query.page;
      }

      let rides = await OfferRide.findAll({
        attributes: [
          "id",
          "profile_id",
          "user_vehicle_id",
          "start_city_name",
          "start_city_address",
          "start_point_latitude",
          "start_point_longitude",
          "end_city_name",
          "end_city_address",
          "end_point_latitude",
          "end_point_longitude",
          ["available_seat", "offered_seat"],
          "total_price",
          "total_distance",
          "route_description",
          "is_round_trip",
          "ride_status",
          "is_active",
          "start_time",
          "end_time",
          "round_start_time",
          "round_end_time",
          "created_at",
          "updated_at",
          "latitude",
          "total_suggested_price",
          "price_master_id",
        ],
        where,
        include: [
          {
            association: "passenger_bookings",
            // include: [
            //   {
            //     association: "passenger_detail",
            //   },
            // ],
          },
          {
            association: "stopovers",
          },
        ],
        ...(sortBy != "driver_name" && sortBy != "vehicle_no"
          ? { order: [[sortBy, orderBy]] }
          : {}),
        ...(limit && page && { limit: parseInt(limit) }),
        ...(limit &&
          page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
      });

      rides = rides.map((item) => item.dataValues);

      rides = rides.map((item) => {
        const activePassengerBookings = item.passenger_bookings.filter(
          (booking) =>
            booking.is_active === true &&
            (booking.booking_status == 1 ||
              booking.booking_status == 2 ||
              booking.booking_status == 4)
        );
        // console.log("activePassengerBookings",activePassengerBookings)
        const totalPassenger = activePassengerBookings.reduce(
          (sum, booking) => sum + booking.total_passenger,
          0
        );

        const available_seats = item.offered_seat - totalPassenger;
        const updatedItem = {
          ...item,
          available_seats,
        };
        return updatedItem;
      });
      for (let ride of rides) {
        if (ride.passenger_bookings.length) {
          for (let passengerBooking of ride.passenger_bookings) {
            let passengerBookingObject = await generatePassengerDeatilObject(
              passengerBooking.profile_id
            );
            passengerBooking.dataValues.passenger_detail =
              passengerBookingObject
                ? passengerBookingObject.passenger_detail
                : {};
          }
        }

        let driverObject = await generateDriverDeatilObject(
          ride.profile_id,
          ride.user_vehicle_id
        );

        //TODO : remove this details in sprint_4 release start

        let profile = await Profile.findOne({
          where: {
            id: ride.profile_id,
          },
        });
        let vehicle = await UserVehicle.findOne({
          where: {
            id: ride.user_vehicle_id,
          },
        });

        //TODO : remove this details in sprint_4 release end

        const passengerBookingInfoByRideId = await PassengerBooking.findAll({
          where: {
            ride_id: ride.id,
          },
        });
        ride.is_ride_booked = passengerBookingInfoByRideId.length > 0;
        ride.driver_detail = driverObject ? driverObject.driver_detail : {};
        ride.vehicle_detail = driverObject ? driverObject.vehicle_detail : {};

        //TODO : remove this details in sprint_4 release start

        ride.driver_name = profile ? profile.dataValues.name : "";
        ride.vehicle_no = vehicle ? vehicle.dataValues.vehicle_no : "";
        ride.vehicle_id = vehicle ? vehicle.dataValues.vehicle_id : "";
        ride.model_id = vehicle ? vehicle.dataValues.model_id : "";
        ride.type_id = vehicle ? vehicle.dataValues.type_id : "";
        ride.colour_id = vehicle ? vehicle.dataValues.colour_id : "";

        //TODO : remove this details in sprint_4 release end
      }
      let count = await OfferRide.count({
        where: {
          ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        },
      });
      if (sortBy == "vehicle_no") {
        rides.sort((a, b) => {
          const sortOrderMultiplier = orderBy == "asc" ? 1 : -1;
          return a[sortBy].localeCompare(b[sortBy]) * sortOrderMultiplier;
        });
      }
      if (sortBy == "driver_name") {
        rides = listSorting(rides, orderBy);
      }
      if (search) {
        rides = rides.filter((item) => {
          const {
            driver_name,
            vehicle_no,
            start_city_name,
            end_city_name,
            start_city_address,
            end_city_address,
          } = item;
          const keyword = search.toLowerCase();
          return (
            driver_name.toLowerCase().includes(keyword) ||
            vehicle_no.toLowerCase().includes(keyword) ||
            start_city_address.toLowerCase().includes(keyword) ||
            end_city_address.toLowerCase().includes(keyword) ||
            start_city_name.toLowerCase().includes(keyword) ||
            end_city_name.toLowerCase().includes(keyword)
          );
        });
        count = rides.length;
      }
      return res.status(200).json({ data: rides, count });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  add: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.RA.validations.invalidBody.code,
            description: err,
          });
        });
      const { error, value } = offerRideAddUpdateDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }

      let getOfferRide = await OfferRide.findAll({
        where: {
          user_vehicle_id: value.user_vehicle_id,
          start_time: {
            [Op.lte]: value.start_time,
          },
          end_time: {
            [Op.gte]: value.start_time,
          },
          ride_status: {
            [Op.in]: [0, 1],
          },
        },
      });
      if (getOfferRide.length > 0) {
        return res
          .status(400)
          .json({ code: responseCodes.RA.validations.exists.code });
      }
      let offerRideObject = {
        user_vehicle_id: value.user_vehicle_id,
        profile_id: profile_id,
        start_city_name: value.start_city_name,
        start_city_address: value.start_city_address,
        start_point_latitude: value.start_point_latitude,
        start_point_longitude: value.start_point_longitude,
        end_city_name: value.end_city_name,
        end_city_address: value.end_city_address,
        end_point_latitude: value.end_point_latitude,
        end_point_longitude: value.end_point_longitude,
        country: value.country,
        available_seat: value.available_seat,
        total_price: value.total_price,
        total_suggested_price: value.total_suggested_price,
        total_distance: value.total_distance,
        route_description: value.route_description,
        is_round_trip: value.is_round_trip,
        start_time: value.start_time,
        end_time: value.end_time,
        available_seat: value.available_seat,
        answer_type: value.answer_type,
        ride_status: value.ride_status,
        price_master_id: value.price_master_id,
      };
      if (value.is_round_trip) {
        offerRideObject.round_start_time = value.round_start_time;
        offerRideObject.round_end_time = value.round_end_time;
      }
      var ride = await OfferRide.create(offerRideObject);
      if (ride) {
        if (value.routes && value.routes.length) {
          value.routes.sort((a, b) => a.index - b.index);
          let routes_array = value.routes.map((route) => {
            return {
              ride_id: ride.id,
              index: route.index,
              city_name: route.city_name,
              city_address: route.city_address,
              latitude: route.latitude,
              longitude: route.longitude,
              price: route.price,
              total_suggested_price: route.total_suggested_price,
              price_master_id: route.price_master_id,
              distance: route.distance,
            };
          });
          await RideStopver.bulkCreate(routes_array);
        }
      }
      return res.status(201).json({ code: responseCodes.RA.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      const { error, value } = offerRideAddUpdateDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }
      const { id } = req.params;
      if (!value.is_type) {
        const passengerBookingInfoByRideId = await PassengerBooking.findAll({
          where: {
            ride_id: id,
          },
        });
        if (passengerBookingInfoByRideId.length < 0) {
          return res.status(401).json({
            code: responseCodes.RA.validations.notModified.code,
            message: responseCodes.RA.validations.notModified.message,
          });
        }
      }
      const ride = await OfferRide.findOne({ where: { id } });
      if (!ride) {
        return res.status(404).json({ code: responseCodes.RA.notFound.code });
      }

      await ride.update(value);
      await RideStopver.destroy({ where: { ride_id: id } });
      if (
        value.routes &&
        (value.routes.length > 0 || value.routes.length == 0)
      ) {
        //value.routes.sort((a, b) => a.index - b.index);
        let routes_array = value.routes.map((route) => {
          return {
            ride_id: id,
            index: route.index,
            city_name: route.city_name,
            city_address: route.city_address,
            latitude: route.latitude,
            longitude: route.longitude,
            price: route.price,
            total_suggested_price: route.total_suggested_price,
            price_master_id: route.price_master_id,
            distance: route.distance,
          };
        });
        console.log("routes_array", routes_array);
        const unique = routes_array.filter((obj, index) => {
          return index === routes_array.findIndex((o) => obj.index === o.index);
        });

        const data = unique.sort((a, b) => a.index - b.index);
        await RideStopver.bulkCreate(data);
      }
      return res.json({ code: responseCodes.RA.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const passengerBookingInfoByRideId = await PassengerBooking.findAll({
        where: {
          ride_id: id,
        },
      });
      if (passengerBookingInfoByRideId.length > 0) {
        return res.status(401).json({
          code: responseCodes.RA.validations.notModified.code,
          message: responseCodes.RA.validations.notModified.message,
        });
      }
      const ride = await OfferRide.findOne({ where: { id: req.params.id } });
      if (!ride) {
        return res.status(404).json({ code: responseCodes.QA.notFound.code });
      }
      await OfferRide.destroy({ where: { id: req.params.id } });
      await RideStopver.destroy({
        where: {
          ride_id: req.params.id,
        },
      });
      return res.status(200).json({ code: responseCodes.RA.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleActiveStatus: async (req, res) => {
    try {
      const { id, status } = await joi
        .object({
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res.status(400).json({
            code: responseCodes.QA.validations.invalidBody.code,
            description: err,
          });
        });
      const offerRide = await OfferRide.findOne({
        where: {
          id: id,
        },
      });
      if (!offerRide) {
        return res.status(400).json({ code: responseCodes.RA.notFound.code });
      }
      await OfferRide.update(
        { ride_status: status },
        {
          where: { id: id },
        }
      );
      return res
        .status(200)
        .json({ code: responseCodes.RA.rideStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleBlockedStatus: async (req, res) => {
    try {
      await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });
      let id = req.params.id;

      console.log("api", id);
      const ride = await OfferRide.findOne({
        where: {
          id: id,
        },
        attributes: ["is_active"],
      });
      if (!ride) {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
      if (ride.dataValues.is_active == true) {
        await OfferRide.update(
          { is_active: false },
          {
            where: { id: req.params.id },
          }
        );
      } else {
        await OfferRide.update(
          { is_active: true },
          {
            where: { id: req.params.id },
          }
        );
      }
      return res
        .status(200)
        .json({ code: responseCodes.RA.rideStatusUpdated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  // getAvailbleRidelistforTesting: async (req, res) => {
  //   try {
  //     const {
  //       start_city_name,
  //       start_city_address,
  //       start_point_latitude,
  //       start_point_longitude,
  //       end_city_name,
  //       end_city_address,
  //       end_point_latitude,
  //       end_point_longitude,
  //       route_description,
  //       is_round_trip,
  //       start_time,
  //       round_start_time,
  //       seats,
  //       sort_by,
  //       order_by,
  //       user_preference
  //     } = await joi
  //       .object({
  //         start_city_name: joi.string().required(),
  //         start_city_address: joi.string().required(),
  //         start_point_latitude: joi.string().required(),
  //         start_point_longitude: joi.string().required(),
  //         end_city_name: joi.string().required(),
  //         end_city_address: joi.string().required(),
  //         end_point_latitude: joi.string().required(),
  //         end_point_longitude: joi.string().required(),
  //         route_description: joi.string().required(),
  //         is_round_trip: joi.boolean().required(),
  //         start_time: joi.date().required(),
  //         round_start_time: joi.date().optional(),
  //         seats: joi.number().required(),
  //         sort_by: joi.string().valid("start_time", "total_price", "close_to_departure", "close_to_arrival").optional(),
  //         order_by: joi.string().valid("ASC", "DESC").default("ASC").optional(),
  //         user_preference: joi.array().items(joi.object({
  //           question_id: joi.string().uuid().allow(...[null, '']),
  //           answers_id: joi.string().uuid().allow(...[null, '']),
  //           end_range: joi.number().optional(),
  //           // answers: joi.array().items(joi.object({
  //           //   id: joi.string().uuid().allow(...[null, '']),
  //           //   end_range: joi.number().optional(),
  //           // }))
  //         })).optional(),
  //       })
  //       .validateAsync(req.body)
  //       .catch((err) => {
  //         console.log("err:", err);
  //         return res
  //           .status(400)
  //           .json({ code: responseCodes.RA.validations.invalidQuery.code, description: err });
  //       });

  //     const {
  //       search,
  //       limit,
  //       page,
  //       sortBy = "start_city_name",
  //       orderBy = "ASC",
  //       ride_status,
  //       type,
  //       is_active,
  //       profiles
  //     } = await joi
  //       .object({
  //         search: joi.string(),
  //         limit: joi.number().default(10),
  //         page: joi.number().default(1),
  //         sortBy: joi.string().valid("driver_name , vehicle_no", ...Object.keys(OfferRide.rawAttributes)).default("start_city_name"),
  //         orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
  //         ride_status: joi.number(),
  //         type: joi.number(),
  //         is_active: joi.boolean(),
  //         profiles: joi
  //           .string()
  //           .trim()
  //           .pattern(
  //             /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
  //           ),
  //       })
  //       .validateAsync(req.query);

  //     const tenHoursInMilliseconds = 10 * 60 * 60 * 1000;
  //     const formattedDateStartTime = new Date(start_time);
  //     formattedDateStartTime.setHours(formattedDateStartTime.getHours() + 5);
  //     formattedDateStartTime.setMinutes(formattedDateStartTime.getMinutes() + 30);

  //     const formattedDateStrRoundTime = new Date(round_start_time);
  //     formattedDateStrRoundTime.setHours(formattedDateStrRoundTime.getHours() + 5);
  //     formattedDateStrRoundTime.setMinutes(formattedDateStrRoundTime.getMinutes() + 30);

  //     let where = {
  //       // end_time: { [Op.gte]: new Date() } ,
  //       ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
  //       ...(typeof is_active === "boolean" && { is_active }),
  //       ...(ride_status && { ride_status }),
  //     }

  //     if (is_round_trip) {
  //       // If is_round_trip is true, use "OR" condition for start_time and round_start_time
  //       where[Op.or] = [
  //         {
  //           start_time: {
  //             [Op.between]: [new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds), new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)],
  //           },
  //         },
  //         {
  //           round_start_time: {
  //             [Op.between]: [new Date(formattedDateStrRoundTime.getTime() - tenHoursInMilliseconds), new Date(formattedDateStrRoundTime.getTime() + tenHoursInMilliseconds)],
  //           },
  //         },
  //       ];
  //     } else {
  //       // If is_round_trip is false, use start_time only
  //       where.start_time = {
  //         [Op.between]: [new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds), new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)],
  //       };
  //     }

  //     where.end_time= { [Op.gte]: new Date() }
  //     where.ride_status= { [Op.in]: [1,2] }
  //     console.log("where", where)

  //     let rides = await OfferRide.findAll({
  //       where,
  //       // where: {
  //       //   ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
  //       //   ...(type ? { ...(type == 1 ? { end_time: { [Op.gte]: new Date() } } : { end_time: { [Op.lt]: new Date() } }) } : {}),
  //       //   ...(typeof is_active === "boolean" && { is_active }),
  //       //   ...(ride_status && { ride_status }),
  //       //   ...(start_time && {
  //       //     start_time: {
  //       //       [Op.between]: [new Date(formattedDateStr.getTime() - tenHoursInMilliseconds), new Date(formattedDateStr.getTime() + tenHoursInMilliseconds)],
  //       //     },
  //       //   }),
  //       //   ...(is_round_trip && {
  //       //     round_start_time: {
  //       //       [Op.between]: [new Date(round_start_time - tenHoursInMilliseconds), new Date(round_start_time + tenHoursInMilliseconds)],
  //       //     },
  //       //   }),
  //       //   // [Op.and]:[literal('(SELECT COUNT(*) FROM `passenger_bookings` WHERE `passenger_bookings`.`ride_id` = `offer_rides`.`id`)')]: {
  //       //   //   [Op.lte]: seats, // Assuming `seats` is the maximum allowed count
  //       //   // },
  //       //   // [Op.and]: [literal('(SELECT COUNT(*) FROM `passenger_bookings` WHERE `passenger_bookings`.`ride_id` = `offer_rides`.`id`) <= "'+ seats +'"')],

  //       //   // [Op.and]: [start_time || is_round_trip ? {
  //       //   // [Op.or]: [
  //       //   //   { start_time: {
  //       //   //     [Op.between]: [new Date(start_time - tenHoursInMilliseconds), new Date(start_time + tenHoursInMilliseconds)],
  //       //   //   },},
  //       //   //   { round_start_time: {
  //       //   //     [Op.between]: [new Date(round_start_time - tenHoursInMilliseconds), new Date(round_start_time + tenHoursInMilliseconds)],
  //       //   //   }, },
  //       //   // ],
  //       //   // "$or": [
  //       //   //   {
  //       //   //     "end_point_latitude": end_point_latitude,
  //       //   //     "end_point_longitude": end_point_longitude
  //       //   //   },
  //       //   //   {
  //       //   //     "stopovers.latitude": end_point_latitude,
  //       //   //     "stopovers.longitude": end_point_longitude
  //       //   //   }
  //       //   // ]
  //       //   // } : {}],
  //       //   // is_active: 1
  //       // },
  //       include: [
  //         {
  //           association: "passenger_bookings",
  //           // where: { is_active: true },
  //           // required: true,
  //           include: [
  //             {
  //               association: "passenger_detail",
  //               // where: { is_active: true },
  //               // required: true,
  //             },
  //           ]
  //         },
  //         {
  //           association: "stopovers",
  //         },

  //       ],
  //       // group: ['OfferRide.id'], // Group by the primary key of OfferRide to avoid duplicates
  //       // having: sequelize.literal('COUNT(`passenger_bookings`.`id`) <= "'+ seats +'"'),
  //       // having: sequelize.literal('COUNT(`passenger_bookings`.`id`) <= "'+ seats +'"'),
  //       ...(sortBy != "driver_name" && sortBy != "vehicle_no" ? { order: [[sortBy, orderBy]] } : {}),
  //       // ...(limit && page && { limit: parseInt(limit) }),
  //       // ...(limit &&
  //       //   page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
  //     });

  //     rides = rides.map(item => {
  //       const activePassengerBookings = item.passenger_bookings.filter(booking => booking.is_active === true);
  //       // const activePassengerBookingsCount = activePassengerBookings.length ? activePassengerBookings.length : 0;
  //       const totalPassenger = activePassengerBookings.reduce((sum, booking) => sum + booking.total_passenger, 0);

  //       const availableSeats = item.available_seat - totalPassenger;
  //       const updatedItem = {
  //         ...item.dataValues,
  //         availableSeats,
  //       };
  //       return updatedItem;
  //     }).filter(item => item.availableSeats >= seats);
  //     // rides = rides.filter((ride) => ride.passenger_bookings.length >= seats);
  //     console.log("total rides ", rides.length)
  //     for (let ride of rides) {
  //       let profile = await Profile.findOne({
  //         where: {
  //           id: ride.profile_id
  //         },
  //       });

  //       let userRidesCount = await OfferRide.findAll({
  //         where: {
  //           profile_id: ride.profile_id,
  //           ride_status: {
  //             [Op.in]: [1, 2],
  //           },
  //         },
  //       });

  //       let vehicle = await UserVehicle.findOne({
  //         where: {
  //           id: ride.user_vehicle_id
  //         },
  //       });

  //       if (vehicle !== undefined) {
  //         var prefrenses_where = { profile_id: ride.profile_id, user_vehicle_id: ride.user_vehicle_id }
  //         // where.vehicle_id = req.body.vehicle_id
  //       } else {
  //         var prefrenses_where = { profile_id: ride.profile_id }
  //       }

  //       var prefrenseData = await UserPrefrense.findAll({
  //         where: prefrenses_where,
  //         include: [
  //           {
  //             association: "userquestion",
  //             where: { is_active: true },
  //             attributes: ["id", "title", "position", "weghtage", "answer_type", "icon"],
  //             require: true,

  //           },
  //           {
  //             association: "userprefrenseanswer",
  //             attributes: ["id", "answer_id", ['end_range', 'set_range']],
  //             include: [
  //               {
  //                 association: "useranswer",
  //                 where: { is_active: true },
  //                 attributes: ["id", "range_title", "start_range", "end_range"],
  //                 require: true,
  //               },
  //             ]
  //           },
  //         ],

  //       });

  //       const userverified = await UserDocument.count({
  //         where: {
  //           [Op.and]: [
  //             {
  //               profile_id: ride.profile_id,
  //             },
  //             {
  //               is_verified: 2,
  //             },
  //           ],
  //         },
  //       });

  //       // TODO get dynamic drivers ratings and reviews
  //       let ratings = 4;
  //       let reviews = 10;

  //       let driver_detail = {
  //         driver_name: profile ? profile.dataValues.name : "",
  //         driver_image: profile ? profile.dataValues.profile_url : "",
  //         dob: profile ? profile.dataValues.dob : "",
  //         profile_detail: profile ? profile.dataValues.profile_detail : "",
  //         created_at: profile ? profile.dataValues.created_at : "",
  //         user_id: profile ? profile.dataValues.user_id : "",
  //         isGovtIdVerified: userverified ? true : false,
  //         ridesCount: userRidesCount.length ? userRidesCount.length : 0,
  //         reviews,
  //         ratings
  //       }

  //       let vehicle_detail = {
  //         vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
  //         vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
  //         model_id: vehicle ? vehicle.dataValues.model_id : "",
  //         type_id: vehicle ? vehicle.dataValues.type_id : "",
  //         colour_id: vehicle ? vehicle.dataValues.colour_id : "",
  //         prefrences: prefrenseData ? prefrenseData : []
  //       }

  //       ride.driver_detail = driver_detail
  //       ride.vehicle_detail = vehicle_detail

  //     }
  //     const count = await OfferRide.count(
  //       {
  //         where: {
  //           ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
  //         }
  //       }
  //     )

  //     if (search) {
  //       rides = rides.filter((item) => {
  //         const { driver_name, vehicle_no, start_city_name, end_city_name, start_city_address, end_city_address } = item;
  //         const keyword = search.toLowerCase();
  //         return (
  //           driver_name.toLowerCase().includes(keyword) ||
  //           vehicle_no.toLowerCase().includes(keyword) ||
  //           start_city_address.toLowerCase().includes(keyword) ||
  //           end_city_address.toLowerCase().includes(keyword) ||
  //           start_city_name.toLowerCase().includes(keyword) ||
  //           end_city_name.toLowerCase().includes(keyword)
  //         );
  //       });
  //     }
  //     // rides=  filterPrefrensRecord(rides, user_prefrense);
  //     console.log("rides data", rides)
  //     let rangeData = [];
  //     if (start_point_latitude && start_point_longitude && end_point_latitude && end_point_longitude) {
  //       rangeData = filterDataWithinRange(rides, start_point_latitude, start_point_longitude, end_point_latitude, end_point_longitude, 5, is_round_trip);
  //     }
  //     console.log("sortbyyyy", sort_by)
  //     if (sort_by == "start_time" || sort_by == "total_price" || sort_by == "close_to_departure" || sort_by == "close_to_arrival") {

  //       if (sort_by == "close_to_departure") {
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == 'asc' ? 1 : -1;
  //           return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
  //         });

  //       } else if (sort_by == "close_to_arrival") {
  //         // Sort rangeData based on close_to_arrival
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == 'asc' ? 1 : -1;
  //           return a[sort_by].localeCompare(b[sort_by]) * sortOrderMultiplier;
  //         });

  //         // Sort stopovers array based on close_to_arrival for each ride in rangeData
  //         rangeData.forEach(ride => {
  //           if (ride.stopovers && Array.isArray(ride.stopovers)) {
  //             ride.stopovers.sort((a, b) => {
  //               return a[sort_by].localeCompare(b[sort_by]) * sortOrderMultiplier;
  //             });
  //           }
  //         });
  //       } else {
  //         console.log("sortbyyyy", sort_by)
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == 'asc' ? 1 : -1;
  //           return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
  //         });
  //       }

  //     }

  //     const filteredCount = rangeData.length;
  //     const startIndex = (parseInt(page) - 1) * parseInt(limit)
  //     const endIndex = parseInt(page) * parseInt(limit);
  //     console.log("filteredCount+++", filteredCount)
  //     // Limit the filtered results based on the pagination
  //     let finalrangeData = rangeData.slice(startIndex, endIndex);
  //     console.log("filteredCount+++", finalrangeData)
  //     return res.status(200).json({ data: finalrangeData, count: filteredCount });
  //   } catch (err) {
  //     console.error("err:", err);
  //     return res
  //       .status(500)
  //       .json({ code: responseCodes.SE.internalError.code });
  //   }
  // },

  getAvailbleRidelistforTesting: async (req, res) => {
    try {
      const {
        start_city_name,
        start_city_address,
        start_point_latitude,
        start_point_longitude,
        end_city_name,
        end_city_address,
        end_point_latitude,
        end_point_longitude,
        route_description,
        is_round_trip,
        start_time,
        round_start_time,
        seats,
        sort_by,
        order_by,
        user_preference,
      } = await joi
        .object({
          start_city_name: joi.string().required(),
          start_city_address: joi.string().required(),
          start_point_latitude: joi.string().required(),
          start_point_longitude: joi.string().required(),
          end_city_name: joi.string().required(),
          end_city_address: joi.string().required(),
          end_point_latitude: joi.string().required(),
          end_point_longitude: joi.string().required(),
          route_description: joi.string().required(),
          is_round_trip: joi.boolean().required(),
          start_time: joi.date().required(),
          round_start_time: joi.date().optional(),
          seats: joi.number().required(),
          sort_by: joi
            .string()
            .valid(
              "start_time",
              "total_price",
              "close_to_departure",
              "close_to_arrival"
            )
            .optional(),
          order_by: joi.string().valid("ASC", "DESC").default("ASC").optional(),
          user_preference: joi
            .array()
            .items(
              joi.object({
                question_id: joi
                  .string()
                  .uuid()
                  .allow(...[null, ""]),
                answers_id: joi
                  .string()
                  .uuid()
                  .allow(...[null, ""]),
                start_range: joi.number().optional(),
                end_range: joi.number().optional(),
              })
            )
            .optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.RA.validations.invalidQuery.code,
            description: err,
          });
        });

      const {
        search,
        limit,
        page,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = await joi
        .object({
          search: joi.string(),
          limit: joi.number().default(10),
          page: joi.number().default(1),
          sortBy: joi
            .string()
            .valid(
              "driver_name , vehicle_no",
              ...Object.keys(OfferRide.rawAttributes)
            )
            .default("start_city_name"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          ride_status: joi.number(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query);

      const tenHoursInMilliseconds = 10 * 60 * 60 * 1000;
      const formattedDateStartTime = new Date(start_time);
      formattedDateStartTime.setHours(formattedDateStartTime.getHours() + 5);
      formattedDateStartTime.setMinutes(
        formattedDateStartTime.getMinutes() + 30
      );

      const formattedDateStrRoundTime = new Date(round_start_time);
      formattedDateStrRoundTime.setHours(
        formattedDateStrRoundTime.getHours() + 5
      );
      formattedDateStrRoundTime.setMinutes(
        formattedDateStrRoundTime.getMinutes() + 30
      );

      let where = {
        // end_time: { [Op.gte]: new Date() } ,
        ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        ...(typeof is_active === "boolean" && { is_active }),
        ...(ride_status && { ride_status }),
      };

      if (is_round_trip) {
        // If is_round_trip is true, use "OR" condition for start_time and round_start_time
        where[Op.or] = [
          {
            start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStartTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStartTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
          {
            round_start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStrRoundTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStrRoundTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
        ];
      } else {
        // If is_round_trip is false, use start_time only
        where.start_time = {
          [Op.between]: [
            new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds),
            new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds),
          ],
        };
      }

      where.end_time = { [Op.gte]: new Date() };
      console.log("where", where);

      let rides = await OfferRide.findAll({
        attributes: [
          "id",
          "profile_id",
          "user_vehicle_id",
          "start_city_name",
          "start_city_address",
          "start_point_latitude",
          "start_point_longitude",
          "end_city_name",
          "end_city_address",
          "end_point_latitude",
          "end_point_longitude",
          ["available_seat", "offered_seat"],
          "total_price",
          "total_distance",
          "route_description",
          "is_round_trip",
          "ride_status",
          "is_active",
          "start_time",
          "end_time",
          "round_start_time",
          "round_end_time",
          "created_at",
          "updated_at",
          "latitude",
          "total_suggested_price",
          "price_master_id",
        ],
        where,
        include: [
          {
            association: "passenger_bookings",
            include: [
              {
                association: "passenger_detail",
              },
            ],
          },
          {
            association: "stopovers",
          },
        ],
      });

      rides = rides
        .map((item) => {
          const activePassengerBookings = item.passenger_bookings.filter(
            (booking) => booking.is_active === true
          );
          const totalPassenger = activePassengerBookings.reduce(
            (sum, booking) => sum + booking.total_passenger,
            0
          );

          const available_seats = item.offered_seat - totalPassenger;
          const updatedItem = {
            ...item.dataValues,
            available_seats,
          };
          return updatedItem;
        })
        .filter((item) => item.available_seats >= seats);

      for (let ride of rides) {
        let profile = await Profile.findOne({
          where: {
            id: ride.profile_id,
          },
        });

        let userRidesCount = await OfferRide.findAll({
          where: {
            profile_id: ride.profile_id,
            ride_status: {
              [Op.in]: [1, 2],
            },
          },
        });

        let vehicle = await UserVehicle.findOne({
          where: {
            id: ride.user_vehicle_id,
          },
        });

        if (vehicle !== undefined) {
          var prefrenses_where = {
            profile_id: ride.profile_id,
            user_vehicle_id: ride.user_vehicle_id,
          };
        } else {
          var prefrenses_where = { profile_id: ride.profile_id };
        }

        var prefrenseData = await UserPrefrense.findAll({
          attributes: ["id", "question_id"],
          where: prefrenses_where,
          include: [
            {
              association: "userquestion",
              where: { is_active: true },
              attributes: ["id", "title", "answer_type", "icon"],
              require: true,
            },
            {
              association: "userprefrenseanswer",
              attributes: [
                "answer_id",
                ["start_range", "start_set_range"],
                ["end_range", "end_set_range"],
              ],
              include: [
                {
                  association: "useranswer",
                  where: { is_active: true },
                  // attributes: ["id", "range_title", "start_range", "end_range"],
                  attributes: ["id"],
                  require: true,
                },
              ],
            },
          ],
        });

        const userverified = await UserDocument.count({
          where: {
            [Op.and]: [
              {
                profile_id: ride.profile_id,
              },
              {
                is_verified: 2,
              },
            ],
          },
        });

        // TODO get dynamic drivers ratings and reviews
        let ratings = 4;
        let reviews = 10;

        let driver_detail = {
          driver_name: profile ? profile.dataValues.name : "",
          driver_image: profile ? profile.dataValues.profile_url : "",
          dob: profile ? profile.dataValues.dob : "",
          profile_detail: profile ? profile.dataValues.profile_detail : "",
          created_at: profile ? profile.dataValues.created_at : "",
          user_id: profile ? profile.dataValues.user_id : "",
          isGovtIdVerified: userverified ? true : false,
          ridesCount: userRidesCount.length ? userRidesCount.length : 0,
          reviews,
          ratings,
        };

        let vehicle_detail = {
          vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
          vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
          model_id: vehicle ? vehicle.dataValues.model_id : "",
          type_id: vehicle ? vehicle.dataValues.type_id : "",
          colour_id: vehicle ? vehicle.dataValues.colour_id : "",
          prefrences: prefrenseData ? prefrenseData : [],
        };

        ride.driver_detail = driver_detail;
        ride.vehicle_detail = vehicle_detail;
      }
      const count = await OfferRide.count({
        where: {
          ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        },
      });

      if (search) {
        rides = rides.filter((item) => {
          const {
            driver_name,
            vehicle_no,
            start_city_name,
            end_city_name,
            start_city_address,
            end_city_address,
          } = item;
          const keyword = search.toLowerCase();
          return (
            driver_name.toLowerCase().includes(keyword) ||
            vehicle_no.toLowerCase().includes(keyword) ||
            start_city_address.toLowerCase().includes(keyword) ||
            end_city_address.toLowerCase().includes(keyword) ||
            start_city_name.toLowerCase().includes(keyword) ||
            end_city_name.toLowerCase().includes(keyword)
          );
        });
      }
      if (user_preference && user_preference.length > 0) {
        rides = filterPrefrensRecord(rides, user_preference);
      }
      let rangeData = [];
      if (
        start_point_latitude &&
        start_point_longitude &&
        end_point_latitude &&
        end_point_longitude
      ) {
        rangeData = filterDataWithinRange(
          rides,
          start_point_latitude,
          start_point_longitude,
          end_point_latitude,
          end_point_longitude,
          5,
          is_round_trip
        );
      }
      console.log("filtered data", rangeData.length);
      if (
        sort_by == "start_time" ||
        sort_by == "total_price" ||
        sort_by == "close_to_departure" ||
        sort_by == "close_to_arrival"
      ) {
        if (sort_by == "close_to_departure") {
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        } else if (sort_by == "close_to_arrival") {
          // Sort rangeData based on close_to_arrival
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        } else {
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        }
      }

      const filteredCount = rangeData.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const endIndex = parseInt(page) * parseInt(limit);
      let finalrangeData = rangeData.slice(startIndex, endIndex);
      return res
        .status(200)
        .json({ data: finalrangeData, count: filteredCount });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  // getAvailbleRidelist: async (req, res) => {
  //   try {
  //     const {
  //       start_city_name,
  //       start_city_address,
  //       start_point_latitude,
  //       start_point_longitude,
  //       end_city_name,
  //       end_city_address,
  //       end_point_latitude,
  //       end_point_longitude,
  //       route_description,
  //       is_round_trip,
  //       start_time,
  //       round_start_time,
  //       seats,
  //       sort_by,
  //       order_by,
  //       user_preference,
  //     } = await joi
  //       .object({
  //         start_city_name: joi.string().required(),
  //         start_city_address: joi.string().required(),
  //         start_point_latitude: joi.string().required(),
  //         start_point_longitude: joi.string().required(),
  //         end_city_name: joi.string().required(),
  //         end_city_address: joi.string().required(),
  //         end_point_latitude: joi.string().required(),
  //         end_point_longitude: joi.string().required(),
  //         route_description: joi.string().optional(),
  //         is_round_trip: joi.boolean().required(),
  //         start_time: joi.date().required(),
  //         round_start_time: joi.date().optional(),
  //         seats: joi.number().required(),
  //         sort_by: joi
  //           .string()
  //           .valid(
  //             "start_time",
  //             "total_price",
  //             "close_to_departure",
  //             "close_to_arrival"
  //           )
  //           .default("total_price")
  //           .optional(),
  //         order_by: joi.string().valid("ASC", "DESC").default("ASC").optional(),
  //         user_preference: joi
  //           .array()
  //           .items(
  //             joi.object({
  //               question_id: joi
  //                 .string()
  //                 .uuid()
  //                 .allow(...[null, ""]),
  //               answers_id: joi
  //                 .string()
  //                 .uuid()
  //                 .allow(...[null, ""]),
  //               start_range: joi.number().optional(),
  //               end_range: joi.number().optional(),
  //             })
  //           )
  //           .optional(),
  //       })
  //       .validateAsync(req.body)
  //       .catch((err) => {
  //         console.log("err:", err);
  //         return res.status(400).json({
  //           code: responseCodes.RA.validations.invalidQuery.code,
  //           description: err,
  //         });
  //       });

  //     const {
  //       search,
  //       limit,
  //       page,
  //       sortBy = "start_city_name",
  //       orderBy = "ASC",
  //       ride_status,
  //       type,
  //       is_active,
  //       profiles,
  //     } = await joi
  //       .object({
  //         search: joi.string(),
  //         limit: joi.number().default(10),
  //         page: joi.number().default(1),
  //         sortBy: joi
  //           .string()
  //           .valid(
  //             "driver_name , vehicle_no",
  //             ...Object.keys(OfferRide.rawAttributes)
  //           )
  //           .default("start_city_name"),
  //         orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
  //         ride_status: joi.number(),
  //         type: joi.number(),
  //         is_active: joi.boolean(),
  //         profiles: joi
  //           .string()
  //           .trim()
  //           .pattern(
  //             /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
  //           ),
  //       })
  //       .validateAsync(req.query);

  //     const tenHoursInMilliseconds = 10 * 60 * 60 * 1000;
  //     const formattedDateStartTime = new Date(req.body.start_time);
  //     const formattedDateStartTime123 = new Date(start_time);
  //     console.log(
  //       req.body.start_time,
  //       "start end 111",
  //       start_time
  //     );
  //     console.log(
  //       new Date(formattedDateStartTime123.getTime() - tenHoursInMilliseconds),
  //       "start end 111",
  //       new Date(formattedDateStartTime123.getTime() + tenHoursInMilliseconds)
  //     );
  //     // formattedDateStartTime.setHours(formattedDateStartTime.getHours() + 5);
  //     // formattedDateStartTime.setMinutes(formattedDateStartTime.getMinutes() + 30);

  //     const formattedDateStrRoundTime = new Date(req.body.round_start_time);
  //     // formattedDateStrRoundTime.setHours(formattedDateStrRoundTime.getHours() + 5);
  //     // formattedDateStrRoundTime.setMinutes(formattedDateStrRoundTime.getMinutes() + 30);

  //     let where = {
  //       ride_status: { [Op.in]: [1] },
  //       // end_time: { [Op.gte]: new Date() } ,
  //       ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
  //       ...(typeof is_active === "boolean" && { is_active }),
  //       ...(ride_status && { ride_status }),
  //     };

  //     if (is_round_trip) {
  //       // If is_round_trip is true, use "OR" condition for start_time and round_start_time
  //       where[Op.or] = [
  //         {
  //           start_time: {
  //             [Op.between]: [
  //               new Date(
  //                 formattedDateStartTime.getTime() - tenHoursInMilliseconds
  //               ),
  //               new Date(
  //                 formattedDateStartTime.getTime() + tenHoursInMilliseconds
  //               ),
  //             ],
  //           },
  //         },
  //         {
  //           round_start_time: {
  //             [Op.between]: [
  //               new Date(
  //                 formattedDateStrRoundTime.getTime() - tenHoursInMilliseconds
  //               ),
  //               new Date(
  //                 formattedDateStrRoundTime.getTime() + tenHoursInMilliseconds
  //               ),
  //             ],
  //           },
  //         },
  //       ];
  //     } else {
  //       // If is_round_trip is false, use start_time only
  //       // where.start_time = {
  //       //   [Op.between]: [new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds), new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)],
  //       // };
  //       where[Op.or] = [
  //         {
  //           start_time: {
  //             [Op.between]: [
  //               new Date(
  //                 formattedDateStartTime.getTime() - tenHoursInMilliseconds
  //               ),
  //               new Date(
  //                 formattedDateStartTime.getTime() + tenHoursInMilliseconds
  //               ),
  //             ],
  //           },
  //         },
  //         {
  //           round_start_time: {
  //             [Op.between]: [
  //               new Date(
  //                 formattedDateStartTime.getTime() - tenHoursInMilliseconds
  //               ),
  //               new Date(
  //                 formattedDateStartTime.getTime() + tenHoursInMilliseconds
  //               ),
  //             ],
  //           },
  //         },
  //       ];
  //     }

  //     where.end_time = { [Op.gte]: new Date() };
  //     console.log(
  //       "where",
  //       start_time,
  //       formattedDateStartTime,
  //       req.body.start_time
  //     );
  //     console.log(
  //       new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds),
  //       "start end ",
  //       new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)
  //     );

  //     let rides = await OfferRide.findAll({
  //       attributes: [
  //         "id",
  //         "profile_id",
  //         "user_vehicle_id",
  //         "start_city_name",
  //         "start_city_address",
  //         "start_point_latitude",
  //         "start_point_longitude",
  //         "end_city_name",
  //         "end_city_address",
  //         "end_point_latitude",
  //         "end_point_longitude",
  //         ["available_seat", "offered_seat"],
  //         "total_price",
  //         "total_distance",
  //         "route_description",
  //         "is_round_trip",
  //         "ride_status",
  //         "is_active",
  //         "start_time",
  //         "end_time",
  //         "round_start_time",
  //         "round_end_time",
  //         "created_at",
  //         "updated_at",
  //         "latitude",
  //         "total_suggested_price",
  //         "price_master_id"
  //       ],
  //       where,
  //       include: [
  //         {
  //           association: "passenger_bookings",
  //           include: [
  //             {
  //               association: "passenger_detail",
  //             },
  //           ],
  //         },
  //         {
  //           association: "stopovers",
  //         },
  //       ],
  //     });
  //     console.log("where", rides.length);
  //     rides = rides
  //       .map((item) => {
  //         const activePassengerBookings = item.passenger_bookings.filter(
  //           (booking) => booking.is_active === true
  //         );
  //         const totalPassenger = activePassengerBookings.reduce(
  //           (sum, booking) => sum + booking.total_passenger,
  //           0
  //         );

  //         const availableSeats = item.available_seat - totalPassenger;
  //         const updatedItem = {
  //           ...item.dataValues,
  //           availableSeats,
  //         };
  //         return updatedItem;
  //       })
  //       .filter((item) => item.availableSeats >= seats);
  //     console.log("where", rides.length);
  //     for (let ride of rides) {
  //       let driverObject = await generateDriverDeatilObject(
  //         ride.profile_id,
  //         ride.user_vehicle_id
  //       );

  //       // let profile = await Profile.findOne({
  //       //   where: {
  //       //     id: ride.profile_id,
  //       //   },
  //       // });

  //       // let userRidesCount = await OfferRide.findAll({
  //       //   where: {
  //       //     profile_id: ride.profile_id,
  //       //     ride_status: {
  //       //       [Op.in]: [1, 2],
  //       //     },
  //       //   },
  //       // });

  //       // let vehicle = await UserVehicle.findOne({
  //       //   where: {
  //       //     id: ride.user_vehicle_id,
  //       //   },
  //       // });
  //       const passengerBookingInfoByRideId = await PassengerBooking.findAll({
  //         where: {
  //           ride_id: ride.id,
  //         },
  //       });
  //       // if (vehicle !== undefined) {
  //       //   var prefrenses_where = {
  //       //     profile_id: ride.profile_id,
  //       //     user_vehicle_id: ride.user_vehicle_id,
  //       //   };
  //       // } else {
  //       //   var prefrenses_where = { profile_id: ride.profile_id };
  //       // }

  //       // var prefrenseData = await UserPrefrense.findAll({
  //       //   // attributes: ["id", "question_id"],
  //       //   where: prefrenses_where,
  //       //   include: [
  //       //     {
  //       //       association: "userquestion",
  //       //       where: { is_active: true },
  //       //       attributes: [
  //       //         "id",
  //       //         "title",
  //       //         "position",
  //       //         "weghtage",
  //       //         "answer_type",
  //       //         "icon",
  //       //       ],
  //       //       require: true,
  //       //     },
  //       //     {
  //       //       association: "userprefrenseanswer",
  //       //       attributes: [
  //       //         "id",
  //       //         "answer_id",
  //       //         ["end_range", "end_set_range"],
  //       //         ["start_range", "start_set_range"],
  //       //       ],
  //       //       include: [
  //       //         {
  //       //           association: "useranswer",
  //       //           where: { is_active: true },
  //       //           attributes: ["id", "range_title", "start_range", "end_range"],
  //       //           // attributes: ["id"],
  //       //           require: true,
  //       //         },
  //       //       ],
  //       //     },
  //       //   ],
  //       // });

  //       // const userverified = await UserDocument.count({
  //       //   where: {
  //       //     [Op.and]: [
  //       //       {
  //       //         profile_id: ride.profile_id,
  //       //       },
  //       //       {
  //       //         is_verified: 2,
  //       //       },
  //       //     ],
  //       //   },
  //       // });

  //       // // TODO get dynamic drivers ratings and reviews
  //       // let ratings = 4;
  //       // let reviews = 10;

  //       // let driver_detail = {
  //       //   driver_name: profile ? profile.dataValues.name : "",
  //       //   driver_image: profile ? profile.dataValues.profile_url : "",
  //       //   dob: profile ? profile.dataValues.dob : "",
  //       //   profile_detail: profile ? profile.dataValues.profile_detail : "",
  //       //   created_at: profile ? profile.dataValues.created_at : "",
  //       //   user_id: profile ? profile.dataValues.user_id : "",
  //       //   isGovtIdVerified: userverified ? true : false,
  //       //   ridesCount: userRidesCount.length ? userRidesCount.length : 0,
  //       //   reviews,
  //       //   ratings,
  //       // };

  //       // let vehicle_detail = {
  //       //   vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
  //       //   vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
  //       //   model_id: vehicle ? vehicle.dataValues.model_id : "",
  //       //   type_id: vehicle ? vehicle.dataValues.type_id : "",
  //       //   colour_id: vehicle ? vehicle.dataValues.colour_id : "",
  //       //   prefrences: prefrenseData ? prefrenseData : [],
  //       // };

  //       // Object.assign(ride, driverObject?.driver_detail, driverObject?.vehicle_detail);
  //       ride.driver_detail = driverObject ? driverObject.driver_detail : {};
  //       ride.vehicle_detail = driverObject ? driverObject.vehicle_detail : {};
  //       ride.is_ride_booked = passengerBookingInfoByRideId.length > 0;
  //       console.log("ride", ride);
  //     }
  //     const count = await OfferRide.count({
  //       where: {
  //         ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
  //       },
  //     });
  //     console.log("where", rides.length);
  //     if (search) {
  //       rides = rides.filter((item) => {
  //         const {
  //           driver_name,
  //           vehicle_no,
  //           start_city_name,
  //           end_city_name,
  //           start_city_address,
  //           end_city_address,
  //         } = item;
  //         const keyword = search.toLowerCase();
  //         return (
  //           driver_name.toLowerCase().includes(keyword) ||
  //           vehicle_no.toLowerCase().includes(keyword) ||
  //           start_city_address.toLowerCase().includes(keyword) ||
  //           end_city_address.toLowerCase().includes(keyword) ||
  //           start_city_name.toLowerCase().includes(keyword) ||
  //           end_city_name.toLowerCase().includes(keyword)
  //         );
  //       });
  //     }
  //     if (user_preference && user_preference.length > 0) {
  //       rides = filterPrefrensRecord(rides, user_preference);
  //     }
  //     console.log("filtered data+++", rides.length);
  //     let rangeData = [];
  //     if (
  //       start_point_latitude &&
  //       start_point_longitude &&
  //       end_point_latitude &&
  //       end_point_longitude
  //     ) {
  //       rangeData = filterDataWithinRange(
  //         rides,
  //         start_point_latitude,
  //         start_point_longitude,
  //         end_point_latitude,
  //         end_point_longitude,
  //         5,
  //         is_round_trip,
  //         formattedDateStartTime,
  //         tenHoursInMilliseconds
  //       );
  //     }
  //     console.log("filtered data", rangeData.length);
  //     if (
  //       sort_by == "start_time" ||
  //       sort_by == "total_price" ||
  //       sort_by == "close_to_departure" ||
  //       sort_by == "close_to_arrival"
  //     ) {
  //       if (sort_by == "close_to_departure") {
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
  //           return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
  //         });
  //       } else if (sort_by == "close_to_arrival") {
  //         // Sort rangeData based on close_to_arrival
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
  //           return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
  //         });
  //       } else {
  //         rangeData.sort((a, b) => {
  //           const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
  //           return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
  //         });
  //       }
  //     }

  //     const filteredCount = rangeData.length;
  //     const startIndex = (parseInt(page) - 1) * parseInt(limit);
  //     const endIndex = parseInt(page) * parseInt(limit);
  //     let finalrangeData = rangeData.slice(startIndex, endIndex);
  //     return res
  //       .status(200)
  //       .json({ data: finalrangeData, count: filteredCount });
  //   } catch (err) {
  //     console.error("err:", err);
  //     return res
  //       .status(500)
  //       .json({ code: responseCodes.SE.internalError.code });
  //   }
  // },

  getAvailbleRidelist: async (req, res) => {
    try {
      const {
        start_city_name,
        start_city_address,
        start_point_latitude,
        start_point_longitude,
        end_city_name,
        end_city_address,
        end_point_latitude,
        end_point_longitude,
        route_description,
        is_round_trip,
        start_time,
        round_start_time,
        seats,
        sort_by,
        order_by,
        user_preference,
      } = await joi
        .object({
          start_city_name: joi.string().required(),
          start_city_address: joi.string().required(),
          start_point_latitude: joi.string().required(),
          start_point_longitude: joi.string().required(),
          end_city_name: joi.string().required(),
          end_city_address: joi.string().required(),
          end_point_latitude: joi.string().required(),
          end_point_longitude: joi.string().required(),
          route_description: joi.string().optional(),
          is_round_trip: joi.boolean().required(),
          start_time: joi.date().required(),
          round_start_time: joi.date().optional(),
          seats: joi.number().required(),
          sort_by: joi
            .string()
            .valid(
              "start_time",
              "total_price",
              "close_to_departure",
              "close_to_arrival"
            )
            .default("total_price")
            .optional(),
          order_by: joi.string().valid("ASC", "DESC").default("ASC").optional(),
          user_preference: joi
            .array()
            .items(
              joi.object({
                question_id: joi
                  .string()
                  .uuid()
                  .allow(...[null, ""]),
                answers_id: joi
                  .string()
                  .uuid()
                  .allow(...[null, ""]),
                start_range: joi.number().optional(),
                end_range: joi.number().optional(),
              })
            )
            .optional(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.RA.validations.invalidQuery.code,
            description: err,
          });
        });

      const {
        search,
        limit,
        page,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = await joi
        .object({
          search: joi.string(),
          limit: joi.number().default(10),
          page: joi.number().default(1),
          sortBy: joi
            .string()
            .valid(
              "driver_name , vehicle_no",
              ...Object.keys(OfferRide.rawAttributes)
            )
            .default("start_city_name"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          ride_status: joi.number(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query);

      const tenHoursInMilliseconds = 10 * 60 * 60 * 1000;
      const formattedDateStartTime = new Date(start_time);

      // Adding 5 hours and 30 minutes to the UTC date
      const hoursToAdd = 5;
      const minutesToAdd = 30;
      formattedDateStartTime.setUTCHours(
        formattedDateStartTime.getUTCHours() + hoursToAdd
      );
      formattedDateStartTime.setUTCMinutes(
        formattedDateStartTime.getUTCMinutes() + minutesToAdd
      );

      const formattedDateStrRoundTime = new Date(round_start_time);
      formattedDateStrRoundTime.setUTCHours(
        formattedDateStrRoundTime.getUTCHours() + hoursToAdd
      );
      formattedDateStrRoundTime.setUTCMinutes(
        formattedDateStrRoundTime.getUTCMinutes() + minutesToAdd
      );

      console.log(
        "where",
        start_time,
        formattedDateStartTime,
        req.body.start_time
      );
      console.log(
        new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds),
        "start end ",
        new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)
      );

      let where = {
        ride_status: { [Op.in]: [1] },
        // end_time: { [Op.gte]: new Date() } ,
        ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        ...(typeof is_active === "boolean" && { is_active }),
        ...(ride_status && { ride_status }),
      };

      if (is_round_trip) {
        // If is_round_trip is true, use "OR" condition for start_time and round_start_time
        where[Op.or] = [
          {
            start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStartTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStartTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
          {
            round_start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStrRoundTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStrRoundTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
        ];
      } else {
        // If is_round_trip is false, use start_time only
        // where.start_time = {
        //   [Op.between]: [new Date(formattedDateStartTime.getTime() - tenHoursInMilliseconds), new Date(formattedDateStartTime.getTime() + tenHoursInMilliseconds)],
        // };
        where[Op.or] = [
          {
            start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStartTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStartTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
          {
            round_start_time: {
              [Op.between]: [
                new Date(
                  formattedDateStartTime.getTime() - tenHoursInMilliseconds
                ),
                new Date(
                  formattedDateStartTime.getTime() + tenHoursInMilliseconds
                ),
              ],
            },
          },
        ];
      }

      where.end_time = { [Op.gte]: new Date() };

      let rides = await OfferRide.findAll({
        attributes: [
          "id",
          "profile_id",
          "user_vehicle_id",
          "start_city_name",
          "start_city_address",
          "start_point_latitude",
          "start_point_longitude",
          "end_city_name",
          "end_city_address",
          "end_point_latitude",
          "end_point_longitude",
          ["available_seat", "offered_seat"],
          "total_price",
          "total_distance",
          "route_description",
          "is_round_trip",
          "ride_status",
          "is_active",
          "start_time",
          "end_time",
          "round_start_time",
          "round_end_time",
          "created_at",
          "updated_at",
          "latitude",
          "total_suggested_price",
          "price_master_id",
        ],
        where,
        include: [
          {
            association: "passenger_bookings",
            include: [
              {
                association: "passenger_detail",
              },
            ],
          },
          {
            association: "stopovers",
          },
        ],
      });
      console.log("where", rides.length);
      rides = rides
        .map((item) => {
          const activePassengerBookings =
            item.dataValues.passenger_bookings.filter(
              (booking) =>
                booking.is_active === true &&
                (booking.booking_status == 1 ||
                  booking.booking_status == 2 ||
                  booking.booking_status == 4)
            );
          const totalPassenger = activePassengerBookings.reduce(
            (sum, booking) => sum + booking.total_passenger,
            0
          );

          //   const availableSeats = item.available_seat - totalPassenger;
          //   const updatedItem = {
          //     ...item.dataValues,
          //     availableSeats,
          //   };
          //   return updatedItem;
          // })
          // .filter((item) => item.availableSeats >= seats);

          const available_seats = item.dataValues.offered_seat - totalPassenger;
          const updatedItem = {
            ...item.dataValues,
            available_seats,
          };
          return updatedItem;
        })
        .filter((item) => item.available_seats >= seats);

      for (let ride of rides) {
        if (ride.passenger_bookings.length) {
          for (let passengerBooking of ride.passenger_bookings) {
            let passengerBookingObject = await generatePassengerDeatilObject(
              passengerBooking.profile_id
            );
            passengerBooking.dataValues.passenger_detail =
              passengerBookingObject
                ? passengerBookingObject.passenger_detail
                : {};
          }
        }

        let driverObject = await generateDriverDeatilObject(
          ride.profile_id,
          ride.user_vehicle_id
        );

        // let profile = await Profile.findOne({
        //   where: {
        //     id: ride.profile_id,
        //   },
        // });

        // let userRidesCount = await OfferRide.findAll({
        //   where: {
        //     profile_id: ride.profile_id,
        //     ride_status: {
        //       [Op.in]: [1, 2],
        //     },
        //   },
        // });

        // let vehicle = await UserVehicle.findOne({
        //   where: {
        //     id: ride.user_vehicle_id,
        //   },
        // });
        const passengerBookingInfoByRideId = await PassengerBooking.findAll({
          where: {
            ride_id: ride.id,
          },
        });
        // if (vehicle !== undefined) {
        //   var prefrenses_where = {
        //     profile_id: ride.profile_id,
        //     user_vehicle_id: ride.user_vehicle_id,
        //   };
        // } else {
        //   var prefrenses_where = { profile_id: ride.profile_id };
        // }

        // var prefrenseData = await UserPrefrense.findAll({
        //   // attributes: ["id", "question_id"],
        //   where: prefrenses_where,
        //   include: [
        //     {
        //       association: "userquestion",
        //       where: { is_active: true },
        //       attributes: [
        //         "id",
        //         "title",
        //         "position",
        //         "weghtage",
        //         "answer_type",
        //         "icon",
        //       ],
        //       require: true,
        //     },
        //     {
        //       association: "userprefrenseanswer",
        //       attributes: [
        //         "id",
        //         "answer_id",
        //         ["end_range", "end_set_range"],
        //         ["start_range", "start_set_range"],
        //       ],
        //       include: [
        //         {
        //           association: "useranswer",
        //           where: { is_active: true },
        //           attributes: ["id", "range_title", "start_range", "end_range"],
        //           // attributes: ["id"],
        //           require: true,
        //         },
        //       ],
        //     },
        //   ],
        // });

        // const userverified = await UserDocument.count({
        //   where: {
        //     [Op.and]: [
        //       {
        //         profile_id: ride.profile_id,
        //       },
        //       {
        //         is_verified: 2,
        //       },
        //     ],
        //   },
        // });

        // // TODO get dynamic drivers ratings and reviews
        // let ratings = 4;
        // let reviews = 10;

        // let driver_detail = {
        //   driver_name: profile ? profile.dataValues.name : "",
        //   driver_image: profile ? profile.dataValues.profile_url : "",
        //   dob: profile ? profile.dataValues.dob : "",
        //   profile_detail: profile ? profile.dataValues.profile_detail : "",
        //   created_at: profile ? profile.dataValues.created_at : "",
        //   user_id: profile ? profile.dataValues.user_id : "",
        //   isGovtIdVerified: userverified ? true : false,
        //   ridesCount: userRidesCount.length ? userRidesCount.length : 0,
        //   reviews,
        //   ratings,
        // };

        // let vehicle_detail = {
        //   vehicle_no: vehicle ? vehicle.dataValues.vehicle_no : "",
        //   vehicle_id: vehicle ? vehicle.dataValues.vehicle_id : "",
        //   model_id: vehicle ? vehicle.dataValues.model_id : "",
        //   type_id: vehicle ? vehicle.dataValues.type_id : "",
        //   colour_id: vehicle ? vehicle.dataValues.colour_id : "",
        //   prefrences: prefrenseData ? prefrenseData : [],
        // };

        // Object.assign(ride, driverObject?.driver_detail, driverObject?.vehicle_detail);
        ride.driver_detail = driverObject ? driverObject.driver_detail : {};
        ride.vehicle_detail = driverObject ? driverObject.vehicle_detail : {};
        ride.is_ride_booked = passengerBookingInfoByRideId.length > 0;
        console.log("ride", ride);
      }
      const count = await OfferRide.count({
        where: {
          ...(profiles ? { profile_id: { [Op.or]: profiles.split(",") } } : {}),
        },
      });

      if (search) {
        rides = rides.filter((item) => {
          const {
            driver_name,
            vehicle_no,
            start_city_name,
            end_city_name,
            start_city_address,
            end_city_address,
          } = item;
          const keyword = search.toLowerCase();
          return (
            driver_name.toLowerCase().includes(keyword) ||
            vehicle_no.toLowerCase().includes(keyword) ||
            start_city_address.toLowerCase().includes(keyword) ||
            end_city_address.toLowerCase().includes(keyword) ||
            start_city_name.toLowerCase().includes(keyword) ||
            end_city_name.toLowerCase().includes(keyword)
          );
        });
      }
      if (user_preference && user_preference.length > 0) {
        rides = filterPrefrensRecord(rides, user_preference);
      }
      console.log("filtered data+++", rides.length);
      let rangeData = [];
      if (
        start_point_latitude &&
        start_point_longitude &&
        end_point_latitude &&
        end_point_longitude
      ) {
        rangeData = filterDataWithinRange(
          rides,
          start_point_latitude,
          start_point_longitude,
          end_point_latitude,
          end_point_longitude,
          5,
          is_round_trip,
          formattedDateStartTime,
          tenHoursInMilliseconds
        );
      }
      console.log("filtered data", rangeData.length);
      if (
        sort_by == "start_time" ||
        sort_by == "total_price" ||
        sort_by == "close_to_departure" ||
        sort_by == "close_to_arrival"
      ) {
        if (sort_by == "close_to_departure") {
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        } else if (sort_by == "close_to_arrival") {
          // Sort rangeData based on close_to_arrival
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        } else {
          rangeData.sort((a, b) => {
            const sortOrderMultiplier = order_by == "ASC" ? 1 : -1;
            return (a[sort_by] - b[sort_by]) * sortOrderMultiplier;
          });
        }
      }

      const filteredCount = rangeData.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const endIndex = parseInt(page) * parseInt(limit);
      let finalrangeData = rangeData.slice(startIndex, endIndex);
      return res
        .status(200)
        .json({ data: finalrangeData, count: filteredCount });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  reportDriver: async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = getTokenFromHeader(authHeader);
      const tokenData = validateAndDecodeAccessToken(token);
      const { error, value } = reportDriverDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }
      const getPassengerByIdAndDriverId = await ReportDriver.findOne({
        where: {
          passenger_user_id: tokenData.id,
          user_id: value.user_id,
        },
      });

      if (getPassengerByIdAndDriverId) {
        return res.status(400).json({
          code: responseCodes.RD.exists.code,
          description: error,
        });
      }
      const reportDriverData = {
        passenger_user_id: tokenData.id,
        user_id: value.user_id, // driver user_id
        ride_id: value.ride_id,
        reason: value.reason,
        message: value.message,
      };
      await ReportDriver.create(reportDriverData);
      return res.status(200).json({ code: responseCodes.RA.created });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
