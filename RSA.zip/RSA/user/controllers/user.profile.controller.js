const console = require("../config/logs.config")(
    "yap:users:controllers:profile"
  );
  const joi = require("joi");
  const { Profile, ProfileFollow, ProfileLikeDislike, ReportProfile } = require("../models");
  const {
    responseCodes,
    db: {
      Sequelize: { Op },
    },
    enums: {reportsList, reports}
  } = require("../config");

 
  module.exports = {
    get: async (req, res) => {
      try {
        const { profile_id } = req.params;
  
        const profileStatus = await Profile.findOne({
          where: {
          id: profile_id
          },
          include: [
            {
              association: "profile_status",
              attributes: ["id","like","dislike"],
            },
          ],
          attributes: [
            "id"
          ],
        });
  
        if (!profileStatus)
          return res.status(400).json({ code: responseCodes.PR.notFound.code });
  
        return res.status(200).json({data:profileStatus });
      } catch (err) {
        console.error(err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    add: async (req, res) => {
      try {
        const value = await joi.object({
            is_liked: joi.boolean().allow(null).required()
          })
          .validateAsync(req.body)
          .catch((err) => {
            return res.status(400).json({ code: responseCodes.PF.validations.invalidBody.code });
          });
          const {profile_id} = req.params
          const profile_liked_disliked_by_id = await Profile.findOne({where: {user_id:  req.user.id}})
          if(!profile_liked_disliked_by_id){
            return res.status(400).json({ code: responseCodes.PF.notFound.code });
          }
          const [isLikedDislikedInfo, created] = await ProfileLikeDislike.findOrCreate({
            where: {
              like_unliked_by: profile_liked_disliked_by_id.dataValues.id,
              profile_id: profile_id,
            },
            defaults: {
              is_liked: value.is_liked
            }
          });


          if (!created) {
            if (value.is_liked === null) {
              await isLikedDislikedInfo.destroy();
            } else {
              await isLikedDislikedInfo.update({ is_liked: value.is_liked });
            }
            return res.status(200).json({ code: responseCodes.PR.profileDisliked.code });
          }
          return res.status(200).json({ code: responseCodes.PR.profileLiked.code });
      } catch (err) {
        console.error(err);
        return res.status(500).json({ code: responseCodes.SE.internalError.code });
      }
    },
    getReport: async (req, res) => {
      try {  
        return res.status(200).json({data:reportsList });
      } catch (err) {
        console.error(err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    addReport: async (req ,res) => {
      try {  
        const value = await joi.object({
          report_id:  joi.string().valid(...Object.values(reports)).required(),
          additional_info: joi.string().optional()
        })
        .validateAsync(req.body)
        .catch((err) => {
          return res.status(400).json({ code: responseCodes.PF.validations.invalidBody.code });
        });
        const {profile_id} = req.params
        const reported_by_profile = await Profile.findOne({where: {user_id: req.user.id}})
        const user_reported = await ReportProfile.findOne({
          where: {
            [Op.and]: [{profile_id: profile_id}, {reported_by: reported_by_profile.dataValues.id}]
          }
      })
      if(user_reported){
        return res.status(400).json({ code: responseCodes.PR.profileAlreadyReported.code });
      }
      const report = await ReportProfile.create({
        profile_id: profile_id,
        reported_by: reported_by_profile.dataValues.id,
        report: req.body.report_id,
        additional_info: req.body.additional_info
      })
      return res.status(201).json({ code: responseCodes.PR.profileReported.code });
      } catch (err) {
        console.error(err);
        return res
          .status(500)
          .json({ code: responseCodes.SE.internalError.code });
      }
    },
    follow: async (req, res) => {
      try {
        const value = await joi.object({
            is_followed: joi.boolean().required()
          })
          .validateAsync(req.body)
          .catch((err) => {
            return res.status(400).json({ code: responseCodes.PF.validations.invalidBody.code });
          });
          const {profile_id} = req.params
          const profile_followed_by_id = await Profile.findOne({where: {user_id: req.user.id}})
          if(!profile_followed_by_id){
            return res.status(400).json({ code: responseCodes.PF.notFound.code });
          }
          console.log(typeof(value.is_followed), "follow")
          if(value.is_followed == true){
            const profile_followed = await ProfileFollow.create({
              followed_by: profile_followed_by_id.dataValues.id,
              followed_profile: profile_id,
              is_followed: true
            })
            return res.status(201).json({ code: responseCodes.PR.profileFollowed.code});
          }
          if(value.is_followed == false){
          const profile_unfollwed  = await ProfileFollow.destroy({
            where: {
              [Op.and]: [{followed_profile: profile_id}, {followed_by: profile_followed_by_id.dataValues.id}]
            }
          })
          if(!profile_unfollwed){
            return res.status(400).json({ code: responseCodes.PF.notFound.code });
          }
          return res.status(200).json({ code: responseCodes.PR.profileUnFollowed.code});
          }
      } catch (err) {
        console.error(err);
        return res.status(500).json({ code: responseCodes.SE.internalError.code });
      }
    },
    profileFollowed: async (req, res) => {
      try {
            const profile = await Profile.findOne({
              where: {user_id: req.user.id}
            })
            console.log(req.user.id, "auth")
            const {profile_id} = req.params
            const profile_followed = await ProfileFollow.findOne({
              where: {
                [Op.and]: [{followed_profile: profile_id}, {followed_by: profile.dataValues.id}]
              }
          })
          if(!profile_followed){
            return res.status(200).json({ is_followed: false });
          }
          return res.status(200).json({ is_followed: true});
      } catch (err) {
        console.error(err);
        return res.status(500).json({ code: responseCodes.SE.internalError.code });
      }
    },
}
