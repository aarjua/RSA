'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('theme_masters', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      theme_name: {
        type: Sequelize.STRING
      },
      theme_preview: {
        type: DataTypes.STRING,
         allowNull: false
       },
      account_bg_image: {
        type: Sequelize.STRING
      },
      home_bg_image: {
        type: Sequelize.STRING
      },
      splash: {
        type: Sequelize.STRING
      },
      primary_color_code: {
        type: Sequelize.STRING
      },
      dark_hint_color: {
        type: Sequelize.STRING
      },
      light_hint_color: {
        type: Sequelize.STRING
      },
      dark_highlight_color: {
        type: Sequelize.STRING
      },
      dark_hover_color: {
        type: Sequelize.STRING
      },
      light_hover_color: {
        type: Sequelize.STRING
      },
      dark_focus_color: {
        type: Sequelize.STRING
      },
      light_focus_color: {
        type: Sequelize.STRING
      },
      card_color: {
        type: Sequelize.STRING
      },
      error_color: {
        type: Sequelize.STRING
      },
      progress_indicator_color: {
        type: Sequelize.STRING
      },
      primary_dark_color: {
        type: Sequelize.STRING
      },
      primary_light_color: {
        type: Sequelize.STRING
      },
      disabled_color: {
        type: Sequelize.STRING
      },
      is_default: {
        type: Sequelize.BOOLEAN,
        defaultValue: 0,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        defaultValue: 1,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('theme_masters');
  }
};