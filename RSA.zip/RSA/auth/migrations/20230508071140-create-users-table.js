const {
  enums: { userTypes, languages },
} = require("../config");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("users", {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        allowNull: false,
        defaultValue: Sequelize.UUIDV4,
      },
      email: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      password: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      contact: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        defaultValue: 1,
      },
      role_id: {
        type: Sequelize.UUID,
        allowNull: true,
        references: {
          model: "roles",
          key: "id",
        },
        onDelete: "SET NULL",
      },
      login_attempts_count: {
        type: Sequelize.INTEGER,
        defaultValue: 0,
        allowNull: false,
      },
      forgot_attempts:{
        type: Sequelize.INTEGER,
        defaultValue: 0,
        allowNull: false,
      },
      type: {
        type: Sequelize.ENUM(...Object.values(userTypes)),
        allowNull: false,
        defaultValue: userTypes.user,
      },
      device_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      firebase_token: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      apple_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      facebook_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      lang:{
        type: Sequelize.ENUM(...Object.values(languages)),
        allowNull: false,
        defaultValue: languages.en
      },
      push_notification: {
        type: Sequelize.BOOLEAN,
        defaultValue: 1,
      },
      is_email_verified:{
        type: Sequelize.BOOLEAN,
        defaultValue: 0,
      },
      is_contact_verified:{
        type: Sequelize.BOOLEAN,
        defaultValue: 0,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("users");
  },
};
