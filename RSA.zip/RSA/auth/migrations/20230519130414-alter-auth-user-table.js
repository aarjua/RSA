"use strict";
const {
  enums: { loginWith },
} = require("../config");
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add altering commands here.
     *
     *
     */
    await queryInterface.removeColumn("users", "login_with");
    await queryInterface.addColumn("users", "login_with", {
      type: Sequelize.ENUM(...Object.values(loginWith)),
      allowNull:false
    })
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
    await queryInterface.removeColumn("users", "login_with", {
      type: Sequelize.ENUM(...Object.values(loginWith)),
      allowNull:false
    })
  },
};
