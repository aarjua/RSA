const express = require("express");
const router = express.Router();
const { RoleController } = require("../controllers");
const {
    auth: { emailAuth, auth},
  } = require("../middlewares");
  
router.get("/last-sequence", RoleController.getLatestPosition);

router.route("/")
    .get(auth(), RoleController.getAll)
    .post(auth(), RoleController.add)

router.route("/:id")
    .get(RoleController.get)
    .patch(RoleController.update)
    .delete(RoleController.delete)

router.route("/permissions")
    .post(RoleController.addUpdatePermissions)

module.exports = router;