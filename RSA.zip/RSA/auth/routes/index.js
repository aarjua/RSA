const express = require("express");
const router = express.Router();

const { AuthController } = require("../controllers");
const { responseCode } = require("../config/responseCodes.config");
const {
  auth: { emailAuth, auth, appAuth },
} = require("../middlewares");
// router.route("/send_push").post(AuthController.sendPush);
router.post("/send_push_notifation", AuthController.sendPush);
router.get("/hc", (req, res) => res.json({ data: "sjsdfhjksdfhjks" }));
router.get("/response-code", AuthController.responseCode);
router.get("/accounts/active-user", emailAuth(), AuthController.activeUserStatus)
router.post('/google-login', AuthController.googleLogin)
router.post('/admin-login', AuthController.adminlogin)
router.post("/login", AuthController.login);
router.post("/signup", AuthController.signup);
router.post("/otp-send", AuthController.otpRegister);
router.post("/otp-verification", appAuth(), AuthController.otpVerification);
router.post("/resend-otp", AuthController.resendOtp);
router.route("/accounts/:type").post(AuthController.addAccount);
router.route("/accounts").get(AuthController.getAccountsList);
router.route("/find_unique").post(appAuth(), AuthController.findUnique);
router.route("/user-role-change/:user_id/:status").patch(AuthController.roleUpdate);
router.route("/send_push_notification/:user_id/:status").patch(AuthController.sendPushNotification);



router.get("/themes", AuthController.themes);
router.patch("/accounts/:id/status", AuthController.toggleActiveStatus)
router.patch("/accounts/:id/block-unblock", AuthController.toggleBlockedStatus)

router.route("/accounts/:id")
  .patch(AuthController.updateAccount)
  .get(AuthController.getAccount)
  .delete(AuthController.deleteAccount)

router.post("/forgot-password", AuthController.forgotPassword);
router.post("/website-forgot-password", AuthController.webSiteforgotPassword);
router.post("/reset-password", AuthController.resetPassword);

router.use("/roles", require("./roles.route"));
router.use("/permissions", require("./permissions.route"));

router.get("/dashboard/user-count", AuthController.dashboardUserCount);
router.patch("/email-verify", AuthController.emailVerify);
router.post("/logout", appAuth(), AuthController.logout);

router.use("/setting", require("./setting.route"))


module.exports = router;
