const express = require("express");
const router = express.Router();
const { SettingController } = require("../controllers");
const {
    multerMiddleware,
    auth: { emailAuth, auth, appAuth },
  } = require("../middlewares");

router.route("/").get(SettingController.getAll);
router.route("/:id").get(SettingController.getUserSetting);
router.route("/").post(multerMiddleware.uploadSingle("logo"),SettingController.add)
router.route("/:id")
  .patch(multerMiddleware.uploadSingle("logo"),SettingController.update)
  .delete(SettingController.delete)
module.exports = router;