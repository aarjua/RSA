const express = require("express");
const router = express.Router();
const { PermissionController } = require("../controllers");

router.route("/")
    .get(PermissionController.getAll)
    .post()

router.route("/:id")
    .get()
    .patch()
    .delete()

module.exports = router;