const { db: { sequelize, Sequelize: { DataTypes } } } = require("../../auth/config");
const ThemeMaster = require("./theme.master.model");

const AppSetting = sequelize.define('app_setting', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  user_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    },
    onUpdate: 'RESTRICT',
    onDelete: 'SET NULL'
  },
  business_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  business_logo: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  business_theme_colour: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'themes',
      key: 'id'
    },
    onUpdate: 'RESTRICT',
    onDelete: 'CASCADE'
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

ThemeMaster.hasMany(AppSetting, { as: "setting", foreignKey: "business_theme_colour" });
AppSetting.belongsTo(ThemeMaster, { foreignKey: 'business_theme_colour' });

module.exports = AppSetting;