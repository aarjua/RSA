const {
  db: { sequelize, Sequelize: { DataTypes } },
  enums: { jwtTokenTypes }
} = require("../config");

const VerificationCode = sequelize.define('verification_codes', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  contact: {
    type: DataTypes.STRING,
    allowNull: false
  },
  otp: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  valid_till: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  sent_count: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

module.exports = VerificationCode;
