const { db: { sequelize, Sequelize: { DataTypes } } } = require("../config");
const Role = require("./role.model");
const Permission = require("./permission.model");

const RolePermission = sequelize.define('role_permission', {
    role_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        references: {
            model: 'roles',
            key: 'id'
        },
        onUpdate: 'RESTRICT',
        onDelete: 'CASCADE'
    },
    permission_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        references: {
            model: 'permissions',
            key: 'id'
        },
        onUpdate: 'RESTRICT',
        onDelete: 'CASCADE'
    },
    permission_given_by: {
        type: DataTypes.UUID,
        allowNull: true,
        references: {
            model: 'users',
            key: 'id'
        },
        onUpdate: 'RESTRICT',
        onDelete: 'SET NULL'
    }
}, {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
});

Role.hasMany(RolePermission, { as: "permissions", foreignKey: "role_id" });
Permission.hasMany(RolePermission, { as: "assignedToRoles", foreignKey: "permission_id" });

RolePermission.belongsTo(Role, { foreignKey: 'role_id' });
RolePermission.belongsTo(Permission, { foreignKey: 'permission_id' });

module.exports = RolePermission;