const {
  db: { sequelize, Sequelize: { DataTypes } },
  enums: { jwtTokenTypes }
} = require("../config");

const ThemeMaster = sequelize.define('theme_master', {
  id: {
   type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  theme_name: {
   type: DataTypes.STRING,
    allowNull: false
  },
  theme_preview: {
   type: DataTypes.STRING,
    allowNull: false
  },
  account_bg_image: {
   type: DataTypes.STRING,
    allowNull: true
  },
  home_bg_image: {
   type: DataTypes.STRING,
    allowNull: true
  },
  splash: {
   type: DataTypes.STRING,
    allowNull: true
  },
  primary_color_code: {
   type: DataTypes.STRING,
    allowNull: true
  },
  dark_hint_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  light_hint_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  dark_highlight_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  dark_hover_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  light_hover_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  dark_focus_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  light_focus_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  card_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  error_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  progress_indicator_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  primary_dark_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  primary_light_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  disabled_color: {
   type: DataTypes.STRING,
    allowNull: true
  },
  is_default: {
    type: DataTypes.BOOLEAN,
    defaultValue: 0,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: 1,
  },
},
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true
  });

module.exports = ThemeMaster;
