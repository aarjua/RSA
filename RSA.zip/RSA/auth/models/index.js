module.exports = {
    User: require("./user.model"),
    Permission: require("./permission.model"),
    Role: require("./role.model"),
    RolePermission: require("./role-permission.model"),
    VerificationCode: require("./verification-code.model"),
    ThemeMaster: require("./theme.master.model"),
    AppSetting: require("./app.setting.model")
}