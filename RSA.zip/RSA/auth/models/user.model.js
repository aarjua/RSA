const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const {
  enums: { userTypes , loginWith, languages},
} = require("../config");
const Role = require("./role.model");

const User = sequelize.define(
  "user",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    login_with:{
      type: DataTypes.ENUM(...Object.values(loginWith)),
      allowNull: false,
      defaultValue: loginWith.default
    },
    contact: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    country_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    iso: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: 1,
    },
    role_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: "roles",
        key: "id",
      },
      onDelete: "SET NULL",
    },
    login_attempts_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    forgot_attempts:{
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    type: {
      type: DataTypes.ENUM(...Object.values(userTypes)),
      allowNull: false,
      defaultValue: userTypes.user,
    },
    device_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    firebase_token: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    apple_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    facebook_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    lang:{
      type: DataTypes.ENUM(...Object.values(languages)),
      allowNull: false,
      defaultValue: languages.en
    },
    push_notification: {
      type: DataTypes.BOOLEAN,
      defaultValue: 1,
    },
    is_email_verified:{
      type: DataTypes.BOOLEAN,
      defaultValue: 0,
    },
    is_contact_verified:{
      type: DataTypes.BOOLEAN,
      defaultValue: 0,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

// User.hasOne(Role, {
//   as: "assignedRole",
//   foreignKey: "id",
//   sourceKey: "role_id",
// });
Role.hasMany(User, { as: "assignedRole", foreignKey: "role_id" });
User.belongsTo(Role, { as: "assignedRole", foreignKey: 'role_id' });
// Role.belongsToMany(User, {  as: "assignedRole",
// sourceKey: "role_id" });

// User.associate = (models) => {
//   User.belongsTo(models.Role, {
//     foreignKey: 'role_id',
//     as: 'assignedRole',
//   });
// };

module.exports = User;
