const console = require("./logs.config")('yap:auth:env');
const dotenv = require("dotenv");
const path = require("path");

// Load environment variables from parent folder .env file.
const envPath = path.resolve(__dirname, `../../${process.env.NODE_ENV || 'development'}.env`);
console.log('auth envPath:', envPath)
dotenv.config({ path: envPath });

// Load environment variables from .env file in this service directory
const envPathLocal = path.resolve(__dirname, `../${process.env.NODE_ENV || 'development'}.env`);
console.log('auth envPathLocal:', envPathLocal)
dotenv.config({ path: envPathLocal });

const joi = require("joi");

const environmentVariablesSchema = joi.object({
    NODE_ENV: joi.string().trim().allow(...['development', 'testing', 'staging', 'production']).required(),
    PORT: joi.number().default(3018),
    DB_HOST: joi.string().trim().required(),
    DB_NAME: joi.string().trim().required(),
    DB_USER: joi.string().trim().required(),
    DB_PASS: joi.string().trim().required(),
    DB_PORT: joi.number().default(3306),
    DB_DIALECT: joi.string().trim().default('mysql'),
    DATA_ENCRYPTION_KEY: joi.string().trim().required(),
    RESPONSE_ENCRYPTION_KEY: joi.string().trim().required(),
    SUPER_ADMIN_EMAIL: joi.string().trim().email().required(),
    JWT_ACCESS_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_ACCESS_TOKEN_SECRET shouldn't be equal to JWT_REFRESH_TOKEN_SECRET and JWT_MAIL_TOKEN_SECRET
        if (value === process.env.JWT_REFRESH_TOKEN_SECRET || value === process.env.JWT_MAIL_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_REFRESH_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_REFRESH_TOKEN_SECRET shouldn't be equal to JWT_ACCESS_TOKEN_SECRET and JWT_MAIL_TOKEN_SECRET
        if (value === process.env.JWT_ACCESS_TOKEN_SECRET || value === process.env.JWT_MAIL_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_MAIL_TOKEN_SECRET: joi.string().trim().custom((value, helpers) => {
        //JWT_MAIL_TOKEN_SECRET shouldn't be equal to JWT_ACCESS_TOKEN_SECRET and JWT_REFRESH_TOKEN_SECRET
        if (value === process.env.JWT_ACCESS_TOKEN_SECRET || value === process.env.JWT_REFRESH_TOKEN_SECRET) {
            return helpers.error('any.invalid');
        }
        return value;
    }).required(),
    JWT_ACCESS_TOKEN_VALIDITY: joi.string().default('1d'),
    JWT_REFRESH_TOKEN_VALIDITY: joi.string().default('1d'),
    JWT_MAIL_TOKEN_VALIDITY: joi.string().default('2d'),
    ALLOWED_ORIGINS: joi.string().default(''),
    REQUEST_RATE_LIMIT: joi.number().default(120),
    REQUEST_RATE_LIMIT_DURATION: joi.number().default(60000),
    CMS_URL: joi.string().uri().required(),
    WEBSITE_URL: joi.string().uri().required(),
    LOGIN_ATTEMPTS_MAX_COUNT: joi.number().default(3),
    FORGET_PASSWORD_RESEND_EMAIL_COUNT: joi.number().default(3),
    FORGET_PASSWORD_RESEND_EMAIL_VALIDITY: joi.number().default(1440),
    AWS_ID: joi.string().trim().required(),
    AWS_ACCOUNT_ID: joi.string().trim().optional(),
    AWS_SECRET_KEY: joi.string().trim().required(),
    AWS_REGION: joi.string().trim().required(),
    STATIC_FILES_URL: joi.string().uri().required(),
    TWILIO_PHONE_NUMBER: joi.string().default('+15417255468'),
    TWILIO_ACCOUNT_SID: joi.string().default('ACb0c01118a744816088816de63803a806'),
    TWILIO_AUTH_TOKEN: joi.string().default('d0b843964ef035c0197c6996857e0367'),
    TWILIO_SERVICEID: joi.string().default('VA9cecd2f881105bb6b220b9a4e7e3842c'),
    USER_SERVICE_URL: joi.string().uri().trim().required(),
    SETTING_SERVICE_URL: joi.string().uri().trim().required(),
}).unknown();

const { error, value: environmentVariables } = environmentVariablesSchema.validate(process.env);
if (error) { console.error(`Environment variables validation error: ${error.message}`); process.exit(); }

module.exports = {
    ...environmentVariables,
    local: {
        username: environmentVariables.DB_USER,
        password: environmentVariables.DB_PASS,
        database: environmentVariables.DB_NAME,
        host: environmentVariables.DB_HOST,
        dialect: environmentVariables.DB_DIALECT,
        logging: false,
    }
};