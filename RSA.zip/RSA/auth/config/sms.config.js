const { TWILIO_PHONE_NUMBER, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_SERVICEID } = require("./env.config");

const client = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

exports.verification = async (data) => {
    return new Promise(async (resolve, reject) => {
        try {

            client.verify.v2.services(TWILIO_SERVICEID)
                .verifications
                .create({ to: data.mobileno, channel: 'sms' })
                .then((verification) => {
                    return resolve({ "Massage": "true", "Status": verification.status });
                })
                .catch((error) => {
                    console.error(error);
                    return resolve({ "Massage": error, "Status": false });
                });
        } catch (e) {
            console.log(e);
        }
    })
}

exports.verifymobile = async (data) => {
    return new Promise(async (resolve, reject) => {
        try {

            client.verify.v2.services(TWILIO_SERVICEID)
                .verificationChecks
                .create({ to: data.mobileno, code: data.code })
                .then((verification) => {
                    return resolve({ "Massage": "true", "Status": verification.status });
                })
                .catch((error) => {
                    console.error(error);
                    return resolve({ "Massage": error, "Status": false });
                });

        } catch (e) {
            console.log(e);
        }
    })
}


exports.sendsms = async (data) => {
    return new Promise(async (resolve, reject) => {
        try {

            client.messages.create({
                body: data.text ,
                from: TWILIO_PHONE_NUMBER,
                to: data.mobileno
            })
                .then(message => {
                    console.log('\x1b[32m%s\x1b[0m', message.sid);
                    return resolve({ "Massage": message.sid, "Status": true })
                }).catch((error) => {
                    console.error(error);
                    return resolve({ "Massage": error, "Status": false });
                });
        } catch (e) {
            console.log(e);
        }
    })
}


exports.sendbulksms = async (data) => {
    return new Promise(async (resolve, reject) => {
        try {
            Promise.all(
                data.mobileno.map(number => {
                    return client.messages.create({
                        to: number,
                        from: TWILIO_PHONE_NUMBER,
                        body: data.text
                    });
                })
            )
            .then(message => {
                console.log('\x1b[32m%s\x1b[0m', "message sent successfully");
                return resolve({ "Massage": message, "Status": true })
            }).catch((error) => {
                console.error(error);
                return resolve({ "Massage": error, "Status": false });
            });

        } catch (e) {
            console.log(e);
        }
    })
}

exports.generateOTP = async () => {
    return Math.floor(100000 + Math.random() * 900000);
  }
  
  // Function to send OTP code via SMS
  exports.sendOTPviaSMS = async (toPhoneNumber, otpCode) => {
    const message = `Your OTP code is: ${otpCode}`;
  
    client.messages
      .create({
        body: message,
        from: TWILIO_PHONE_NUMBER,
        to: toPhoneNumber,
      })
      .then((message) => console.log(`OTP sent. Message SID: ${message.sid}`))
      .catch((error) => console.error('Error sending OTP:', error));
  }