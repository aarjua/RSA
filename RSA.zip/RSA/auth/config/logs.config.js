const {
  logColors: { red },
} = require("./enums.config");
module.exports = (groupName) => {
  let log, error;
  if (process.env.DEBUG === "default") {
    log = (...o) => console.log(groupName, "-", ...o);
    error = (...o) => console.log(groupName, "-", ...o);
  } else if (process.env.DEBUG?.startsWith("yap")) {
    log = (...o) => require("debug")(`${groupName}:logs`)(...o);
    error = (...o) =>
      require("debug")(`${groupName}:errors`)(red, JSON.stringify(o, null, 4));
  } else {
    log = (...o) => { };
    error = (...o) => { };
  }
  return { log: console.log, error: console.log };
};
