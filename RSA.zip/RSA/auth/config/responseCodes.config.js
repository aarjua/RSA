/**
 * SM - System
 * AU - Auth
 * UR - User
 */

module.exports = {
  /**
   * SE - System
   */
  SE: {
    internalError: {
      code: "SE500",
      message: "internal server error",
    },
    invalidEncryptedBody: {
      code: "SE501",
      message: "invalid encrypted body or couldn't decrypt the request body",
    },
  },
  /**
   * AU - Auth
   */
  AU: {
    validations: {
      invalidBody: {
        code: "AU400",
        message: "body invalid",
      },
      accountEmailAlreadyExists: {
        code: "AU407",
        message: "account email already exists",
      },
      accountContactAlreadyExists: {
        code: "AU408",
        message: "account contact already exists",
      },
      invalidQuery: {
        code: "AU410",
        message: "query invalid",
      },
    },
    invalidToken: {
      code: "AU401",
      message: "invalid token",
    },
    invalidEmailOrPassword: {
      code: "AU402",
      message: "invalid email or password",
    },
    invalidContactOrOtp: {
      code: "AU411",
      message: "invalid contact",
    },
    unathourizedAccess: {
      code: "AU403",
      message: "unauthorized access",
    },
    logout: {
      code: "AU212",
      message: "logout successfully"
    },
    accountNotActive: {
      code: "AU405",
      message: "account not active",
    },
    emailNotActive: {
      code: "AU425",
      message: "email is not verified",
    },
    verificationEmailSent: {
      code: "AU201",
      message: "verification email sent",
    },
    forgotPasswordEmailSent: {
      code: "AU207",
      message: "forgot password email sent",
    },
    resetPasswordSuccess: {
      code: "AU202",
      message: "reset password success",
    },
    accountActivatedSuccess: {
      code: "AU203",
      message: "account activated success",
    },
    accountAlreadyActivated: {
      code: "AU204",
      message: "account already activated success",
    },
    contactSupportSuccess: {
      code: "AU205",
      message: "contact support mail sent",
    },
    forgotAttemptComplete:{
     code:"AU412",
     message: "max number of attempts reached"
    },
    accountBlocked: {
      code: "AU406",
      message: "account has been blocked due to max number of login attempts",
    },
    accountBlockedSuccessfully: {
      code: "AU206",
      message: "account has been blocked/unblocked successfully for login",
    },
    otpSentSuccessfully: {
      code: "AU208",
      message: "otp has been sent successfully",
    },
    otpResentSuccessfully: {
      code: "AU209",
      message: "otp has been resent successfully",
    },
    otpNotFound: {
      code: "AU413",
      message: "otp not found",
    },
    invalidOtp: {
      code: "AU409",
      message: "entered wrong otp",
    },
    userExist: {
      code: "AU416",
      message: "entered wrong otp",
    },
    otpExpired: {
      code: "AU414",
      message: "otp expired",
    },
    otpMaxAttempt: {
      code: "AU415",
      message: "you have reached maximum attempts for otp requests. you can try again tomorrow",
    },
    roleIdNotFound: {
      code: "AU417",
      message: "role not found",
    },
    userRoleNotFound: {
      code: "AU418",
      message: "role does not match with passenger, driver and passengerwithdriver role",
    },
    themenotFound: {
      code: "AU419",
      message: "theme not found",
    },
    otpVerified: {
      code: "AU420",
      message: "otp verified",
    },
    emailNotExist: {
      code: "AU421",
      message: "email not found",
    },
    contactNotExist: {
      code: "AU422",
      message: "contact not found",
    },
    themeSet: {
      code: "AU423",
      message: "theme configured",
    },
    themeUpdated: {
      code: "AU424",
      message: "theme updated",
    },
    roleUpdated: {
      code: "AU426",
      message: "role updated",
    },
    tokenExpired: {
      code: "AU427",
      message: "token expired",
    },
    profileNotUpdated: {
      code: "AU428",
      message: "profile not updated",
    },
    notFound: {
      code: "AU404",
      message: "not found",
    },
    notificationSent: {
      code: "AU430",
      message: "push notification sent",
    },
  },
  /**
   * U - System User
   */
  UR: {
    created: {
      code: "SU201",
      message: "created",
    },
    notFound: {
      code: "SU404",
      message: "user not found",
    },
    validations: {
      invalidBody: {
        code: "SU400",
        message: "body invalid",
      },
      exists: {
        code: "SU409",
        message: "already exists",
      },
    },
    updated: {
      code: "SU200",
      message: "updated",
    },
    userActivated: {
      code: "SU202",
      message: "user activated"
    },
    userAlreadyActivated: {
      code: "SU203",
      message: "user already activated"
    },
  },
  /**
   * MR - Master Role
   */
  MR: {
    created: {
      code: "MR201",
      message: "created",
    },
    notFound: {
      code: "MR404",
      message: "role not found",
    },
    updated: {
      code: "MR202",
      message: "role updated",
    },
    deleted: {
      code: "MR204",
      message: "role deleted",
    },
    permissionsUpdated: {
      code: "MR205",
      message: "permissions updated",
    },
    validations: {
      invalidBody: {
        code: "MR400",
        message: "body invalid",
      },
      exists: {
        code: "MR409",
        message: "already exists",
      },
    },
  },
  // role management
  RM: {
    created: {
      code: "RM201",
      message: "created",
    },
    updated: {
      code: "RM202",
      message: "person updated",
    },
    deleted: {
      code: "RM204",
      message: "person deleted",
    },
    notFound: {
      code: "RM404",
      message: "person not found",
    },
    validations: {
      invalidBody: {
        code: "RM400",
        message: "body invalid",
      },
      exists: {
        code: "RM409",
        message: "already exists",
      },
    },
  },
  /**
   * MU - Management User
   */
  MU: {
    created: {
      code: "MU201",
      message: "created",
    },
    updated: {
      code: "MU202",
      message: "user updated",
    },
    deleted: {
      code: "MU204",
      message: "user deleted",
    },
    notFound: {
      code: "MU404",
      message: "management user not found",
    },
    forgetPasswordTimeLimit: {
      code: "MU406",
      message: "already sent 3 times, please try after 24 hours.",
    },
  },
};

(() => {
  const codes = new Set();

  const checkCodesUniqueness = (obj) => {
    for (const key in obj) {
      const code = obj[key].code;
      const message = obj[key].message;

      if (code !== undefined) {
        if (codes.has(code)) {
          throw new Error(`Duplicate code found: ${code}.`);
        } else {
          codes.add(code);
        }
      }

      if (message !== undefined && /[A-Z]/.test(message)) {
        throw new Error(`Capital letters found in message: ${message}`);
      }

      if (typeof obj[key] === "object") {
        checkCodesUniqueness(obj[key]);
      }
    }
  };

  checkCodesUniqueness(module.exports);
})();
