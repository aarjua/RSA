module.exports = {
    logColors: {
        red: `\x1b[31m%s\x1b[0m`
    },
    loginTypes: {
        password: 'password',
        otp: 'otp'
    },
    userTypes: {
        superAdmin: 'super-admin',
        user: 'user'
    },
    loginWith: {
        default: 'default',
        facebook: 'facebook',
        google:'google',
        apple:'apple'
    },
    roles: {
        passenger: 'b4ce3bb1-18cd-46f4-8ad0-99ebb84bb60f',
        driver: 'c7468e01-7b57-4b43-8c7a-78b6986e8d6d',
        passengerWithDriver:'a87a54db-7350-4b5e-89f1-168386915e9b'
    },
    userStatus: {
        created: 'created',
        activated: 'activated',
        deactivated: 'deactivated'
    },
    jwtTokenTypes: {
        verificationCodeValidity: 15,
        maxOtpRequests: 5,
        authenticationTokenTime: 1440,
        accessToken: 'access_token',
        refreshToken: 'refresh_token',
        mailToken: 'mail_token'
    },
    languages: {
        en: 'EN',
        german: 'DE'
    },
    snsTopics: {
        newUser: 'new-user'
    },
    managementPermissions: {
        admin: "admin",
        "roles:read": "roles:read",
        "roles:write": "roles:write",
        "users:read": "users:read",
        "users:write": "users:write",
        // "approval:read": "approval:read",
        // "approval:write": "approval:write",
        "travelPreferences:read": "travelPreferences:read",
        "travelPreferences:write": "travelPreferences:write",
        // "basePrice:read": "basePrice:read",
        // "basePrice:write": "basePrice:write",
        // "commissionRate:read": "commissionRate:read",
        // "commissionRate:write": "commissionRate:write",
        // "reports:read": "reports:read",
        // "reports:write": "reports:write",
        // "rating:read": "rating:read",
        // "rating:write": "rating:write",
        // "payouts:read": "payouts:read",
        // "payouts:write": "payouts:write",
        // "notifications:read": "notifications:read",
        // "notifications:write": "notifications:write",
        // "settings:read": "settings:read",
        // "settings:write": "settings:write",
        "privaryPolicy:read": "privaryPolicy:read",
        "privaryPolicy:write": "privaryPolicy:write",
        "termsConditions:read": "termsConditions:read",
        "termsConditions:write": "termsConditions:write",
        "faq:read": "faq:read",
        "faq:write": "faq:write",
        "aboutUs:read": "aboutUs:read",
        "aboutUs:write": "aboutUs:write",
        "support:read": "support:read",
        "support:write": "support:write",
        "drivers:read": "drivers:read",
        "drivers:write": "drivers:write",
        "offerRides:read": "offerRides:read",
        "offerRides:write": "offerRides:write",
        "bookings:read": "bookings:read",
        "bookings:write": "bookings:write" 
    }
}