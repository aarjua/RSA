const console = require("./logs.config")('yap:auth:config:sns');
const { snsTopics } = require("./enums.config");
const { AWS_ID, AWS_ACCOUNT_ID, AWS_SECRET_KEY, AWS_REGION } = require("./env.config");
const AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION, accessKeyId: AWS_ID, secretAccessKey: AWS_SECRET_KEY });
const sns = new AWS.SNS();

//TODO: Use AWS v3 instead of v2 later on.

const topicName = snsTopics.newUser;
const topicArnRegExp = new RegExp(`.*:${topicName}$`);

sns.listTopics({}, function (err, data) {
    if (err) {
        console.log(err);
    } else {
        const topics = data.Topics.map(topic => topic.TopicArn);
        console.log('topics:', topics)
        if (topics.includes(`arn:aws:sns:${AWS_REGION}:${AWS_ACCOUNT_ID}:${topicName}`)) {
            console.log(`Topic ${topicName} already exists`);
        } else {
            sns.createTopic({ Name: topicName }, function (err, data) {
                if (err) {
                    console.log(err);
                } else {
                    console.log(`Topic ${topicName} created with ARN: ${data.TopicArn}`);
                }
            });
        }
    }
});

module.exports = sns;