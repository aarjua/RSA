YAP

Commands for migrations and seeders

Create a migration file
npx sequelize-cli migration:create --name migration-name

Create a seeder file
npx sequelize-cli seed:generate --name seed-name

Run all seeders
npx sequelize-cli db:seed:all

Undo all seeders
npx sequelize-cli db:seed:undo:all

Run a specifc seeder file
npx sequelize-cli db:seed --seed name-of-the-seeder-file.js

Undo a specific seeder file
npx sequelize-cli db:seed:undo --seed name-of-the-seeder-file.js
