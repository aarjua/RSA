const multer = require("multer");

const inMemoryStorage = multer.memoryStorage();

module.exports = {
  uploadSingle: (fieldName = "files") => {
    console.log(fieldName, "fieldName")
    return multer({ storage: inMemoryStorage }).single(fieldName);
  },
  uploadFiles:  (fields = ["files"]) => {
    const fieldImages = fields.map((item) => {
      return { name: item, maxCount: 10 };
    });
    return multer({ storage: inMemoryStorage }).fields(fieldImages);
    },
  uploadArrayFiles: (field = ["files"], maxCount = 10, next) => {
  try {
    const fieldImages = { name: field, maxCount: maxCount };
    return multer({ storage: inMemoryStorage }).fields([fieldImages]);
  } catch (err) {
    console.log("upload err", err);
    return err;
  }
}
};

