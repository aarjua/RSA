const console = require("../config/logs.config")("yap:auth:middlewares:auth");
const {
  User,
  // Function,
  // ManagementFunctionPermission,
  Permission,
} = require("../models");
const {
  enums: { userStatus, managementPermissions },
  responseCodes,
} = require("../config");
const joi = require("joi");
const {
  token: { validateAndDecodeAccessToken, validateAndDecodeEmailToken },
} = require("../services");

const getTokenFromHeader = (authHeader) => {
  const token = authHeader && authHeader.split(" ")[1];
  if (token == null) {
    throw new Error("Bearer token not present in the headers");
  }
  return token;
};

const validateUserToken = (token, localApproachForPermissions = false) => {
  try {
    const user = joi
      .object({
        id: joi.string().uuid().required(),
        iat: joi.date().required(),
        exp: joi.date().required(),
        ...(localApproachForPermissions && {
          permissions: joi
            .array()
            .min(1)
            .items(joi.string().valid(...Object.values(managementPermissions)))
            .required(),
        }),
      })
      .validate(token);

    return user;
  } catch (err) {
    throw new Error("JWT token validation failed");
  }
};

const checkUserExists = async (id) => {
  console.log(id);
  const where = { id , is_active : true };
  const count = await User.count({ where });
  if (count < 1) {
    throw new Error("user not found");
  }
};

const verifyPermissions = async (
  userData,
  requiredPermissions,
  localApproachForPermissions
) => {
  if (localApproachForPermissions) {
    const { permissions: permissionsGiven } = user;
    if (!Array.isArray(permissionsGiven)) {
      throw new Error("Token not having permissions array");
    }

    // Local approach
    for (const permission of requiredPermissions) {
      if (!permissionsGiven.includes(permission)) {
        throw new Error("Insufficient permissions using local approach");
      }
    }
  } else {
    // DB approach
    console.log("user++", userData)
 
    const { id } = userData;
    const where = { id };

    // const managementUser = await ManagementUser.findOne({
    //   where,
    //   attributes: ["id"],
    //   include: [
    //     {
    //       model: Function,
    //       as: "function",
    //       attributes: ["id"],
    //       include: [
    //         {
    //           model: ManagementFunctionPermission,
    //           include: [
    //             {
    //               model: Permission,
    //               as: "permission",
    //               attributes: ["id", "name"],
    //             },
    //           ],
    //           as: "permissions",
    //           attributes: ["function_id", "permission_id"],
    //         },
    //       ],
    //     },
    //   ],
    // });

    const user = await User.findOne({
      where,
      include: [
        {
          association: "assignedRole",
          include: [
            {
              association: "permissions",
              include: [
                {
                  association: "permission",
                },
              ],
            },
          ],
        },
      ],
    });

    if (!user) {
      throw new Error("Management user not found");
    }
    const { assignedRole } = user.toJSON();
    if (!assignedRole?.permissions.length) {
      throw new Error("Assigned function not having any permissions");
    }

    const { permissions } = assignedRole;
    const permissionsGiven = permissions.map(
      (permission) => permission?.permission?.name
    );

    if (permissionsGiven.includes(managementPermissions.admin)) {
      return true;
    }

    for (const permission of requiredPermissions) {
      if (!permissionsGiven.includes(permission)) {
        throw new Error("Insufficient permissions using DB approach");
      }
    }
  }

  return true;
};

module.exports = {
  auth:
    (requiredPermissions = [], localApproachForPermissions = false) =>
      async (req, res, next) => {
        try {
          const authHeader = req.headers.authorization;
          const token = getTokenFromHeader(authHeader);
          const tokenData = validateAndDecodeAccessToken(token);
          const { value: user } = validateUserToken(
            tokenData,
            localApproachForPermissions
          );

          try {
            await checkUserExists(user.id);
            await verifyPermissions(
              user,
              requiredPermissions,
              localApproachForPermissions
            );
            req.user = user;

            next();
          } catch (err) {
            console.log("catch error",err)
            return res
              .status(401)
              .json({ code: responseCodes.AU.unathourizedAccess.code });
          }
        } catch (err) {
          return res
            .status(401)
            .json({ code: responseCodes.AU.invalidToken.code });
        }
      },
  emailAuth: () => async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      const token = getTokenFromHeader(authHeader);
      const tokenData = validateAndDecodeEmailToken(token);
      const { value: user } = validateUserToken(tokenData);

      try {
        console.log("user", user)
        await checkUserExists(user.id);

        req.user = user;
        next();
      } catch (err) {
        console.log("emailAuth err:", err);
        return res
          .status(401)
          .json({ code: responseCodes.AU.unathourizedAccess.code });
      }
    } catch (err) {
      console.log("emailAuth err:", err);
      return res.status(401).json({ code: responseCodes.AU.invalidToken.code });
    }
  },
  appAuth: () => async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      const token = getTokenFromHeader(authHeader);
      const tokenData = validateAndDecodeAccessToken(token);
      const { value: user } = validateUserToken(tokenData);

      try {
        // await checkUserExists(user.id);

        req.user = user;
        next();
      } catch (err) {
        console.log("emailAuth err:", err);
        return res
          .status(401)
          .json({ code: responseCodes.AU.unathourizedAccess.code });
      }
    } catch (error) {
      console.log("emailAuth err:", error);
      return res.status(401).json({ code: responseCodes.AU.invalidToken.code });
    }
  }
  
};
