const console = require("../config/logs.config")("RSA:auth:services:mail");
const sendGrid = require("@sendgrid/mail");
const {
  enums: { jwtTokenTypes },
  env: { SENDGRID_API_KEY, SEND_GRID_FROM: from, CMS_URL, WEBSITE_URL, STATIC_FILES_URL },
} = require("../config");
sendGrid.setApiKey(SENDGRID_API_KEY);

module.exports = {
  sendMail: async ({ to, subject, template, data }) => {
    console.log("WEBSITE_URL",WEBSITE_URL, "cms_url",CMS_URL)
    if (
      !Object.keys(module.exports).includes(template) &&
      template !== "sendMail" &&
      template !== "parentTemplate"
    )
      throw { message: `Template provided doesn't exist!` };
    const childTemplate = module.exports[template](data);
    const html = module.exports.parentTemplate(childTemplate);
    console.log(`Sending mail to ${to} regarding ${subject}`);
    return await sendGrid.send({ to, from, subject, html });
  },
  parentTemplate: (childTemplate) => {
    return `<!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content=""> 
        <title></title>
      </head>
    
      <body>
      <table border="0" cellspacing="0" cellspacing="0" width="600" align="center" style=" background: #F8F8F8;  width:600px; font-size: 15px; font-family:'Open Sans',Arial,sans-serif; color: #262626; border-collapse:collapse; padding:0px; line-height: 20px; color: #000000;   border: 1px solid #f3efef;">
        <tbody>
          <tr>
            <td style="background: #ffffff;">  
              <p style="text-align:left; margin: 6px 0px 10px 10px;"><img src="${STATIC_FILES_URL}/images/logo.png" alt="" style="max-height: 90px;"></p>                          
            </td>
          </tr>
         
          ${childTemplate}
       
          <tr>
            <td style="padding-left: 15px; padding-right: 15px;">
              <div style="background: #EFEFEF;
              padding: 20px 20px;
              border-radius: 10px;
              margin-bottom: 20px;
              margin-top: 20px; text-align: center; font-size: 12px; line-height: 18px;">
              Disclaimer: The information contained herein (including any accompanying documents) is confidential and is intended solely for the addressee(s).
              If you have erroneously received this message, please immediately delete it and notify the sender. Also, if you are not the intended recipient, you are hereby notified that any disclosure, copying, distribution or taking any action in reliance on the contents of this message or any accompanying document is strictly prohibited and is unlawful. 
            </div>
            </td>
          </tr>
     
        </tbody>
      </table>
      </body>
    </html>
    `;
  },
  accountVerificationTemplate: ({
    token,
    language,
    email,
  }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ?  ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Welcome to the RSA! Your account has been created sccessfully.<br>
                  You still need to confirm your email address.<br>
                  <p style="height:10px; margin: 0;"></p>This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
                  <p style="height:10px; margin: 0;"></p> 
              <div style="text-align: center;">
              <a href="${CMS_URL}/verify-email?token=${token}&email=${email}"
              style="border-radius: 45px;
              background: #0080bb;
              padding: 10px 40px;
              display: inline-block;
              color: #ffffff;
              font-weight: 700;
              text-decoration: none;
              margin-top: 15px;">Confirm email address</a>
              </div>
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      : ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Welcome to the RSA! Your account has been setup successfully.<br>
                  You still have to activate this.<br>
                  <p style="height:10px; margin: 0;"></p>This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
                  <p style="height:10px; margin: 0;"></p> 
              <div style="text-align: center;">
              <a href="${CMS_URL}/verify-email?token=${token}&email=${email}"
              style="border-radius: 45px;
              background: #0080bb;
              padding: 10px 40px;
              display: inline-block;
              color: #ffffff;
              font-weight: 700;
              text-decoration: none;
              margin-top: 15px;">Confirm email address</a>
              </div>
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      ;
  },
  accountVerificationTemplateAdmin: ({
    token,
    language,
    email,
  }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ?  ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Welcome to the RSA! Your account has been created sccessfully.<br>
                  You still need to confirm your email address.<br>
                  <p style="height:10px; margin: 0;"></p>This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
                  <p style="height:10px; margin: 0;"></p> 
              <div style="text-align: center;">
              <a href="${CMS_URL}/auth/login?token=${token}&email=${email}"
              style="border-radius: 45px;
              background: #0080bb;
              padding: 10px 40px;
              display: inline-block;
              color: #ffffff;
              font-weight: 700;
              text-decoration: none;
              margin-top: 15px;">Confirm email address</a>
              </div>
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      : ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Welcome to the RSA! Your account has been setup successfully.<br>
                  You still have to activate this.<br>
                  <p style="height:10px; margin: 0;"></p>This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
                  <p style="height:10px; margin: 0;"></p> 
              <div style="text-align: center;">
              <a href="${CMS_URL}/auth/login?token=${token}&email=${email}"
              style="border-radius: 45px;
              background: #0080bb;
              padding: 10px 40px;
              display: inline-block;
              color: #ffffff;
              font-weight: 700;
              text-decoration: none;
              margin-top: 15px;">Confirm email address</a>
              </div>
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      ;
  },
  accountVerificationOtpTemplate: ({
    otp,
    language,
    email,
  }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ?  ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Thank you for choosing our services. To ensure the security of your account, we have implemented an additional layer of protection through a One-Time Password (OTP). Please find your OTP below:
                  <br>
                  OTP:${otp}<br>
                  <p style="height:10px; margin: 0;"></p>Please note that this OTP is valid for a single use and will expire in ${jwtTokenTypes.verificationCodeValidity} minutes. Do not share this OTP with anyone, including our support team. We will never ask for your OTP.<br>
                  <p style="height:10px; margin: 0;"></p> 
             
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      : ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  Thank you for choosing our services. To ensure the security of your account, we have implemented an additional layer of protection through a One-Time Password (OTP). Please find your OTP below:
                  <br>
                  OTP:${otp}<br>
                  <p style="height:10px; margin: 0;"></p>Please note that this OTP is valid for a single use and will expire in ${jwtTokenTypes.verificationCodeValidity} minutes. Do not share this OTP with anyone, including our support team. We will never ask for your OTP.<br>
                  <p style="height:10px; margin: 0;"></p> 
             
              </div>  

            <div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                <p style="margin: 0;">Thank you,</p>
                <p style="margin: 0;">The RSA Team</p>
            </div>  

          </div> 
      </td>
    </tr>`
      ;
  },
  forgotPasswordTemplate: ({ email, token, language }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ? ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  We’ve received a request to reset the password for the RSA account associated with email id(${email})  <br>
                  This link is active for 48 hours. If you wish to reset  your password later or if the 48 hours have already expired, please contact our support team as well.We will immediately send you a new password reset email.<br>
<p style="height:10px; margin: 0;"></p>
You can reset your password by clicking the link below: 
<p style="height:10px; margin: 0;"></p> 
<div style="text-align: center;"><a href="${CMS_URL}/auth/set-password?token=${token}&email=${email}" style="border-radius: 45px;
background: #0080bb;
padding: 10px 40px;
display: inline-block;
color: #ffffff;
font-weight: 700;
text-decoration: none;
margin-top: 15px;">Click  Click here to reset password </a>
</div>
              </div>  

<div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                  <p style="margin: 0;">Thank you,</p>
                  <p style="margin: 0;">The RSA Team</p>
              </div>  

          </div> 
      </td>
    </tr>`
      : ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  We’ve received a request to reset the password for the RSA account associated with email id(${email})  <br>
                  This link is active for 48 hours. If you wish to reset  your password later or if the 48 hours have already expired, please contact our support team as well.We will immediately send you a new password reset email.<br>
<p style="height:10px; margin: 0;"></p>
You can reset your password by clicking the link below: 
<p style="height:10px; margin: 0;"></p> 
<div style="text-align: center;"><a href="${CMS_URL}/auth/set-password?token=${token}&email=${email}" style="border-radius: 45px;
background: #0080bb;
padding: 10px 40px;
display: inline-block;
color: #ffffff;
font-weight: 700;
text-decoration: none;
margin-top: 15px;">Click here to reset password </a>
</div>
              </div>  

<div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                  <p style="margin: 0;">Thank you,</p>
                  <p style="margin: 0;">The RSA Team</p>
              </div>  

          </div> 
      </td>
    </tr>
    `;
  },
  websiteforgotPasswordTemplate: ({ email, token, language }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ? ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  You have received this e-mail because you should be given access to the RSA committee databases.  <br>
                  You do not want access to the RSA committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
<p style="height:10px; margin: 0;"></p>
This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
<p style="height:10px; margin: 0;"></p> 
<div style="text-align: center;"><a href="${WEBSITE_URL}/set-password?token=${token}&email=${email}" style="border-radius: 45px;
background: #0080bb;
padding: 10px 40px;
display: inline-block;
color: #ffffff;
font-weight: 700;
text-decoration: none;
margin-top: 15px;">Click  Click here to reset password </a>
</div>
              </div>  

<div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                  <p style="margin: 0;">Thank you,</p>
                  <p style="margin: 0;">The RSA Team</p>
              </div>  

          </div> 
      </td>
    </tr>`
      : ` <tr>
      <td style="padding-left: 15px; padding-right: 15px;">  
            <div style="padding:20px 22px 8px 22px;
            border: 1px solid #DCDCDC; 
            border-radius: 10px; margin-top: 20px; background: #ffffff;">  

              <div style="font-size: 15px; color: #161E21; margin-top: 0px; margin-bottom: 5px; line-height: 22px;">
                  <span>Hello ${email},</span>
                  <p style="height:10px; margin: 0;"></p>
                  You have received this e-mail because you should be given access to the RSA committee databases.  <br>
                  You do not want access to the RSA committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
<p style="height:10px; margin: 0;"></p>
This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
<p style="height:10px; margin: 0;"></p> 
<div style="text-align: center;"><a href="${WEBSITE_URL}/set-password?token=${token}&email=${email}" style="border-radius: 45px;
background: #0080bb;
padding: 10px 40px;
display: inline-block;
color: #ffffff;
font-weight: 700;
text-decoration: none;
margin-top: 15px;">Click here to reset password </a>
</div>
              </div>  

<div style="font-size: 15px; color: #161E21; margin-top: 25px; margin-bottom: 5px; line-height: 24px;">
                  <p style="margin: 0;">Thank you,</p>
                  <p style="margin: 0;">The RSA Team</p>
              </div>  

          </div> 
      </td>
    </tr>
    `;
  },
  contactSupportTeamTemplate: ({ email, message, language }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ? `
    <tr>
    <td style="padding: 20px 40px; text-align: left;" valign="top">
    <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
    Hi, 
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">
    Sie haben eine neue Support-Anfrage
    <span style="display: block;padding: 10px 0;"> <strong> E-Mail Adresse:</strong>${email}</span>
    <span style="display: block;padding: 10px 0;"> <strong>Nachricht  :</strong> <i>${message}</i></span>													
		</span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">Vielen Dank! </span>
        <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Ihr Sparkassenverband Bayern</span>
        <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
				  Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
          Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
          Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend eine neue Aktivierungs-E-Mail senden.<br>
          <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team aufnehmen.</a> 
				</span>
				<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch generierte E-Mail. </span>
      </td>		
      </tr>      
    `
      : `
    <tr>
    <td style="padding: 20px 40px; text-align: left;" valign="top">
    <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
    Hi, 
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">
    A new contact support request has submitted with following information 
    <span style="display: block;padding: 10px 0;"> <strong> E-mail address :</strong> ${email}</span>
    <span style="display: block;padding: 10px 0;"> <strong>Message  :</strong> <i> ${message}</i></span>													
		</span>
    <span style="width: 100%; display: inline-block; text-align: left; padding-top: 20px; padding-bottom: 0px;">
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the RSA committee databases. <br>
    You do not want access to the RSA committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
  </td>		
  </tr>       
    `;
  },
  contactSupportUserTemplate: ({ language }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ? `
    <tr>
    <td style="padding: 20px 40px; text-align: left;" valign="top">
    <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
    Hi,
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">
    Vielen Dank für Ihre Anfrage. Wir kümmern uns schnellstmöglich um Ihr Anliegen.
    <span style="display: block;padding: 10px 0;">Bitte haben Sie noch etwas Geduld. Wir melden uns schnellstmöglich bei Ihnen.</span>
    <span style="display: block;padding: 0 0 10px;font-style: italic;">Wir entschuldigen uns nochmals für die Unannehmlichkeiten.</span>
    <span>
    In der Zwischenzeit können Sie einige Schritte durchführen, um das Problem vielleicht selbst zu lösen:
    <span style="display: block;">1. Überprüfen Sie erneut Ihre E-Mail-Adresse und Ihr Passwort. </span>
    <span style="display: block;">2.  Löschen Sie Ihren Browser-Cache und versuchen Sie es erneut. </span>
    <span style="display: block;">3. Klicken Sie auf Passwort vergessen, um das Passwort zurückzusetzen. </span>
    <span style="display: block;">4. Verwenden Sie eine sichere Internetverbindung.  </span>
    </span>
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">Vielen Dank! </span>
      <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Ihr Sparkassenverband Bayern</span>
      <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
			Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
      Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
      Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend eine neue Aktivierungs-E-Mail senden.<br>
      <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team aufnehmen.</a> 
			</span>
			<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch generierte E-Mail. </span>
  </td>
  </tr>
    `
      : `
    <tr>
    <td style="padding: 20px 40px; text-align: left;" valign="top">
    <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
    Hi ,
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">
    We have received your query. We definitely understand your concern, and our team is working on your issue. 
    <span style="display: block;padding: 10px 0;">Please standby, and one of our team members will get back to you with more details/solution ASAP.</span>
    <span style="display: block;padding: 0 0 10px;font-style: italic;">We apologise again for any inconvenience.</span>
    <span>
      Meanwhile, here are some actions you can take that may resolve the issue:
    <span style="display: block;">1. Use correct email and password to login </span>
    <span style="display: block;">2. Clear your browser cache and try  to login again </span>
    <span style="display: block;">3. Forgot your password if you don't remember password </span>
    <span style="display: block;">4. Use a safe internet connection  </span>
    </span>
    </span>
    <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the SVB committee databases. <br>
    You do not want access to the SVB committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
  </td>
  </tr>
    `;
  },
  userDeleteRecordsTemplate: ({ name, language }) => {
    console.log("nammm", name);
    return language === "DE" //TODO: Import language enum & use languages.german
      ? `
      <tr>
      <td style="padding: 20px 40px; text-align: left;" valign="top">
          <span
              style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
              Hallo ${name},
          </span>
  
          <span style="font-size: 15px; color: #565656; line-height: 1.7;">
              As per your request, your data has been removed from our database. Now you are not able to use your
              Sparkassenverband Bayern account. Also, you have been removed from all the committees to which you were
              added.
              <span style="display: block;padding: 6px 0;">For any further queries, please contact our <a href="#"
                      style="color: #E00;">support team. </a> </span>
              <br />
  
  
              <span style="font-size: 15px; color: #565656; line-height: 1.7;">
                  Vielen Dank!
              </span>
              <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">
                  Ihr Sparkassenverband Bayern
              </span>
  
              <span
                  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
                  Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
                  Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen
                  fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
                  Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden
                  bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend
                  eine neue Aktivierungs-E-Mail senden.<br>
                  <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team
                      aufnehmen.</a>
              </span>
              <span style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch
                  generierte E-Mail. </span>
  
  
  
      </td>
  </tr>
    `
      : `
      <tr>
      <td style="padding: 20px 40px; text-align: left;" valign="top">
          <span
              style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
              Hi ${name},
          </span>
  
          <span style="font-size: 15px; color: #565656; line-height: 1.7;">
              As per your request, your data has been removed from our database. Now you are not able to use your
              Sparkassenverband Bayern account. Also, you have been removed from all the committees to which you were
              added.
              <span style="display: block;padding: 6px 0;">For any further queries, please contact our <a href="#"
                      style="color: #E00;">support team. </a> </span>
              <br />
  
  
              <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the SVB committee databases. <br>
    You do not want access to the SVB committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
  
  
      </td>
  </tr>
    `;
  },
  userDeleteCommitteeTemplate: ({ name, language }) => {
    console.log("nammm", name);
    return language === "DE" //TODO: Import language enum & use languages.german
      ? `
      <tr>
      <td style="padding: 20px 40px; text-align: left;" valign="top">
          <span
              style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
              Hi ${name},
          </span>
          <span style="font-size: 15px; color: #565656; line-height: 1.7;">
              As per your request, you have been removed from all the committees in Sparkassenverband Bayern.
              <span style="display: block;padding: 6px 0;">For any further queries, please contact our <a href="#"
                      style="color: #E00;">support team. </a> </span>
              <br />
  
  
              <span style="font-size: 15px; color: #565656; line-height: 1.7;">
                  Vielen Dank!
              </span>
              <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">
                Ihr Sparkassenverband Bayern
              </span>
  
              <span
                  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
                  Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
                  Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen
                  fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
                  Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden
                  bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend
                  eine neue Aktivierungs-E-Mail senden.<br>
                  <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team
                      aufnehmen.</a>
              </span>
              <span style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch
                  generierte E-Mail. </span>
  
  
  
      </td>
  </tr>
    `
      : `
      <tr>
      <td style="padding: 20px 40px; text-align: left;" valign="top">
          <span
              style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
              Hi ${name},
          </span>
          <span style="font-size: 15px; color: #565656; line-height: 1.7;">
              As per your request, you have been removed from all the committees in Sparkassenverband Bayern.
              <span style="display: block;padding: 6px 0;">For any further queries, please contact our <a href="#"
                      style="color: #E00;">support team. </a> </span>
              <br />
  
              <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the SVB committee databases. <br>
    You do not want access to the SVB committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
  
  
  
      </td>
  </tr>
    `;
  },
  honararyWishesTemplate: ({
    salutation,
    first_name,
    last_name,
    language,
    background_info,
    updates_by,
  }) => {
    return language === "DE" //TODO: Import language enum & use languages.german
      ? `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hallo ${salutation} ${first_name} ${last_name},<br>
  ${background_info} <br>
  - ${updates_by}<br>
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Vielen Dank! </span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Ihr Sparkassenverband Bayern</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
    Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
    Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend eine neue Aktivierungs-E-Mail senden.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team aufnehmen.</a> 
    </span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch generierte E-Mail. </span>
</td>
</tr>
  `
      : `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hi ${salutation} ${first_name} ${last_name},<br>
  ${background_info} <br>
  - ${updates_by}<br>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the SVB committee databases. <br>
    You do not want access to the SVB committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
</td>
</tr>
  `;
  },
  userUpdatePasswordTemplate: ({ language }) => {
    return language === "DE"
      ? `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hallo,
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Your password has been changed successfully. Now you can login with your new password.</span><br />
  <span style="width: 100%; display: inline-block; text-align: left; padding-top: 20px; padding-bottom: 0px;">
  <a 
  href="${CMS_URL}/auth/login"   
  style="
    opacity: 1;
    color: #fff;
    font-size: 16px;
    padding: 9px 10px;
    display: block;
    margin: 6px 0 28px;
    max-width: 240px;
    text-align: center;
    text-decoration: none;
    background: #EE0000;
    box-shadow: 0px 3px 46px #00000029;
    border: 1px solid #AA0000;
    border-radius: 5px;
  ">                                                              
  Click here log in
  </a>
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thank you !</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">The RSA Team</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this email because you are supposed to get access to the RSAs. <br>
    You do not want to get access to the RSAen or this email was sent to you by mistake? Then please contact our support team.<br>
    This link will be active for 48 hours. If you want to activate your account later or the 48 hours have already expired, please contact our support team as well. We will send you a new activation email immediately.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team aufnehmen.</a> 
    </span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;">Contact the support team. </span>
</td>
</tr>
  `
      : `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hi,
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Your password has been changed successfully. Now you can login with your new password.</span><br />
  <span style="width: 100%; display: inline-block; text-align: left; padding-top: 20px; padding-bottom: 0px;">
  <a 
  href="${CMS_URL}/auth/login"   
  style="
    opacity: 1;
    color: #fff;
    font-size: 16px;
    padding: 9px 10px;
    display: block;
    margin: 6px 0 28px;
    max-width: 240px;
    text-align: center;
    text-decoration: none;
    background: #EE0000;
    box-shadow: 0px 3px 46px #00000029;
    border: 1px solid #AA0000;
    border-radius: 5px;
  ">                                                              
  Click here log in
  </a>
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thank you ! </span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">The RSA Team</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this email because you are supposed to get access to the RSAs. <br>
    You do not want to get access to the RSAen or this email was sent to you by mistake? Then please contact our support team.<br>
    This link will be active for 48 hours. If you want to activate your account later or the 48 hours have already expired, please contact our support team as well. We will send you a new activation email immediately.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
    </span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email. </span>
</td>
</tr>
  `;
  },
  adminUpdatePasswordTemplate: ({ language: language, password: password }) => {
    return language === "DE"
      ? `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hallo,
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Ihr Passwort wurde von Admin geändert.</span>
  <span style="display: block;margin-top: 15px;font-size: 15px;color: #565656;line-height: 1.7;">Dein neues Passwort ist <span style="background: #f5f5f5;padding: 5px 20px;border: 1px solid #eaeaea;margin: 0 0 0 12px;font-weight: 600;font-size: 19px;border-radius: 3px;">${password}</span></span>
  <br />
  <span style="width: 100%; display: inline-block; text-align: left; padding-top: 10px; padding-bottom: 0px;">
    <a 
    href="${CMS_URL}/auth/login" 
    style="
    opacity: 1;
    color: #fff;
    font-size: 16px;
    padding: 9px 10px;
    display: block;
    margin: 6px 0 28px;
    max-width: 240px;
    text-align: center;
    text-decoration: none;
    background: #EE0000;
    box-shadow: 0px 3px 46px #00000029;
    border: 1px solid #AA0000;
    border-radius: 5px;
  "
  >
  Mit neuem Passwort anmelden
  </a>
  </span>
	<span style="font-size: 15px; color: #565656; line-height: 1.7;display: block;padding-bottom: 15px;">
  Wenn Sie keine Änderungen an Ihrem Konto oder Passwort wünschen, verbinden Sie sich bitte mit unserem <a href="${CMS_URL}/auth/support" style="color: #e00;text-decoration: none;">support team</a> now.
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Vielen Dank! </span>
  <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Ihr Sparkassenverband Bayern</span>
  <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
  Sie haben diese E-Mail erhalten, da Sie Zugang zu den RSAen erhalten sollen. <br>
  Sie möchten keinen Zugang zu den RSAen erhalten, oder diese E-Mail wurde Ihnen fälschlicherweise zugestellt? Dann wenden Sie sich bitte an unser Support-Team.<br>
  Dieser Link ist für 48 Stunden aktiv. Wenn Sie Ihr Konto später aktivieren möchten oder die 48 Stunden bereits abgelaufen sind, kontaktieren Sie bitte ebenfalls unser Support-Team. Wir werden Ihnen umgehend eine neue Aktivierungs-E-Mail senden.<br>
  <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Kontakt zum Support-Team aufnehmen.</a> 
  </span>
  <span  style="font-size: 12px; color: #565656; line-height: 1.7;">Antworten Sie nicht auf diese automatisch generierte E-Mail. </span>
	</td>				
  </tr>                                                 
  `
      : `
  <tr>
  <td style="padding: 20px 40px; text-align: left;" valign="top">
  <span style="font-size: 15px; color: #565656; line-height: 1.7;display:block; padding-bottom: 15px; padding-top:5px;">
  Hello,
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;"> As per your request, your password has been changed by Admin.</span>
  <span style="display: block;margin-top: 15px;font-size: 15px;color: #565656;line-height: 1.7;"> Your new password is <span style="background: #f5f5f5;padding: 5px 20px;border: 1px solid #eaeaea;margin: 0 0 0 12px;font-weight: 600;font-size: 19px;border-radius: 3px;">${password}</span></span>
  <br />
  <span style="width: 100%; display: inline-block; text-align: left; padding-top: 10px; padding-bottom: 0px;">
    <a 
    href="${CMS_URL}/auth/login" 
    style="
    opacity: 1;
    color: #fff;
    font-size: 16px;
    padding: 9px 10px;
    display: block;
    margin: 6px 0 28px;
    max-width: 240px;
    text-align: center;
    text-decoration: none;
    background: #EE0000;
    box-shadow: 0px 3px 46px #00000029;
    border: 1px solid #AA0000;
    border-radius: 5px;
  "
  >
  Login with new password
  </a>
  </span>
	<span style="font-size: 15px; color: #565656; line-height: 1.7;display: block;padding-bottom: 15px;">
  If you didn't want any changes to your account or password, please connect with our <a href="${CMS_URL}/auth/support" style="color: #e00;text-decoration: none;">support team</a> now.
  </span>
  <span style="font-size: 15px; color: #565656; line-height: 1.7;">Thanks very much!</span>
    <span style="font-size: 15px; color: #565656; display:block; padding-top : 12px; line-height: 1.7;">Your Bavarian Savings Banks Association</span>
    <span  style="font-size: 12px; color: #565656; line-height: 1.7;display: block;border-top: 1px solid #E3E3E3;padding-top: 10px;margin-top: 30px;padding-bottom: 15px;">
    You have received this e-mail because you should be given access to the SVB committee databases. <br>
    You do not want access to the SVB committee databases, or this e-mail was sent to you by mistake? Then please contact our support team.<br>
    This link is active for 48 hours. If you wish to activate your account later or if the 48 hours have already expired, please contact our support team as well. We will immediately send you a new activation email.<br>
    <a href="${CMS_URL}/auth/support" style="display: block;text-decoration: none;color: #e00;">Contact the support team.</a> 
		</span>
		<span  style="font-size: 12px; color: #565656; line-height: 1.7;">Do not reply to this automatically generated email.</span>
	</td>				
  </tr>                                                 
  `;
  },
};
