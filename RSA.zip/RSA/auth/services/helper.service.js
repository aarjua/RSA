const console = require("../config/logs.config")('yap:auth:services:helper');
function getPermissionKeyName(key){
    switch (key) {
        case "aboutUs":
        return "About Us"
        case "support":
        return "Support & Contact"
        case "termsConditions":
        return "Terms & Conditions"
        case "travelPreferences":
        return "Travel & Preferences"
        case "offerRides":
        return "Offer Rides"
        case "privaryPolicy":
         return "Privacy Policy"
        default:
            return key;
    }
}
module.exports = {
    replaceObjectEmptyStringKeysWithNull: (obj) => replaceEmptyStringWithNull(obj),
    convertPermissionsToArrayGroups: (arr) => {
        const result = [];
        const temp = {};

        for (const item of arr) {
            const [name, permission] = item.name.split(':');

            if (!temp[name]) {
                temp[name] = {
                    name:getPermissionKeyName(name),
                    permissions: [],
                };
            }

            temp[name].permissions.push({
                id: item.id,
                originalName: item.name,
                name: permission || item.name,
            });
        }

        for (const name in temp) {
            result.push(temp[name]);
        }

        return result;
    },
    formatRoleName: (inputString) => {
        // Remove consecutive spaces
        inputString = inputString.replace(/\s{2,}/g, ' ');
        // Lowercase the string
        inputString = inputString.toLowerCase();
        // Remove spaces before or after "-"
        inputString = inputString.replace(/\s*-\s*/g, '-');
        // Replace spaces with "-"
        inputString = inputString.replace(/\s/g, '-');
        // Remove two consecutive hyphens
        inputString = inputString.replace(/--/g, '-');
        // Trim leading and trailing spaces
        inputString = inputString.trim();
        return inputString;
    },
    isDateEqual: (timestamp1, timestamp2) => {
        const [date1] = module.exports.getDateString(new Date(timestamp1)).split("_");
        const [date2] = module.exports.getDateString(new Date(timestamp2)).split("_");
        return date1 === date2;
    },

    getDateString: (datetime) => {
        const date = [
            datetime.getDate(),
            datetime.getMonth() + 1,
            datetime.getFullYear(),
            datetime.getHours(),
            datetime.getMinutes(),
            datetime.getSeconds(),
        ];
        let dateString = "";
        for (let i = 0; i < date.length; i++) {
            if (date[i] < 10) date[i] = "0" + date[i];
            if (i == 3) dateString += "_" + date[i];
            else dateString += date[i];
        }
        return dateString;
    }
},



    function replaceEmptyStringWithNull(obj) {
        if (obj === null || obj === undefined) {
            return null;
        } else if (Array.isArray(obj)) {
            return obj.map(replaceEmptyStringWithNull);
        } else if (typeof obj === 'object') {
            if (obj instanceof Date) {
                return obj;
            } else {
                return Object.keys(obj).reduce((acc, key) => {
                    acc[key] = replaceEmptyStringWithNull(obj[key]);
                    return acc;
                }, {});
            }
        } else if (obj === '') {
            return null;
        } else {
            return obj;
        }
    };