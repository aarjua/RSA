module.exports = {
  crypto: require("./crypto.service"),
  helper: require("./helper.service"),
  token: require("./token.service"),
  mail: require("./mail.service"),
  sms: require("./sms.service"),
  push: require("./push.notification.service")
  // file: require("./file.service"),
  // awsMethod: require("./s3.service"),
  // sns: require("./sns.service")
};
