const { sns } = require("../config");
const { env: { AWS_ID, AWS_ACCOUNT_ID, AWS_SECRET_KEY, AWS_REGION } } = require("../config");

module.exports = {
    publishMessage: async (topicArn, message) => {
        // sns.publish({ TopicArn: `arn:aws:sns:${AWS_REGION}:${AWS_ACCOUNT_ID}:${topicArn}`, Message: JSON.stringify(message) }, function (err, data) {
        //     if (err) {
        //         console.log('Error publishing message:', err);
        //     } else {
        //         console.log('Message published:', data);
        //     }
        // });
    }
}