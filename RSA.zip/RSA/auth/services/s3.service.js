const console = require("../config/logs.config")('yap:auth:services:s3');
const s3 = require("../config/s3.config");
const { PutObjectCommand } = require('@aws-sdk/client-s3');
const { env: { AWS_BUCKET_NAME } } = require("../config");
const uuid = require("uuid");
module.exports = {
  uploadFileToS3: async (file) => {
    console.log("Uploading file", file);
    const params = {
      Bucket: AWS_BUCKET_NAME,
      Key: uuid.v1() +
        `.${file.originalname.split(".")[1]}`,
      Body: file.buffer,
    };
    try {
      await s3.send(new PutObjectCommand(params));
      console.log(`Successfully uploaded file ${params.Key} to S3 bucket ${AWS_BUCKET_NAME}`);
    } catch (err) {
      console.log(`Error uploading file ${params.Key} to S3 bucket ${AWS_BUCKET_NAME}: ${err}`);
    }
  },
  uploadFilesToS3: async (files) => {
    return new Promise(async (resolve, reject) => {
      const uploadedFiles = await Promise.all(
        files['files'].map((file) => {
          console.log("Uploading file", file);
          return new Promise((resolve, reject) => {
            try {
              const params = {
                Bucket: process.env.AWS_BUCKET_NAME,
                Body: file.buffer,
                Key:
                  uuid.v1() +
                  `.${file.originalname.split(".")[1]}`,
              };
              s3.send(new PutObjectCommand(params), function (err, data) {
                if (err) {
                  console.log(`Error uploading file ${params.Key} to S3 bucket ${AWS_BUCKET_NAME}: ${err}`);
                  reject(err);
                } else {
                  console.log(`Successfully uploaded file ${params.Key} to S3 bucket ${AWS_BUCKET_NAME}`);
                  resolve({ name: file.originalname, url: params.Key });
                }
              });
            }
            catch (err) {
              reject(err);
            }
          })
        })
      );
      resolve(uploadedFiles);
    })
  }
}