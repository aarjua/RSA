const console = require("../config/logs.config")('yap:auth:services:token');
const jwt = require("jsonwebtoken");
const {
    env: {
        JWT_ACCESS_TOKEN_SECRET,
        JWT_REFRESH_TOKEN_SECRET,
        JWT_MAIL_TOKEN_SECRET,
        JWT_ACCESS_TOKEN_VALIDITY,
        JWT_REFRESH_TOKEN_VALIDITY,
        JWT_MAIL_TOKEN_VALIDITY,
    }
} = require("../config");

module.exports = {
    createAccessToken: (body, rememberme = true) => {
        if (rememberme) {
            return jwt.sign(body, JWT_ACCESS_TOKEN_SECRET);
        } else {
            console.log("token time , ", JWT_ACCESS_TOKEN_VALIDITY)
            return jwt.sign(body, JWT_ACCESS_TOKEN_SECRET, { expiresIn: JWT_ACCESS_TOKEN_VALIDITY });
        }
    },
    validateAndDecodeAccessToken: (token) => {
        return jwt.verify(token, JWT_ACCESS_TOKEN_SECRET);
    },
    createRefreshToken: (body) => {
        return jwt.sign(body, JWT_REFRESH_TOKEN_SECRET, { expiresIn: JWT_REFRESH_TOKEN_VALIDITY });
    },
    validateAndDecodeRefreshToken: (token) => {
        return jwt.verify(token, JWT_REFRESH_TOKEN_SECRET);
    },
    createEmailToken: (body) => {
        console.log("here++++ forgot password token")
        return jwt.sign(body, JWT_MAIL_TOKEN_SECRET, { expiresIn: JWT_MAIL_TOKEN_VALIDITY });
    },
    validateAndDecodeEmailToken: async(token) => {
        console.log("here++++ reset password")
        return jwt.verify(token, JWT_MAIL_TOKEN_SECRET);
    }
};
