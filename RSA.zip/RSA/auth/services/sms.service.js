const { env: { TWILIO_PHONE_NUMBER, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_SERVICEID } } = require("../config");

const client = require('twilio')('AC177d5ce337efce6a49da85c2f9162d3c', '66f1f68029523444adfa2cd90a249cf4');

module.exports = {
    sendsms: async (data) => {
        return new Promise(async (resolve, reject) => {
            try {

                client.messages.create({
                    body: data.text,
                    from: TWILIO_PHONE_NUMBER,
                    to: data.mobileno
                })
                    .then(message => {
                        console.log('\x1b[32m%s\x1b[0m', message.sid);
                        return resolve({ "Massage": message.sid, "Status": true })
                    }).catch((error) => {
                        console.error(error);
                        return resolve({ "Massage": error, "Status": false });
                    });
            } catch (e) {
                console.log(e);
            }
        })
    },
    sendbulksms: async (data) => {
        return new Promise(async (resolve, reject) => {
            try {
                Promise.all(
                    data.mobileno.map(number => {
                        return client.messages.create({
                            to: number,
                            from: TWILIO_PHONE_NUMBER,
                            body: data.text
                        });
                    })
                )
                    .then(message => {
                        console.log('\x1b[32m%s\x1b[0m', "message sent successfully");
                        return resolve({ "Massage": message, "Status": true })
                    }).catch((error) => {
                        console.error(error);
                        return resolve({ "Massage": error, "Status": false });
                    });

            } catch (e) {
                console.log(e);
            }
        })
    },
    generateOTP: async () => {
        return Math.floor(1000 + Math.random() * 9000);
    },
    // Function to send OTP code via SMS
    sendOTPviaSMS: async (toPhoneNumber, otpCode) => {
        const message = `Your OTP code is: ${otpCode}`;
        client.messages
            .create({
                body: message,
                from: TWILIO_PHONE_NUMBER,
                to: toPhoneNumber,
            })
            .then((message) => console.log(`OTP sent. Message SID: ${message.sid}`))
            .catch((error) => console.error('Error sending OTP:', error));

    },
}