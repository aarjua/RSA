const {
  env: { USER_SERVICE_URL },
} = require("../config");
const {
  makeRestCall,
  RestClientMethodEnum,
} = require("../restClientService/restClientService");

module.exports = {
  getPassengerBookingList: async (userId) => {
    try {
      const url = USER_SERVICE_URL + "/profiles/get_passenger_booking_list/" + userId;
      const response = await makeRestCall(
        RestClientMethodEnum.GET,
        url,
        null,
        null
      );
      return response;
    } catch (err) {
      throw err;
    }
  },
};
