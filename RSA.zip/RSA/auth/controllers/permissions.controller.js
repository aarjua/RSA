const { Permission } = require("../models");
const joi = require("joi");
const {
    responseCodes,
    db: { Sequelize: { Op } }
} = require("../config");

const { helper: { convertPermissionsToArrayGroups } } = require("../services")

module.exports = {
    getAll: async (req, res) => {
        try {
            const { search, limit, page, sortBy = 'name', orderBy = 'ASC' } = await joi.object({
                search: joi.string(),
                limit: joi.number(),
                page: joi.number(),
                sortBy: joi.string().default('name'),
                orderBy: joi.string().valid('ASC', 'DESC').default('ASC')
            }).validateAsync(req.query);

            const instances = await Permission.findAll({
                where: {
                    [Op.and]: [
                        search ? { name: { [Op.like]: `%${search}%` } } : {},
                    ]
                },
                attributes: ['id', 'name'],
                order: [[sortBy, orderBy]],
                ...((limit && page) && ({ limit: parseInt(limit) })),
                ...((limit && page) && ({ offset: (parseInt(page) - 1) * parseInt(limit) }))
            });

            return res.status(200).json(convertPermissionsToArrayGroups(instances));
        } catch (err) {
            console.error('err:', err)
            return res.status(500).json({ code: responseCodes.SE.internalError.code });
        }
    }
}