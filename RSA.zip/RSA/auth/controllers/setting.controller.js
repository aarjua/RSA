const {
  Sequelize: { Op },
} = require("../config/db.config");
const { AppSetting, ThemeMaster } = require("../models");
const { responseCodes } = require("../config");
const joi = require("joi");
const { s3 } = require("../services");

module.exports = {
  add: async (req, res) => {
    try {
      // let file ;
      // if (req.file) {
      //   const { url } = await s3.uploadFileToS3(req.file);
      //   req.body.business_logo = url;
      //   console.log("url", url, req.body.business_logo)
      //   //  file = await s3.uploadFileToS3(req.file);
      // }
      const value = await joi
        .object({
          business_name: joi.string().trim().required(),
          business_logo: joi.string().trim().allow(...[null, '']).optional(),
          business_theme_colour: joi.string().uuid().required(),
          user_id: joi.string().uuid().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.IN.invalidBody.code });
        });

      const isAppAlreadyExist = await AppSetting.findOne({
        where: { user_id: value.user_id },
      });
      if (isAppAlreadyExist) {
        // console.log("isAppAlreadyExistisAppAlreadyExist",isAppAlreadyExist)
        await isAppAlreadyExist.update(value)
        return res.status(200).json({ code: responseCodes.AU.themeUpdated.code });
      }
      await AppSetting.create(value);
      return res.status(201).json({ code: responseCodes.AU.themeSet.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      const { id } = req.params;
      const interestList = await ThemeMaster.findAll({
        // where: {
        //    user_id: req.params.id,
        // },
        // attributes: ["id", "name", "position"],
        include: [
          {
            association: "setting",
            // where: {
            //   user_id: id,
            // },
            required: true,
          },
        ],
      });
      if (!interestList) {
        return res.status(400).json({ code: responseCodes.AU.notFound.code }); //need to change the status code
      }
      return res.status(200).json(interestList);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getUserSetting: async (req, res) => {
    try {
      const { id } = req.params;

      const interestList = await AppSetting.findAll({});
      if (!interestList) {
        return res.status(400).json({ code: responseCodes.AU.notFound.code }); //need to change the status code
      }
      const themetList = await ThemeMaster.findOne({
        where: {
          id: interestList[0].dataValues.business_theme_colour,
        },
      });
      if(themetList){
        interestList[0].dataValues.theme_name = themetList.theme_name
        interestList[0].dataValues.theme_preview = themetList.theme_preview
      }else{
      
        interestList.dataValues.theme_name = ""
        interestList.dataValues.theme_preview = ""
      }
      return res.status(200).json(interestList);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      const { id } = req.params;
      // if (req.file) {
      //   const { url } = (req.body.business_logo = await s3.uploadFileToS3(
      //     req.file
      //   ));
      //   req.body.business_logo = url;
      //   //  file = await s3.uploadFileToS3(req.file);
      // }
      const value = await joi
        .object({
          business_name: joi.string().trim().allow(...[null, '']),
          // business_logo: joi.string().trim().allow(...[null, '']),
          business_theme_colour: joi.string().uuid().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.IN.invalidBody.code });
        });
      const appData = await AppSetting.findOne({
        where: {
          id,
        },
      });
      if (appData) {
        return res
          .status(400)
          .json({ code: responseCodes.IN.appDataNotFound });
      }
      await appData.update(value, { where: { id } });
      return res.status(200).json({ code: responseCodes.IN.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const appName = await AppSetting.destroy({
        where: {
          id,
        },
      });
      if (appName < 1) {
        return res.status(400).json({ code: responseCodes.IN.notFound.code }); //need to change the status code
      }
      return res.status(200).json({ code: responseCodes.IN.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },

};
