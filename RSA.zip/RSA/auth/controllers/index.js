module.exports = {
    AuthController: require("./auth.controller"),
    PermissionController: require("./permissions.controller"),
    RoleController: require("./roles.controller"),
    SettingController: require("./setting.controller")
} 