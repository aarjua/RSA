const { Role, RolePermission } = require("../models");
const joi = require("joi");
const { responseCodes } = require("../config");
const {
  Sequelize: { Op },
  sequelize,
} = require("../config/db.config");
const { helper: { formatRoleName } } = require("../services");

const schema = joi.object({
  name: joi.string().required().custom((value, helpers) => {
    return formatRoleName(value);
  }),
  created_by: joi.string().uuid(),
  position: joi.number().required(),
});

module.exports = {
  get: async (req, res) => {
    try {
      const { id } = req.params;

      const role = await Role.findOne({ where: { id } });
      if (!role) {
        return res.status(404).json({ code: responseCodes.MR.notFound.code });
      }
      return res.status(200).json({ data: role });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAll: async (req, res) => {
    try {
      const {
        search,
        limit,
        page,
        sortBy = "position",
        orderBy = "ASC",
      } = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().default("position"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
        })
        .validateAsync(req.query);
      const searchData = search || "";

      const where = {
        [Op.or]: [
          { "name": { [Op.like]: `%${searchData}%` } },
          { "position": { [Op.like]: `%${searchData}%` } },
        ]
      }
      const instances = await Role.findAll({
        where,
        attributes: ["id", "name", "position"],
        include: [
          {
            association: "permissions",
            attributes: ["permission_id"],
          },
        ],
        order: [[sortBy, orderBy]],
        ...(limit && page && { limit: parseInt(limit) }),
        ...(limit &&
          page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
      });
      const count = await Role.count()
      // console.log(instances, "kfjgksdjgksd")
      return res.status(200).json({ data: instances, count });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  add: async (req, res) => {
    try {
      const { error, value } = schema.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res
          .status(400)
          .json({ code: responseCodes.RM.validations.invalidBody.code });
      }
      console.log(value.name);
      const rolename = await Role.findOne({
        where: {
          [Op.and]: [{ name: value.name }],
        },
        paranoid: true,
      });
      if (rolename) {
        return res
          .status(400)
          .json({ code: responseCodes.RM.validations.exists.code });
      }
      const roleSequence = await Role.findOne({
        where: {
          [Op.and]: [{ position: value.position }],
        },
        paranoid: true,
      });
      const roleStartPosition = value.position;
      const roleEndPosition = (await Role.count()) + 1;
      if (!roleSequence) {
        var role = await Role.create(value);
      } else {
        await Role.increment("position", {
          by: 1,
          where: {
            position: {
              [Op.between]: [roleStartPosition, roleEndPosition],
            },
          },
        });
        var role = await Role.create(value);
      }
      console.log("role:", role.dataValues);
      return res.status(201).json({ code: responseCodes.RM.created.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      const { error, value } = schema.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res
          .status(400)
          .json({ code: responseCodes.MR.validations.invalidBody.code });
      }

      const { id } = req.params;

      const role = await Role.findOne({ where: { id } });
      if (!role) {
        return res.status(404).json({ code: responseCodes.MR.notFound.code });
      }

      const sameRoleWithNameExists = await Role.findOne({
        where: { name: value.name, id: { [Op.ne]: id } },
        attributes: ["id", "name", "position"],
      });
      if (sameRoleWithNameExists) {
        return res
          .status(400)
          .json({ code: responseCodes.MR.validations.exists.code });
      }

      if (Number(value.position) !== Number(role.dataValues.position)) {
        const oldRolePosition = Number(role.dataValues.position);
        const currentRolePosition = Number(value.position);

        if (oldRolePosition > currentRolePosition) {
          await Role.increment("position", {
            by: 1,
            where: {
              position: {
                [Op.between]: [currentRolePosition, oldRolePosition],
              },
            }
          })
        } else {
          await Role.decrement("position", {
            by: 1,
            where: {
              position: {
                [Op.between]: [oldRolePosition, currentRolePosition],
              },
            }
          })
        }
      }

      await role.update(value);

      return res.json({ code: responseCodes.MR.updated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const role = await Role.findOne({ where: { id: req.params.id } });
      if (!role) {
        return res.status(404).json({ code: responseCodes.MR.notFound.code });
      }

      const roleStartPosition = Number(role.dataValues.position) + 1;
      const roleEndPosition = await Role.count();

      await Role.decrement("position", {
        by: 1,
        where: {
          position: {
            [Op.between]: [roleStartPosition, roleEndPosition],
          },
        },
      });

      await role.destroy();
      return res.status(200).json({ code: responseCodes.MR.deleted.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addUpdatePermissions: async (req, res) => {
    try {
      const value = await joi
        .array()
        .items(
          joi.object({
            role_id: joi.string().uuid().required(),
            permissions: joi.array().items(joi.string().uuid()).required(),
          })
        )
        .validateAsync(req.body)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.MR.validations.invalidBody.code });
        });

      for (const { role_id, permissions } of value) {
        await RolePermission.destroy({ where: { role_id } });
        await RolePermission.bulkCreate(
          permissions.map((permission_id) => {
            return { role_id, permission_id };
          })
        );
      }

      return res.json({ code: responseCodes.MR.permissionsUpdated.code });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getLatestPosition: async (req, res) => {
    try {
      const { position } = await Role.findOne({
        order: [["position", "DESC"]],
        attributes: ["position"],
      });

      return res.json({ position: position ? Number(position) : 1 });
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
};
