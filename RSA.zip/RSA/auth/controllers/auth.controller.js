const console = require("../config/logs.config")("yap:auth:controllers:auth");
const joi = require("joi");
const { User, Role, VerificationCode, ThemeMaster } = require("../models");
const { responseCode } = require("../config/responseCodes.config");
const {
  enums: { userStatus, snsTopics, jwtTokenTypes },
  responseCodes,
  env: { LOGIN_ATTEMPTS_MAX_COUNT, FORGET_PASSWORD_RESEND_EMAIL_COUNT, CMS_URL },
  db: {
    Sequelize: { Op, literal },
  },
} = require("../config");
const {
  token: { createAccessToken, createEmailToken, validateAndDecodeEmailToken },
  mail: { sendMail },
  crypto: { compareHash, hash },
  sms: { generateOTP, sendOTPviaSMS },
  helper: { isDateEqual },
  push: { sendmessage },
} = require("../services");
const { loginWith, languages, roles } = require("../config/enums.config");
const { getPassengerBookingList } = require("../internalServiceRepositories/internalUserServiceRepository");



module.exports = {
  otpRegister: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      console.log("bdjghsdf", type)
      if (type == "contact") {
        const { contact } = await joi
          .object({
            contact: joi.string().required()
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });


        // Generate OTP code
        const otpCode = await generateOTP();
        const currentDate = new Date();
        const validTill = new Date(
          currentDate.getTime() + jwtTokenTypes.verificationCodeValidity * 60 * 1000
        );
        const otp = await VerificationCode.create({
          contact: contact,
          otp: otpCode,
          valid_till: validTill
        });
        console.log("otp")
        await sendOTPviaSMS(contact, otpCode);
        console.log("otpget ")
        return res
          .status(200)
          .json({ code: responseCodes.AU.otpSentSuccessfully.code, id: otp.id, otp: otpCode });
      } else {
        const { email } = await joi
          .object({
            email: joi.string().email().required()
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code, description: err });
          });

        // Generate OTP code
        const otpCode = await generateOTP();
        const currentDate = new Date();
        const validTill = new Date(
          currentDate.getTime() + jwtTokenTypes.verificationCodeValidity * 60 * 1000
        );
        const otp = await VerificationCode.create({
          contact: email,
          otp: otpCode,
          valid_till: validTill
        });
        await sendMail({
          to: email,
          subject: `Email Verification`,
          template: `accountVerificationOtpTemplate`,
          data: { otp: otpCode, language: languages.english, email: email }
        });

        return res
          .status(200)
          .json({ code: responseCodes.AU.otpSentSuccessfully.code, id: otp.id, otp: otpCode });
      }


    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  resendOtp: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (type == "contact") {
        const { contact, id } = await joi
          .object({
            contact: joi.string().required(),
            id: joi.string().uuid(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
        // Generate OTP code
        const otpCode = await generateOTP();
        const currentDate = new Date();
        const validTill = new Date(
          currentDate.getTime() + jwtTokenTypes.verificationCodeValidity * 60 * 1000
        );
        const verificationCode = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (verificationCode) {
          if (isDateEqual(verificationCode.valid_till, validTill)) {
            if (verificationCode.sent_count >= jwtTokenTypes.maxOtpRequests) {
              return res
                .status(400)
                .json({ code: responseCodes.AU.otpMaxAttempt.code });
            }
            else {
              const sentCount = verificationCode.sent_count + 1;
              await verificationCode.update({
                otp: otpCode,
                valid_till: validTill,
                sent_count: sentCount,
              });
            }
          } else {
            await verificationCode.update({
              otp: otpCode,
              valid_till: validTill,
              sent_count: 1,
            });
          }
          await sendOTPviaSMS(contact, otpCode);

          return res
            .status(200)
            .json({ code: responseCodes.AU.otpResentSuccessfully.code, id: verificationCode.id, otp: otpCode });

        } else {
          let newotp = await VerificationCode.create({
            contact: contact,
            otp: otpCode,
            valid_till: validTill
          });
          await sendOTPviaSMS(contact, otpCode);

          return res
            .status(200)
            .json({ code: responseCodes.AU.otpResentSuccessfully.code, id: newotp.id, otp: otpCode });
        }
      } else {
        const { email, id } = await joi
          .object({
            email: joi.string().email().required(),
            id: joi.string().uuid(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
        // Generate OTP code
        const otpCode = await generateOTP();
        const currentDate = new Date();
        const validTill = new Date(
          currentDate.getTime() + jwtTokenTypes.verificationCodeValidity * 60 * 1000
        );
        const verificationCode = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (verificationCode) {
          if (isDateEqual(verificationCode.valid_till, validTill)) {
            if (verificationCode.sent_count >= jwtTokenTypes.maxOtpRequests) {
              return res
                .status(400)
                .json({ code: responseCodes.AU.otpMaxAttempt.code });
            }
            else {
              const sentCount = verificationCode.sent_count + 1;
              await verificationCode.update({
                otp: otpCode,
                valid_till: validTill,
                sent_count: sentCount,
              });
            }
          } else {
            await verificationCode.update({
              otp: otpCode,
              valid_till: validTill,
              sent_count: 1,
            });
          }

          await sendMail({
            to: email,
            subject: `Email Verification`,
            template: `accountVerificationOtpTemplate`,
            data: { otp: otpCode, language: languages.english, email: email }
          });

          return res
            .status(200)
            .json({ code: responseCodes.AU.otpResentSuccessfully.code, id: verificationCode.id, otp: otpCode });

        } else {
          let newotp = await VerificationCode.create({
            contact: contact,
            otp: otpCode,
            valid_till: validTill
          });
          await sendOTPviaSMS(contact, otpCode);

          return res
            .status(200)
            .json({ code: responseCodes.AU.otpResentSuccessfully.code, id: newotp.id, otp: otpCode });
        }
      }

    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  otpVerification: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (type == "contact") {
        const { contact, otp, id } = await joi
          .object({
            contact: joi.string().required(),
            otp: joi.string().required(),
            id: joi.string().uuid(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const doesContactAlreadyExist = await User.count({
          where: { id: { [Op.ne]: req.user.id }, contact },
        });

        if (doesContactAlreadyExist) {
          console.log(`Account already exists with contact ${contact}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountContactAlreadyExists.code,
          });
        }

        const otpget = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (!otpget) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpNotFound.code });
        }
        if (otpget.otp != otp) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.invalidOtp.code });
        }

        if (new Date() >= new Date(otpget.valid_till)) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpExpired.code });
        }

        // const userfind = await User.findOne({
        //   where: {
        //     contact,
        //   },
        // });
        // if (!userfind) {
        //   return res
        //     .status(400)
        //     .json({ code: responseCodes.AU.contactNotExist.code });
        // }

        const user = await User.update({
          contact: contact,
          is_contact_verified: true,
        },
          { where: { id: req.user.id } });
        const deletedOtp = await otpget.destroy();

        return res.status(200).json({ code: responseCodes.AU.otpVerified.code });
      } else {
        const { email, otp, id } = await joi
          .object({
            email: joi.string().required(),
            otp: joi.string().required(),
            id: joi.string().uuid(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const doesEmailAlreadyExist = await User.count({
          where: { id: { [Op.ne]: req.user.id }, email },
        });

        if (doesEmailAlreadyExist) {
          console.log(`Account already exists with email ${email}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountEmailAlreadyExists.code,
          });
        }

        const otpget = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (!otpget) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpNotFound.code });
        }
        if (otpget.otp != otp) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.invalidOtp.code });
        }

        if (new Date() >= new Date(otpget.valid_till)) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpExpired.code });
        }

        // const userfind = await User.findOne({
        //   where: {
        //     email,
        //   },
        // });
        // if (!userfind) {
        //   return res
        //     .status(400)
        //     .json({ code: responseCodes.AU.validations.emailNotExist.code });
        // }

        const user = await User.update({
          email,
          is_email_verified: true,
        },
          { where: { id: req.user.id } });
        const deletedOtp = await otpget.destroy();

        return res.status(200).json({ code: responseCodes.AU.otpVerified.code });
      }
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  findUnique: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (type == "contact") {
        const { contact } = await joi
          .object({
            contact: joi.string().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const doesContactAlreadyExist = await User.count({
          where: { id: { [Op.ne]: req.user.id }, contact },
        });

        if (doesContactAlreadyExist) {
          console.log(`Account already exists with contact ${contact}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountContactAlreadyExists.code,
          });
        }

        return res.status(200).json({ code: responseCodes.AU.contactNotExist.code });
      } else {
        const { email } = await joi
          .object({
            email: joi.string().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const doesEmailAlreadyExist = await User.count({
          where: { id: { [Op.ne]: req.user.id }, email },
        });

        if (doesEmailAlreadyExist) {
          console.log(`Account already exists with email ${email}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountEmailAlreadyExists.code,
          });
        }

        return res.status(200).json({ code: responseCodes.AU.emailNotExist.code });
      }
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  googleLogin: async (req, res) => {
    try {
      const { email, role_id } = await joi
        .object({
          email: joi.string().email().required(),
          role_id: joi.string().uuid()
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });
      const user = await User.findOne({
        where: { email },
      });
      if (user) {
        const accessToken = createAccessToken({ id: user.id });
        return res.status(200).json({ accessToken: accessToken });
      } else {
        const user = await User.create({
          email: email,
          login_with: loginWith.google,
          ...(role_id && { role_id }),
          is_active: true
        });
        const accessToken = createAccessToken({ id: user.id });
        return res.status(200).json({ accessToken: accessToken, id: user.id });
      }
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  login: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (type == "google") {
        const { email, firebase_token, device_id } = await joi
          .object({
            email: joi.string().email().required(),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const user = await User.findOne({
          where: { email },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (!user) {
          const createUser = await User.create({
            email,
            login_with: loginWith.google,
            role_id: roles.passenger,
            is_active: true,
            lang: languages.en,
          });
          console.log(createUser.id)
          const accessToken = createAccessToken({ id: createUser.id });
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              firebase_token,
              device_id
            },
            { where: { id: createUser.id } }
          );

          return res.status(200).json({ accessToken: accessToken, id: createUser.id });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        }

        if (user.dataValues.is_active == false) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.accountNotActive.code });
        }

        const role = user?.dataValues;

        if (!role.role_id) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        // const permission = role.assignedRole.dataValues.permissions.map(
        //   (item) => item.dataValues.permission.name
        // );

        const userJson = user.toJSON();
        if (userJson?.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
          console.log(`max attempts reached`);
          return res.status(400).json({
            code: responseCodes.AU.accountBlocked.code,
            login_attempts_count: userJson?.login_attempts_count,
          });
        }
        // if (!compareHash(password, userJson?.password)) {
        //   console.log(`wrong password`);
        //   await user.increment("login_attempts_count");
        //   return res.status(400).json({
        //     code: responseCodes.AU.invalidEmailOrPassword.code,
        //     login_attempts_count: userJson?.login_attempts_count + 1,
        //   });
        // }

        // if (!compareHash(password, user?.password)) {
        //   console.log(`wrong password`);
        //   return res
        //     .status(400)
        //     .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        // }

        const accessToken = createAccessToken({ id: user.id });
        await User.update(
          {
            device_id: ""
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            login_attempts_count: 0,
            firebase_token,
            device_id
          },
          { where: { id: userJson.id } }
        );

        return res.status(200).json({ accessToken });
      } else if (type == "facebook") {
        const { facebook_id, email, firebase_token, device_id } = await joi
          .object({
            facebook_id: joi.string().required(),
            email: joi.string().trim().allow(...[null, '']),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const user = await User.findOne({
          where: { facebook_id },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (!user) {
          let id;
          if (email) {
            const emailUser = await User.findOne({
              where: { email },
              include: [
                {
                  association: "assignedRole"
                },
              ],
            });
            if (emailUser) {
              const role = emailUser?.dataValues;

              if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
                var createUser = await User.create({
                  facebook_id,
                  login_with: loginWith.facebook,
                  role_id: roles.passenger,
                  is_active: true,
                  lang: languages.en,
                });
                id = createUser.id;
              } else {
                await User.update(
                  {
                    facebook_id,
                    firebase_token,
                    device_id
                  },
                  { where: { id: emailUser.id } }
                );
                id = emailUser.id;
              }
            } else {
              var createUser = await User.create({
                facebook_id,
                email,
                login_with: loginWith.facebook,
                role_id: roles.passenger,
                is_active: true,
                lang: languages.en,
              });
              id = createUser.id;
            }
          } else {
            var createUser = await User.create({
              facebook_id,
              email,
              login_with: loginWith.facebook,
              role_id: roles.passenger,
              is_active: true,
              lang: languages.en,
            });
            id = createUser.id;
          }

          const accessToken = createAccessToken({ id: id });
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              firebase_token,
              device_id
            },
            { where: { id: id } }
          );

          return res.status(200).json({ accessToken: accessToken, id: id });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        }

        if (user.dataValues.is_active == false) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.accountNotActive.code });
        }

        const role = user?.dataValues;

        if (!role.role_id) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        // const permission = role.assignedRole.dataValues.permissions.map(
        //   (item) => item.dataValues.permission.name
        // );

        const userJson = user.toJSON();
        if (userJson?.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
          console.log(`max attempts reached`);
          return res.status(400).json({
            code: responseCodes.AU.accountBlocked.code,
            login_attempts_count: userJson?.login_attempts_count,
          });
        }
        // if (!compareHash(password, userJson?.password)) {
        //   console.log(`wrong password`);
        //   await user.increment("login_attempts_count");
        //   return res.status(400).json({
        //     code: responseCodes.AU.invalidEmailOrPassword.code,
        //     login_attempts_count: userJson?.login_attempts_count + 1,
        //   });
        // }

        // if (!compareHash(password, user?.password)) {
        //   console.log(`wrong password`);
        //   return res
        //     .status(400)
        //     .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        // }

        console.log("Generating access token");

        const accessToken = createAccessToken({ id: user.id });
        await User.update(
          {
            device_id: ""
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            login_attempts_count: 0,
            firebase_token,
            device_id
          },
          { where: { id: userJson.id } }
        );

        return res.status(200).json({ accessToken });
      } else if (type == "apple") {
        const { apple_id, email, firebase_token, device_id } = await joi
          .object({
            apple_id: joi.string().required(),
            email: joi.string().trim().allow(...[null, '']),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const user = await User.findOne({
          where: { apple_id },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (!user) {
          let id;
          if (email) {
            const emailUser = await User.findOne({
              where: { email },
              include: [
                {
                  association: "assignedRole"
                },
              ],
            });
            if (emailUser) {
              const role = emailUser?.dataValues;

              if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
                var createUser = await User.create({
                  apple_id,
                  login_with: loginWith.apple,
                  role_id: roles.passenger,
                  is_active: true,
                  lang: languages.en,
                });
                id = createUser.id;
              } else {
                await User.update(
                  {
                    apple_id,
                    firebase_token,
                    device_id
                  },
                  { where: { id: emailUser.id } }
                );
                id = emailUser.id;
              }

            } else {
              var createUser = await User.create({
                apple_id,
                email,
                login_with: loginWith.apple,
                role_id: roles.passenger,
                is_active: true,
                lang: languages.en,
              });
              id = createUser.id;
            }
          } else {
            var createUser = await User.create({
              apple_id,
              email,
              login_with: loginWith.apple,
              role_id: roles.passenger,
              is_active: true,
              lang: languages.en,
            });
            id = createUser.id;
          }

          const accessToken = createAccessToken({ id: id });
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              firebase_token,
              device_id
            },
            { where: { id: id } }
          );

          return res.status(200).json({ accessToken: accessToken, id: id });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        }

        if (user.dataValues.is_active == false) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.accountNotActive.code });
        }

        const role = user?.dataValues;

        if (!role.role_id) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }

        // const permission = role.assignedRole.dataValues.permissions.map(
        //   (item) => item.dataValues.permission.name
        // );

        const userJson = user.toJSON();
        if (userJson?.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
          console.log(`max attempts reached`);
          return res.status(400).json({
            code: responseCodes.AU.accountBlocked.code,
            login_attempts_count: userJson?.login_attempts_count,
          });
        }
        // if (!compareHash(password, userJson?.password)) {
        //   console.log(`wrong password`);
        //   await user.increment("login_attempts_count");
        //   return res.status(400).json({
        //     code: responseCodes.AU.invalidEmailOrPassword.code,
        //     login_attempts_count: userJson?.login_attempts_count + 1,
        //   });
        // }

        // if (!compareHash(password, user?.password)) {
        //   console.log(`wrong password`);
        //   return res
        //     .status(400)
        //     .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
        // }

        console.log("Generating access token");

        const accessToken = createAccessToken({ id: user.id });
        await User.update(
          {
            device_id: ""
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            login_attempts_count: 0,
            firebase_token,
            device_id
          },
          { where: { id: userJson.id } }
        );

        return res.status(200).json({ accessToken, id: user.id });
      } else {
        const { contact, otp, id, rememberme, firebase_token, device_id } = await joi
          .object({
            contact: joi.string().required(),
            otp: joi.string().required(),
            id: joi.string().uuid(),
            rememberme: joi.boolean().required(),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const otpget = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (!otpget) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpNotFound.code });
        }
        if (otpget.otp != otp) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.invalidOtp.code });
        }
        if (new Date() >= new Date(otpget.valid_till)) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpExpired.code });
        }

        const user = await User.findOne({
          where: { contact },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
          ],
          include: [
            {
              association: "assignedRole"
            },
          ],
        });

        if (!user) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.invalidContactOrOtp.code });
        }

        if (user.dataValues.is_active == false) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.accountNotActive.code });
        }

        const role = user?.dataValues;

        if (!role.role_id) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }
        if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
          return res
            .status(400)
            .json({ error: responseCodes.AU.unathourizedAccess });
        }
        const userJson = user.toJSON();
        if (userJson?.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
          console.log(`max attempts reached`);
          return res.status(400).json({
            code: responseCodes.AU.accountBlocked.code,
            login_attempts_count: userJson?.login_attempts_count,
          });
        }

        const accessToken = createAccessToken({ id: user.id, rememberme });
        const deletedOtp = await otpget.destroy();
        await User.update(
          {
            device_id: ""
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            login_attempts_count: 0,
            firebase_token,
            device_id
          },
          { where: { id: userJson.id } }
        );

        return res.status(200).json({ accessToken, id: user.id });
      }
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  signup: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (type == "google") {
        const { email, firebase_token, device_id } = await joi
          .object({
            email: joi.string().email().required(),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const user = await User.findOne({
          where: { email },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
            "is_email_verified"
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (user) {
          if (user.dataValues.is_active == false) {
            return res
              .status(400)
              .json({ code: responseCodes.AU.accountNotActive.code });
          }
          // console.log("dbgfjhdgjd e,ail+++", user)
          if (user.dataValues.is_email_verified == false) {
            return res
              .status(400)
              .json({ code: responseCodes.AU.emailNotActive.code });
          }
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              firebase_token,
              device_id,
              is_email_verified: true,
            },
            { where: { email } }
          );
          console.log("user", user)
          const accessToken = createAccessToken({ id: user.id });
          return res.status(200).json({ accessToken: accessToken, data: user, type: "login" });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.validations.accountEmailAlreadyExists.code });
        }

        const createUser = await User.create({
          email,
          login_with: loginWith.google,
          role_id: roles.passenger,
          is_active: true,
          lang: languages.en,
          is_email_verified: true,
        });
        const accessToken = createAccessToken({ id: createUser.id });
        await User.update(
          {
            device_id: "",
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            firebase_token: ""
          },
          { where: { firebase_token: firebase_token } }
        );
        await User.update(
          {
            firebase_token,
            device_id,
            is_email_verified: true,
          },
          { where: { id: createUser.id } }
        );
        console.log("user new", createUser)
        return res.status(200).json({ accessToken: accessToken, data: createUser, type: "signup" });

      } else if (type == "facebook") {
        const { facebook_id, email, firebase_token, device_id } = await joi
          .object({
            facebook_id: joi.string().required(),
            email: joi.string().trim().allow(...[null, '']),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
        const user = await User.findOne({
          where: { facebook_id },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
            "is_email_verified"
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (user) {
          if (user.dataValues.is_active == false) {
            return res
              .status(400)
              .json({ code: responseCodes.AU.accountNotActive.code });
          }
          // console.log("dbgfjhdgjd e,ail+++", user)
          // if (user.dataValues.is_email_verified == false) {
          //   return res
          //     .status(400)
          //     .json({ code: responseCodes.AU.emailNotActive.code });
          // }
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              email: email ? email : user.email,
              firebase_token,
              device_id,
              is_email_verified: email ? true : user.is_email_verified,
            },
            { where: { facebook_id } }
          );

          const accessToken = createAccessToken({ id: user.id });
          return res.status(200).json({ accessToken: accessToken, data: user, type: "login" });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.validations.accountEmailAlreadyExists.code });
        }
        let id;
        let type;
        let data;
        if (email) {
          const emailUser = await User.findOne({
            where: { email },
            include: [
              {
                association: "assignedRole"
              },
            ],
          });

          if (emailUser) {

            // console.log(emailUser?.dataValues, "hhhhhh")
            const role = emailUser?.dataValues;

            if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
              var createUser = await User.create({
                facebook_id,
                login_with: loginWith.facebook,
                role_id: roles.passenger,
                is_active: true,
                lang: languages.en,
              });
              id = createUser.id;
              data = createUser;
              type = "signup";
            } else {
              if (role.is_active == false) {
                return res
                  .status(400)
                  .json({ code: responseCodes.AU.accountNotActive.code });
              }
              // console.log("dbgfjhdgjd e,ail+++", user)
              if (role.is_email_verified == false) {
                return res
                  .status(400)
                  .json({ code: responseCodes.AU.emailNotActive.code });
              }
              await User.update(
                {
                  facebook_id
                },
                { where: { email } }
              );
              id = emailUser.id;
              data = emailUser;
              type = "login";
            }
          } else {
            var createUser = await User.create({
              facebook_id,
              email,
              login_with: loginWith.facebook,
              role_id: roles.passenger,
              is_active: true,
              lang: languages.en,
            });
            id = createUser.id;
            data = createUser;
            type = "signup";
          }
        } else {
          var createUser = await User.create({
            facebook_id,
            login_with: loginWith.facebook,
            role_id: roles.passenger,
            is_active: true,
            lang: languages.en,
          });
          id = createUser.id;
          data = createUser;
          type = "signup";
        }

        const accessToken = createAccessToken({ id: id });

        await User.update(
          {
            device_id: "",
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            firebase_token: ""
          },
          { where: { firebase_token: firebase_token } }
        );
        await User.update(
          {
            firebase_token,
            device_id,
            is_email_verified: true,
          },
          { where: { id } }
        );

        return res.status(200).json({ accessToken: accessToken, data, type });

      } else if (type == "apple") {
        const { apple_id, email, firebase_token, device_id } = await joi
          .object({
            apple_id: joi.string().required(),
            email: joi.string().trim().allow(...[null, '']),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const user = await User.findOne({
          where: { apple_id },
          attributes: [
            "id",
            "password",
            "is_active",
            "login_attempts_count",
            "role_id",
          ],
          include: [
            {
              association: "assignedRole",
            },
          ],
        });

        if (user) {
          if (user.dataValues.is_active == false) {
            return res
              .status(400)
              .json({ code: responseCodes.AU.accountNotActive.code });
          }
          // console.log("dbgfjhdgjd e,ail+++", user)
          // if (user.dataValues.is_email_verified == false) {
          //   return res
          //     .status(400)
          //     .json({ code: responseCodes.AU.emailNotActive.code });
          // }
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              email: email ? email : user.email,
              firebase_token,
              device_id,
              is_email_verified: email ? true : user.is_email_verified,
            },
            { where: { id: user.id } }
          );
          const accessToken = createAccessToken({ id: user.id });
          return res.status(200).json({ accessToken: accessToken, data: user, type: "login" });

        }

        let id;
        let data;
        let type;
        if (email) {
          console.log("email", email)
          const emailUser = await User.findOne({
            where: { email },
            include: [
              {
                association: "assignedRole"
              },
            ],
          });

          if (emailUser) {
            const role = emailUser?.dataValues;

            if (!(role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver")) {
              var createUser = await User.create({
                apple_id,
                login_with: loginWith.apple,
                role_id: roles.passenger,
                is_active: true,
                lang: languages.en,
              });
              id = createUser.id;
              data = createUser;
              type = "signup";
            } else {
              if (role.is_active == false) {
                return res
                  .status(400)
                  .json({ code: responseCodes.AU.accountNotActive.code });
              }
              // console.log("dbgfjhdgjd e,ail+++", user)
              if (role.is_email_verified == false) {
                return res
                  .status(400)
                  .json({ code: responseCodes.AU.emailNotActive.code });
              }
              await User.update(
                {
                  apple_id,
                },
                { where: { email } }
              );
              id = emailUser.id;
              data = emailUser;
              type = "login";
            }
          } else {
            var createUser = await User.create({
              apple_id,
              email,
              login_with: loginWith.apple,
              role_id: roles.passenger,
              is_active: true,
              lang: languages.en,
            });
            id = createUser.id;
            data = createUser;
            type = "signup";
          }
        } else {
          var createUser = await User.create({
            apple_id,
            email,
            login_with: loginWith.apple,
            role_id: roles.passenger,
            is_active: true,
            lang: languages.en,
          });
          id = createUser.id;
          data = createUser;
          type = "signup";
        }

        const accessToken = createAccessToken({ id: id });

        await User.update(
          {
            device_id: "",
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            firebase_token: ""
          },
          { where: { firebase_token: firebase_token } }
        );
        await User.update(
          {
            firebase_token,
            device_id,
            is_email_verified: true,
          },
          { where: { id } }
        );

        return res.status(200).json({ accessToken: accessToken, data, type });

      } else {
        const { contact, otp, id, firebase_token, device_id, rememberme } = await joi
          .object({
            contact: joi.string().required(),
            otp: joi.string().required(),
            id: joi.string().uuid(),
            firebase_token: joi.string().trim().allow(...[null, '']),
            device_id: joi.string().trim().allow(...[null, '']),
            rememberme: joi.boolean().required(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });

        const otpget = await VerificationCode.findOne({
          where: {
            id,
          },
        });
        if (!otpget) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpNotFound.code });
        }

        const userfind = await User.findOne({
          where: {
            contact
          },
        });
        if (userfind) {
          if (userfind?.dataValues.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
            return res.status(400).json({
              code: responseCodes.AU.accountBlocked.code,
            });
          }
        }

        if (otpget.otp != otp) {

          await User.update(
            { login_attempts_count: userfind?.dataValues.login_attempts_count + 1 },
            { where: { contact } }
          );
          return res
            .status(400)
            .json({ code: responseCodes.AU.invalidOtp.code });
        }

        if (new Date() >= new Date(otpget.valid_till)) {
          return res
            .status(400)
            .json({ code: responseCodes.AU.otpExpired.code });
        }


        if (userfind) {
          if (userfind.dataValues.is_active == false) {
            return res
              .status(400)
              .json({ code: responseCodes.AU.accountNotActive.code });
          }
          await User.update(
            {
              device_id: "",
            },
            { where: { device_id: device_id } }
          );
          await User.update(
            {
              firebase_token: ""
            },
            { where: { firebase_token: firebase_token } }
          );
          await User.update(
            {
              firebase_token,
              device_id,
              is_contact_verified: true
            },
            { where: { contact } }
          );
          const accessToken = createAccessToken({ id: userfind.dataValues.id, rememberme });
          const deletedOtp = await otpget.destroy();
          return res.status(200).json({ accessToken: accessToken, data: userfind, type: "login" });
          // return res
          //   .status(400)
          //   .json({ code: responseCodes.AU.validations.accountContactAlreadyExists.code });
        }
        console.log("languages.en", languages.en)
        const user = await User.create({
          contact: contact,
          login_with: loginWith.default,
          role_id: roles.passenger,
          is_active: true,
          lang: languages.en,
          is_contact_verified: true
        });
        const accessToken = createAccessToken({ id: user.id, rememberme });
        const deletedOtp = await otpget.destroy();
        await User.update(
          {
            device_id: "",
          },
          { where: { device_id: device_id } }
        );
        await User.update(
          {
            firebase_token: ""
          },
          { where: { firebase_token: firebase_token } }
        );
        await User.update(
          {
            firebase_token,
            device_id
          },
          { where: { id: user.id } }
        );

        return res.status(200).json({ accessToken: accessToken, data: user, type: "signup" });
      }
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  signupwithemail: async (req, res) => {
    try {
      const { email, password } = await joi
        .object({
          email: joi.string().email().required(),
          password: joi.string().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });

      const doesEmailAlreadyExist = await User.count({
        where: { email },
      });

      if (doesEmailAlreadyExist) {
        console.log(`Account already exists with email ${email}`);
        return res.status(400).json({
          code: responseCodes.AU.validations.accountEmailAlreadyExists.code,
        });
      }

      const user = await User.create({
        email,
        password: hash(password),
      });

      // publishMessage(snsTopics.newUser, { ...user.dataValues });

      const accessToken = createAccessToken({ id: user.id });

      return res.status(201).json({ accessToken });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  adminlogin: async (req, res) => {
    try {
      const { email, password, rememberme } = await joi
        .object({
          email: joi.string().email().required(),
          password: joi.string().required(),
          rememberme: joi.boolean().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });

      const user = await User.findOne({
        where: { email },
        attributes: [
          "id",
          "password",
          "is_active",
          "login_attempts_count",
          "role_id",
          "is_email_verified"
        ],
        include: [
          {
            association: "assignedRole",
            include: [
              {
                association: "permissions",
                include: [
                  {
                    association: "permission",
                  },
                ],
              },
            ],
          },
        ],
      });
      // console.log("user", user)
      if (!user) {
        return res
          .status(400)
          .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
      }

      if (user.dataValues.is_active == false) {
        return res
          .status(400)
          .json({ code: responseCodes.AU.accountNotActive.code });
      }
      if (user.dataValues.is_email_verified == false) {
        return res
          .status(400)
          .json({ code: responseCodes.AU.emailNotActive.code });
      }

      const role = user?.dataValues;
      if (!role.role_id) {
        return res
          .status(400)
          .json({ error: responseCodes.AU.unathourizedAccess });
      }
      if (role.assignedRole.dataValues.name === "passenger" || role.assignedRole.dataValues.name === "driver" || role.assignedRole.dataValues.name === "passenger_with_driver") {
        return res
          .status(400)
          .json({ error: responseCodes.AU.unathourizedAccess });
      }

      const permission = role.assignedRole.dataValues.permissions.map(
        (item) => item.dataValues.permission.name
      );

      const userJson = user.toJSON();
      if (userJson?.login_attempts_count === LOGIN_ATTEMPTS_MAX_COUNT) {
        console.log(`max attempts reached`);
        return res.status(400).json({
          code: responseCodes.AU.accountBlocked.code,
          login_attempts_count: userJson?.login_attempts_count,
        });
      }
      if (!compareHash(password, userJson?.password)) {
        console.log(`wrong password`);
        await user.increment("login_attempts_count");
        return res.status(400).json({
          code: responseCodes.AU.invalidEmailOrPassword.code,
          login_attempts_count: userJson?.login_attempts_count + 1,
        });
      }

      if (!compareHash(password, user?.password)) {
        console.log(`wrong password`);
        return res
          .status(400)
          .json({ code: responseCodes.AU.invalidEmailOrPassword.code });
      }

      const accessToken = createAccessToken({ id: user.id }, rememberme);
      await User.update(
        { login_attempts_count: 0 },
        { where: { id: userJson.id } }
      );

      return res.status(200).json({ accessToken, permission });

    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  addAccount: async (req, res) => {
    try {
      const { type } = await joi
        .object({
          type: joi.string().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      let value
      if (type == "MU") {
        value = await joi
          .object({
            email: joi.string().email().required(),
            password: joi.string().required(),
            contact: joi.string().optional(),
            role_id: joi.string().uuid().required(),
            country_code: joi.string().optional(),
            iso: joi.string().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
      } else {
        value = await joi
          .object({
            email: joi.string().email(),
            password: joi.string(),
            contact: joi.string().required(),
            role_id: joi.string().uuid().required(),
            country_code: joi.string().optional(),
            iso: joi.string().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
      }
      if (type == "MU") {
        var authobj = {
          email: value.email,
          password: value.password ? hash(value.password) : "",
          contact: value.contact,
          role_id: value.role_id,
          country_code: value.country_code,
          iso: value.iso,
          is_active: false,
        }

      } else {
        if (value.email != "") {
          var authobj = {
            email: value.email,
            password: value.password ? hash(value.password) : "",
            contact: value.contact,
            role_id: value.role_id,
            country_code: value.country_code,
            iso: value.iso,
            is_active: true,
            is_email_verified: true,
          }
        } else {
          var authobj = {
            email: value.email,
            password: value.password ? hash(value.password) : "",
            contact: value.contact,
            role_id: value.role_id,
            country_code: value.country_code,
            iso: value.iso,
            is_active: false,
          }
        }

      }
      const { email, password, contact, role_id } = value;
      console.log(value, "jsdhfjsdhfjksd")
      if (email) {
        const doesEmailAlreadyExist = await User.count({
          where: { email },
        });

        if (doesEmailAlreadyExist) {
          console.log(`Account already exists with email ${email}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountEmailAlreadyExists.code,
          });
        }
      }
      // const doesContactAlreadyExist = await User.count({
      //   where: { contact },
      // });

      // if (doesContactAlreadyExist) {
      //   console.log(`Account already exists with contact ${contact}`);
      //   return res.status(400).json({
      //     code: responseCodes.AU.validations.accountContactAlreadyExists.code,
      //   });
      // }

      const role = await Role.count({
        where: { id: role_id },
        attributes: ["id"],
      });

      if (!role)
        return res.status(400).json({ code: responseCodes.MR.notFound.code });
      let passwordHash = "";
      password ? passwordHash = hash(password) : passwordHash = "";

      const user = await User.create(authobj);

      if (email) {
        const accessToken = createEmailToken({ id: user.id });
        // if(role.dataValues.type === "Admin")
        // {
        //   await sendMail({
        //     to: email,
        //     subject: `Email Verification`,
        //     template: `accountVerificationTemplateAdmin`,
        //     data: { token: accessToken, language: languages.english, email: email }
        //   });
        // }
        // else{
        await sendMail({
          to: email,
          subject: `Email Verification`,
          template: `accountVerificationTemplate`,
          data: { token: accessToken, language: languages.english, email: email }
        });
      }
      // }

      // publishMessage(snsTopics.newUser, { id: user.dataValues });

      return res.status(201).json({ id: user.id });

    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateAccount: async (req, res) => {
    try {
      const { id } = req.params;

      let type = req.body.type;
      let value;
      // value = await joi
      //     .object({
      //       email: joi.string().email().optional(),
      //       contact: joi.string().allow("").optional(),
      //       role_id: joi.string().uuid(),
      //       password: joi.string().trim().min(8).optional(),
      //       type: joi.string().optional(),
      //     })
      //     .validateAsync(req.body)
      //     .catch((err) => {
      //       console.error("err:", err);
      //       return res
      //         .status(400)
      //         .json({ code: responseCodes.AU.validations.invalidBody.code });
      //     });
      if (type == "MU") {
        value = await joi
          .object({
            email: joi.string().email().optional(),
            contact: joi.string().allow("").optional(),
            role_id: joi.string().uuid(),
            password: joi.string().trim().min(8),
            country_code: joi.string().required(),
            iso: joi.string().required(),
            type: joi.string().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
      } else {
        value = await joi
          .object({
            email: joi.string().email().optional(),
            contact: joi.string().allow("").optional(),
            role_id: joi.string().uuid(),
            password: joi.string().trim().min(8),
            type: joi.string().optional(),
          })
          .validateAsync(req.body)
          .catch((err) => {
            console.error("err:", err);
            return res
              .status(400)
              .json({ code: responseCodes.AU.validations.invalidBody.code });
          });
      }



      // const body = await joi
      //   .object({
      //     email: joi.string().email().optional(),
      //     contact: joi.string().allow("").optional(),
      //     role_id: joi.string().uuid(),
      //     password: joi.string().trim().min(8),
      //   })
      //   .validateAsync(req.body)
      //   .catch((err) => {
      //     console.error("err:", err);
      //     return res
      //       .status(400)
      //       .json({ code: responseCodes.AU.validations.invalidBody.code });
      //   });

      if (!Object.keys(value).length) {
        //INFO: If there is nothing to update send success response.
        return res.json({ code: responseCodes.MU.updated.code });
      }

      const user = await User.findOne({ where: { id }, attributes: ["id"] });
      if (!user)
        return res.status(404).json({ code: responseCodes.MU.notFound.code });

      const { email, contact, role_id, password } = value;

      //TODO: convert below code blocks to fns.

      if (value.hasOwnProperty("email")) {
        const doesEmailAlreadyExist = await User.count({
          where: { id: { [Op.ne]: id }, email },
        });

        if (doesEmailAlreadyExist) {
          console.log(`Account already exists with email ${email}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountEmailAlreadyExists.code,
          });
        }
      }

      if (value.hasOwnProperty("contact")) {
        const doesContactAlreadyExist = await User.count({
          where: { id: { [Op.ne]: id }, contact },
        });

        if (doesContactAlreadyExist) {
          console.log(`Account already exists with contact ${contact}`);
          return res.status(400).json({
            code: responseCodes.AU.validations.accountContactAlreadyExists.code,
          });
        }
      }

      if (value.hasOwnProperty("role_id")) {
        const role = await Role.count({
          where: { id: role_id },
          attributes: ["id"],
        });

        if (!role) {
          console.log(`Role with id ${role_id} doesn't exist!`);
          return res.status(400).json({ code: responseCodes.MR.notFound.code });
        }
      }

      if (type == "MU") {
        var authobj = {
          email: value.email,
          password: value.password ? hash(value.password) : user.password,
          contact: value.contact,
          role_id: value.role_id,
          country_code: value.country_code,
          iso: value.iso,
        }

      } else {
        var authobj = {
          email: value.email,
          password: value.password ? hash(value.password) : user.password,
          contact: value.contact,
          role_id: value.role_id,
        }

      }

      // var authobj = {
      //   email: value.email,
      //   password: password ? hash(value.password): user.password,
      //   contact: value.contact,
      //   role_id: value.role_id,
      // }

      await user.update(authobj);

      return res.json({ code: responseCodes.MU.updated.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAccountsList: async (req, res) => {
    try {
      const query = await joi
        .object({
          search: joi.string(),
          type: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi
            .string()
            .valid(...Object.keys(User.rawAttributes), "assignedRole.name")
            .default("created_at"),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
          accounts: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
          role_id: joi.string().uuid(),
          is_active: joi.boolean(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      const {
        search,
        type,
        limit,
        page,
        sortBy = "created_at",
        orderBy = "ASC",
        accounts,
        role_id,
        is_active,
      } = query;


      if (type == "driver") {
        // comsole.log("driver",accounts.split(","))
        var where = {
          ...(typeof is_active === "boolean" && { is_active }),
          // ...({ role_id: roles.driver }),
          ...(accounts && { id: { [Op.or]: accounts.split(",") } }),
          ...(search && {
            [Op.or]: [
              { "email": { [Op.like]: `%${search}%` } },
              { "contact": { [Op.like]: `%${search}%` } },
              // { "$assignedRole.name$": { [Op.like]: `%${search}%` } },
            ],
          }),
        };
        // where.role_id = roles.driver;
      } else {
        var where = {
          ...(typeof is_active === "boolean" && { is_active }),
          ...(role_id && { role_id }),
          ...(accounts && { id: { [Op.or]: accounts.split(",") } }),
          ...(search && {
            [Op.or]: [
              { "email": { [Op.like]: `%${search}%` } },
              { "contact": { [Op.like]: `%${search}%` } },
              { '$assignedRole.name$': { [Op.like]: `%${search}%` } },
              // { "$assignedRole.name$": { [Op.like]: `%${search}%` } },
            ],
          }),
        };
      }
      const [data, count] = await Promise.all([
        User.findAll({
          include: [
            {
              model: Role,
              as: "assignedRole",
              attributes: ["id", "name"],
            },
          ],
          where,
          attributes: [
            "id",
            "email",
            "contact",
            "is_active",
            "role_id",
            "country_code",
            "iso",
            "is_email_verified",
            "is_contact_verified",
            "firebase_token",
            "push_notification",
            "device_id",
            [literal("login_attempts_count >= 3"), "is_blocked"],
          ],
          order: [
            sortBy === "assignedRole.name"
              ? ["assignedRole", "name", orderBy]
              : [sortBy, orderBy],
          ],
          ...(type != "driver" && limit && page && { limit: parseInt(limit) }),
          ...(type != "driver" && limit &&
            page && { offset: (parseInt(page) - 1) * parseInt(limit) }),
        }),
        User.count({
          where,
          include: [
            {
              model: Role,
              as: "assignedRole",
              attributes: ["id", "name"],
            },
          ],
        }),
      ]);

      return res.status(200).json({ data, count });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAccount: async (req, res) => {
    try {
      const { id } = req.params;

      const account = await User.findOne({
        where: { id },
        include: [
          {
            association: "assignedRole",
            attributes: ["id", "name"],
          },
        ],
        // attributes: ["id", "email", "contact"],
      });

      if (!account)
        return res.status(400).json({ code: responseCodes.MU.notFound.code });

      return res.json(account);
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteAccount: async (req, res) => {
    try {
      const id = req.params.id;
      const findUser = await User.findOne({ where: { id } });

      if (!findUser) {
        return res.status(400).json({ code: responseCodes.MU.notFound.code });
      }
      const deletedUser = await User.destroy({ where: { id } });
      return res.status(200).json({ code: responseCodes.MU.deleted.code });
    } catch (err) {
      console.error(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  forgotPassword: async (req, res) => {
    try {
      const language = req.headers["app-lang"] || "EN";
      const { error, value } = joi
        .object({
          email: joi.string().email().required(),
        })
        .validate(req.body);
      if (error) {
        console.error("err:", error);
        return res
          .status(400)
          .json({ code: responseCodes.AU.validations.invalidBody.code });
      }
      const user = await User.findOne({
        attributes: ["id", "forgot_attempts"],
        where: { email: value.email },
      });
      if (!user) {
        return res.status(404).json({ code: responseCodes.MU.notFound.code });
      }
      const userJson = user.toJSON();
      if (userJson?.forgot_attempts >= FORGET_PASSWORD_RESEND_EMAIL_COUNT) {
        return res.status(400).json({
          code: responseCodes.AU.forgotAttemptComplete.code,
          forget_attempts: userJson?.forget_attempts,
        });
      }
      const token = createEmailToken({ id: user.id });
      await user.increment("forgot_attempts");
      await sendMail({
        to: value.email,
        subject: "Forgot Password",
        template: `forgotPasswordTemplate`,
        data: { email: value.email, token, language: language },
      });
      return res.json({ code: responseCodes.AU.forgotPasswordEmailSent.code });
    } catch (err) {
      console.log("error", err);
      return res
        .status(500)
        .send({ code: responseCodes.SE.internalError.code });
    }
  },
  webSiteforgotPassword: async (req, res) => {
    try {
      const language = req.headers["app-lang"] || "EN";
      const { error, value } = joi
        .object({
          email: joi.string().email().required(),
        })
        .validate(req.body);
      if (error) {
        console.error("err:", error);
        return res
          .status(400)
          .json({ code: responseCodes.AU.validations.invalidBody.code });
      }
      const user = await User.findOne({
        attributes: ["id", "forgot_attempts"],
        where: { email: value.email },
      });
      if (!user) {
        return res.status(404).json({ code: responseCodes.MU.notFound.code });
      }
      const userJson = user.toJSON();
      if (userJson?.forgot_attempts >= FORGET_PASSWORD_RESEND_EMAIL_COUNT) {
        console.log(`max attempts reached`);
        return res.status(400).json({
          code: responseCodes.AU.forgotAttemptComplete.code,
          forget_attempts: userJson?.forget_attempts,
        });
      }

      const token = createEmailToken({ id: user.id });
      await user.increment("forgot_attempts");
      console.log("api testing5");
      console.log("token:", token);
      await sendMail({
        to: value.email,
        subject: "Forgot Password",
        template: `websiteforgotPasswordTemplate`,
        data: { email: value.email, token, language: language },
      });
      return res.json({ code: responseCodes.AU.forgotPasswordEmailSent.code });
    } catch (err) {
      console.log("error", err);
      return res
        .status(500)
        .send({ code: responseCodes.SE.internalError.code });
    }
  },
  resetPassword: async (req, res) => {
    try {
      const language = req.headers["app-lang"] || "EN";
      const { error, value } = joi
        .object({
          password: joi.string().required(),
          token: joi.string().required(),
          email: joi.string().required(),
          // comparePassword: joi.string().required().valid(joi.ref("password")),
        })
        .validate(req.body);
      console.log(value, "value");
      if (error) {
        console.log(`error`, error);
        return res
          .status(400)
          .json({ code: responseCodes.AU.validations.invalidBody.code });
      }

      let token = req.body.token;
      let email = req.body.email;
      let emailUser = await validateAndDecodeEmailToken(token)
      let user = await User.findOne({ where: { email } });
      if (!user)
        return res.status(400).json({ code: responseCodes.UR.notFound.code });

      // const user = await User.findOne({
      //   where: {
      //     id: req.user.email,
      //   },
      //   attributes: ["id", "email"],
      // });
      // console.log(user, "user");
      // if (!user) {
      //   return res.status(404).json({ code: responseCodes.MU.notFound.code });
      // }

      await User.update(
        { password: hash(value.password) },
        {
          where: {
            id: user.id,
          },
        }
      );

      return res.json({ code: responseCodes.AU.resetPasswordSuccess.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  // activateAccount: async (req, res) => {
  //   try {
  //     const { error, value } = joi
  //       .object({
  //         password: joi.string().required(),
  //       })
  //       .validate(req.body);

  //     if (error) {
  //       console.error("err:", err);
  //       return res
  //         .status(400)
  //         .json({ code: responseCodes.AU.validations.invalidBody.code });
  //     }

  //     const managementUser = await ManagementUser.findOne({
  //       where: {
  //         id: req.user.id,
  //       },
  //       attributes: ["id", "user_id", "status"],
  //     });

  //     if (!managementUser) {
  //       return res.status(404).send({ code: responseCodes.MU.notFound.code });
  //     }

  //     if (managementUser.status === userStatus.activated) {
  //       return res.json({
  //         code: responseCodes.AU.accountAlreadyActivated.code,
  //       });
  //     }

  //     await User.update(
  //       { password: hash(value.password) },
  //       { where: { id: managementUser.user_id } }
  //     );

  //     await ManagementUser.update(
  //       { status: userStatus.activated },
  //       { where: { id: managementUser.id } }
  //     );

  //     ManagementUserStatusHistory.create({
  //       management_user_id: managementUser.id,
  //       status: userStatus.activated,
  //       changed_by: req.user.id,
  //     });

  //     return res.json({ code: responseCodes.AU.accountActivatedSuccess.code });
  //   } catch (err) {
  //     console.error(err);
  //     return res
  //       .status(500)
  //       .json({ code: responseCodes.SE.internalError.code });
  //   }
  // },
  contactSupport: async (req, res) => {
    try {
      const language = req.headers["app-lang"] || "EN";
      const { error, value } = joi
        .object({
          email: joi.string().email().required(),
          message: joi.string().required(),
        })
        .validate(req.body);

      if (error) {
        console.log(`error`, error);
        return res
          .status(400)
          .json({ code: responseCodes.AU.validations.invalidBody.code });
      }
      await sendMail({
        to: req.body.email,
        subject: "Contact Support",
        template: `contactSupportUserTemplate`,
        data: { language: language },
      });
      await sendMail({
        to: process.env.CONTACT_SUPPORT_EMAIL,
        subject: "Contact Support",
        template: `contactSupportTeamTemplate`,
        data: {
          email: req.body.email,
          message: req.body.message,
          language: language,
        },
      });
      return res
        .status(200)
        .json({ code: responseCodes.AU.contactSupportSuccess.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleActiveStatus: async (req, res) => {
    try {
      await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });
      let userId = req.params.id;
      const passengerBookingList = await getPassengerBookingList(userId);
      if (passengerBookingList.length > 0) {
        return res.status(403).json({ message: "Change status is not performed " });
      }
      const user = await User.findOne({
        where: {
          id: userId,
        },
        attributes: ["is_active"],
      });
      if (!user) {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
      if (user.dataValues.is_active == true) {
        await User.update(
          { is_active: false },
          {
            where: { id: req.params.id },
          }
        );
      } else {
        await User.update(
          { is_active: true },
          {
            where: { id: req.params.id },
          }
        );
      }
      return res.status(200).json({ code: responseCodes.UR.created.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  emailVerify: async (req, res) => {
    try {
      await joi
        .object({
          token: joi.string().required(),
          email: joi.string().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });
      let token = req.body.token;
      let email = req.body.email;
      let emailUser = await validateAndDecodeEmailToken(token)
      let userData = await User.findOne({ where: { email } });
      if (!userData)
        return res.status(400).json({ code: responseCodes.UR.notFound.code });
      // const user = await User.findOne({
      //   where: {
      //     email,
      //   },
      //   attributes: ["is_active", "created_at"],
      // });
      // if (!user) {
      //   return res.status(400).json({ code: responseCodes.UR.notFound.code });

      // }

      // const createdDate = new Date(user.created_at);
      // const currentDate = new Date();
      // const timeDifference = currentDate.getTime() - createdDate.getTime();
      // const hoursDifference = timeDifference / (1000 * 60 * 60);

      // // Perform the 48-hour validation
      // if (hoursDifference >= 48) {
      //   return res.status(200).json({ code: responseCodes.AU.tokenExpired.code });
      // }
      await User.update(
        { is_email_verified: true, is_active: true },
        {
          where: { email },
        }
      );

      // res.redirect(`${CMS_URL}`);
      return res.status(200).json({ code: responseCodes.UR.userActivated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(400)
        .json({ code: responseCodes.AU.invalidToken.code });
      // return res
      //   .status(500)
      //   .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleBlockedStatus: async (req, res) => {
    try {
      await joi
        .object({
          id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidBody.code });
        });
      let userId = req.params.id;
      const user = await User.findOne({
        where: {
          id: userId,
        },
        attributes: ["login_attempts_count"],
      });
      if (user.dataValues.login_attempts_count === 3) {
        await User.update(
          { login_attempts_count: 0 },
          { where: { id: userId } }
        );
        return res
          .status(200)
          .json({ code: responseCodes.AU.accountBlockedSuccessfully.code });
      }
      await User.update({ login_attempts_count: 3 }, { where: { id: userId } });
      return res
        .status(200)
        .json({ code: responseCodes.AU.accountBlockedSuccessfully.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  activeUserStatus: async (req, res) => {
    try {
      let userId = req.user.id;
      const user = await User.findOne({
        where: {
          id: userId,
        },
        attributes: ["is_active"],
      });
      if (!user) {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
      if (user.dataValues.is_active === true) {
        return res.status(200).json({ code: responseCodes.UR.userAlreadyActivated.code });
      }
      await await User.update(
        { is_active: true },
        { where: { id: userId, } }
      );
      return res.status(200).json({ code: responseCodes.UR.userActivated.code });
    } catch (err) {
      console.error(JSON.stringify(err));
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  dashboardUserCount: async (req, res) => {
    try {
      const values = Object.values(roles);
      const [totalUserCount, passengerUserCount, driverUserCount, passengerWithDriverUserCount] = await Promise.all([
        await User.count({
          where: { role_id: { [Op.in]: values }, is_active: 1 }
        }),
        await User.count({
          where:
            { role_id: roles.passenger, is_active: 1 }
        }),
        await User.count({
          where:
            { role_id: roles.driver, is_active: 1 }
        }),
        await User.count({
          where:
            { role_id: roles.passengerWithDriver, is_active: 1 }
        })
      ])
      return res.json({ data: { totalUserCount, passengerUserCount, driverUserCount, passengerWithDriverUserCount } });
    } catch (err) {
      console.log(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  roleUpdate: async (req, res) => {
    try {
      const { user_id, status } = await joi
        .object({
          user_id: joi.string().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      const user = await User.findOne({
        where: {
          id: user_id,
        },
        attributes: ["is_active"],
      });
      if (!user) {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
      if (user.email == "" && user.contact == "") {
        return res
          .status(400)
          .json({ code: responseCodes.AU.profileNotUpdated.code });
      }
      if (status == 2) {
        await User.update(
          { role_id: roles.driver },
          {
            where: { id: user_id },
          }
        );
      }
      return res.status(200).json({ code: responseCodes.AU.roleUpdated.code });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  sendPushNotification: async (req, res) => {
    try {
      const { user_id, status } = await joi
        .object({
          user_id: joi.string().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      const user = await User.findOne({
        where: {
          id: user_id,
          is_active: true
        },
        attributes: ["firebase_token", "push_notification"],
      });
      if (!user) {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
      let title, text;
      if (status == 2) {
        title = "Booking accepted",
          text = "Booking accepted by driver"
      } else if (status == 4) {
        title = "Booking accepted",
          text = "Booking accepted by admin"
      } else if (status == 3) {
        title = "Booking rejected",
          text = "Booking rejected by driver"
      } else if (status == 5) {
        title = "Booking rejected",
          text = "Booking rejected by admin"
      }
      if (user?.push_notification) {
        var message = {
          "message": {
            "token": user?.firebase_token,
            "notification": {
              "title": title,
              "body": text
            },
          }
        }
        await sendmessage(message);
      }
      return res.status(200).json({ code: responseCodes.AU.notificationSent.code });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  sendPush: async (req, res) => {
    try {
      const data = await joi.object({
        reqdata: joi.array().items(
          joi.object({
            title: joi.string().required(),
            text: joi.string().required(),
            user_id: joi.string().uuid().required(),
          })
        ),
      }).validateAsync(req.body)
        .catch((err) => {
          console.log("error", err)
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });
      if (data.reqdata.length > 0) {
        for (let row of data.reqdata) {
          let user = await User.findOne({
            where: {
              id: row.user_id,
              is_active: true
            },
            attributes: ["firebase_token", "push_notification"],
          });
          // if (!user) {
          //   return res.status(200).json({ code: responseCodes.UR.notFound.code });
          // }
          user = user.dataValues;
          if (user) {
            if (user?.push_notification) {
              var message = {
                "message": {
                  "token": user?.firebase_token,
                  "notification": {
                    "title": row.title,
                    "body": row.text
                  },
                }
              }
              await sendmessage(message);
            }
          }
        }
        return res.status(200).json({ code: responseCodes.AU.notificationSent.code });
      } else {
        return res.status(200).json({ code: responseCodes.UR.notFound.code });
      }
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  responseCode: async (req, res) => {
    try {
      const responseList = [];
      for (const category in responseCodes) {
        for (const key in responseCodes[category]) {
          if (key === 'validations') {
            // Check if 'validations' key exists
            const validations = responseCodes[category][key];

            for (const validationKey in validations) {
              const code = validations[validationKey].code;
              const message = validations[validationKey].message;
              responseList.push({ code, message });
            }
          } else {
            const code = responseCodes[category][key].code;
            const message = responseCodes[category][key].message;
            responseList.push({ code, message });
          }
        }
      }

      return res.json({ data: responseList });
    } catch (err) {
      console.log(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  logout: async (req, res) => {
    try {
      const { firebase_token } = await joi
        .object({
          firebase_token: joi.string().required(),
        })
        .validateAsync(req.body)
        .catch((err) => {
          console.error("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      const userRecord = await User.findOne({
        where: {
          id: req.user.id,
          firebase_token: firebase_token,
        },
      });
      if (!userRecord) {
        return res.status(200).json({ code: responseCodes.AU.logout.code });  // If user logout from another fcm token they should also be logout with success.
      }
      await User.update(
        {
          device_id: "",
          firebase_token: ""
        },
        { where: { id: userRecord.id } }
      );
      return res.status(200).json({ code: responseCodes.AU.logout.code });
    } catch (err) {
      console.log(err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  themes: async (req, res) => {
    try {
      const themeList = await ThemeMaster.findAll({ where: { is_active: 1 } });
      if (!themeList) {
        return res.status(400).json({ code: responseCodes.AU.themenotFound.code });
      }
      return res.status(200).json(themeList);
    } catch (err) {
      console.error("err:", err);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },

};
