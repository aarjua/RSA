const console = require("../config").logs('svb:seeder');
const { ThemeMaster } = require("../models");

const themes = [
  { theme_name: 'light', account_bg_image: '', home_bg_image: '', splash: '', primary_color_code: '#F3D231', dark_hint_color: '#280C0B', light_hint_color: '#EECED3', dark_highlight_color: '#37290', dark_hover_color: '#3A3A3B', light_hover_color: '#4285F4', dark_focus_color: '#0B2512', light_focus_color: '#A8DAB5', card_color: '#151515', error_color: '#EF5350', progress_indicator_color: '#1E88E5', primary_dark_color: '#000000', primary_light_color: '#FFFFFF', disabled_color: '#BDBDBD', is_default: 1 },
  // { theme_name: 'dark' , account_bg_image: '', home_bg_image: '', splash: '', primary_color_code: '#F3D231', dark_hint_color: '#280C0B', light_hint_color:'#EECED3', dark_highlight_color: '#37290', dark_hover_color: '#3A3A3B', light_hover_color: '#4285F4', dark_focus_color: '#0B2512', light_focus_color:'#A8DAB5', card_color: '#151515', error_color:'#EF5350', progress_indicator_color: '#1E88E5', primary_dark_color:'#000000', primary_light_color:'#FFFFFF', disabled_color:'#BDBDBD', is_default : 0 },
]
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    try {

      const createdThemes = [];
      for (const { theme_name, account_bg_image, home_bg_image, splash, primary_color_code, dark_hint_color, light_hint_color, dark_highlight_color, dark_hover_color, light_hover_color, dark_focus_color, light_focus_color, card_color, error_color, progress_indicator_color, primary_dark_color, primary_light_color, disabled_color, is_default, } of themes) {
        const [func, created] = await ThemeMaster.findOrCreate({ where: { theme_name, account_bg_image, home_bg_image, splash, primary_color_code, dark_hint_color, light_hint_color, dark_highlight_color, dark_hover_color, light_hover_color, dark_focus_color, light_focus_color, card_color, error_color, progress_indicator_color, primary_dark_color, primary_light_color, disabled_color, is_default, } });
        if (created) {
          createdThemes.push(func);
        }
      }
      console.log(createdThemes, "created theme");
      console.log(`Created ${createdThemes.length} themes.`);
    } catch (error) {
      console.error("Error creating themes:", error);
    }
  },

  async down(queryInterface, Sequelize) {
    try {
      const deletedThemesCount = await ThemeMaster.destroy({ where: { theme_name: is_default } });
      console.log(`Deleted ${deletedThemesCount} themes.`);
    } catch (error) {
      console.error("Error deleting theme:", error);
    }
  }
};
