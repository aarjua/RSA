const console = require("../config").logs('svb:seeder');
const { Permission } = require("../models");
const { enums: { managementPermissions } } = require("../config");

const defaultPermissions = Object.values(managementPermissions);
console.log(defaultPermissions, "default permissions")
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    try {

      const createdPermissions = [];
      for (const name of defaultPermissions) {
        const [func, created] = await Permission.findOrCreate({ where: { name }, defaults: { name } });
        if (created) {
          createdPermissions.push(func);
        }
      }
      console.log(createdPermissions, "created permissions");
      console.log(`Created ${createdPermissions.length} permissions.`);
    } catch (error) {
      console.error("Error creating permissions:", error);
    }
  },

  async down(queryInterface, Sequelize) {
    try {
      const deletedPermissionsCount = await Permission.destroy({ where: { name: defaultPermissions } });
      console.log(`Deleted ${deletedPermissionsCount} permissions.`);
    } catch (error) {
      console.error("Error deleting permissions:", error);
    }
  }
};
