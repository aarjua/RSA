const console = require("../config").logs('svb:seeder');
const { User, AppSetting, ThemeMaster } = require('../models');
const { env: { SUPER_ADMIN_EMAIL } } = require("../config");
const email = SUPER_ADMIN_EMAIL;

module.exports = {
  up: async (queryInterface, Sequelize) => {

    // Check if the admin user already exists
    const admin = await User.findOne({
      where: {
        email,
        role_id: "d61837e9-6db5-4137-9ddb-f43561a7ddea"
      }
    });

    if (admin) {
      console.log('Admin user already exists. Skipping seeding.');
      return;
    }
    let created = await User.create({
      email,
      password: `$2a$10$u4x.UV6FwXvh8Vv6PrVtLuyAwPkbvnIdv4m6bHTM7pCo3SLGdvfDO`, //Test@123
      // password: `$2a$10$u4x.$10$2mPUpavpn2l18tVz1ppJmeD2YrctqypkL5kQ2xmnZagXKskEu6Hs6`, //Test@123
      role_id: "d61837e9-6db5-4137-9ddb-f43561a7ddea",
    });
    
    let theme = await ThemeMaster.findOne({
      where: {
        is_default: 1,
        is_active: 1
      }
    });
    if (created) {
      const client_config = await AppSetting.findOne({
        where: {
          user_id: created.id
        }
      });
      if (client_config) {
        await AppSetting.update(
          { business_theme_colour: theme ? theme.dataValues.id : "" },
          { where: { user_id: created.id } });
      } else {
        await AppSetting.create({
          user_id: created.id,
          business_theme_colour: theme ? theme.dataValues.id : ""
        });
      }

    }
    console.log('Admin user seeded successfully.');
  },

  down: async (queryInterface, Sequelize) => {
    // Remove the admin user
    await User.destroy({
      where: {
        email,
        role_id: "d61837e9-6db5-4137-9ddb-f43561a7ddea",
      }
    });

    console.log('Admin user unseeded successfully.');
  }
};