const console = require("../config").logs('svb:seeder');
const { Role } = require("../models");

const defaultRoles = [
  { name: 'admin' , position : 1 },
  { name: 'passenger', position : 2 },
  { name: 'driver',position : 3 },
  { name: 'passenger_with_driver',position : 4 }
]
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    try {

      const createdRoles = [];
      for (const { name, position } of defaultRoles) {
        const [func, created] = await Role.findOrCreate({ where: { name, position } });
        if (created) {
          createdRoles.push(func);
        }
      }
      console.log(createdRoles, "created roles");
      console.log(`Created ${createdRoles.length} roles.`);
    } catch (error) {
      console.error("Error creating roles:", error);
    }
  },

  async down(queryInterface, Sequelize) {
    try {
      const deletedRolesCount = await Permission.destroy({ where: { name: defaultRoles } });
      console.log(`Deleted ${deletedRolesCount} roles.`);
    } catch (error) {
      console.error("Error deleting roles:", error);
    }
  }
};
