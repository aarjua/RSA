const {
  env: {
    AUTH_SERVICE_URL,
    USER_SERVICE_URL,
    GOOGLE_CLIENT_ID,
  },
  responseCodes,
} = require("../config");
const axios = require("axios");
const { s3 } = require("../services");
const {
  enums: { roles },
} = require("../config");
const {
  crypto: { decryptResponseBody, encryptRequestBody },
  helper: {
    mapAccountsToProfiles,
    mapProfilesToAccountsForDriverEmailVerifiedKey,
    mapProfilesToAccounts,
    mapAnswersinToQuestion,
    mapVehileToUserVehicle,
    mapVehileToUserVehiclefroDriver,
    mapProfilesToRoles,
    mapVehileToUserVehicleForAvailableRides,
    mapVehileToUserVehicleForBookingsList,
    mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking,
    mapProfilesToAccountsForDriverEmailVerifiedKeyForRide,
    mapRideToPaymentsForRide,
    mapBookingToPaymentsRefund,
    mapBookingToPaymentsForRide,
    mapBookingToPaymentsForAllHistory
  },
  auth: AuthService,
  user: UserService,
  setting: SettingService,
  payment: PaymentService,
} = require("../services");
const joi = require("joi");
const { OAuth2Client } = require("google-auth-library");
const {
  addBooking,
  createPassengerBooking,
  saveBookingHistory
} = require("../services/user.service");
const { passengerBookingDtos } = require("../dtos/booking.dtos");
const { getReversePriceCalculations } = require("../services/setting.service");
const { v4: uuidv4 } = require("uuid");
const { savePayment } = require("../services/payment.service");

module.exports = {
  googleSignIn: async (req, res) => {
    const client = new OAuth2Client(GOOGLE_CLIENT_ID);
    try {
      const { token } = req.body;
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: GOOGLE_CLIENT_ID,
      });

      const { email, name } = ticket.getPayload();
      const userRole = await axios.get(AUTH_SERVICE_URL + "/roles?search=user");

      const userRoleDecrypt = decryptResponseBody(
        userRole.headers.get("IV"),
        userRole.data
      );

      const authResponse = await axios.post(
        AUTH_SERVICE_URL + "/google-login",
        {
          email: email,
          role_id: userRoleDecrypt.data[0].id,
        }
      );

      const userResponseData = decryptResponseBody(
        authResponse.headers.get("IV"),
        authResponse.data
      );

      if (userResponseData.id) {
        const userResponse = await axios.post(USER_SERVICE_URL + "/profiles", {
          data: encryptRequestBody({
            user_id: userResponseData.id,
            name: name,
          }),
        });
      }

      return res.status(200).json(userResponseData);
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        success: false,
        message: error,
      });
    }
  },
  add: async (req, res) => {
    try {
      let type = req.body.type;

      let authResponse;
      authResponse = await axios.post(AUTH_SERVICE_URL + "/accounts/" + type, {
        email: req.body.email,
        password: req.body.password,
        contact: req.body.contact,
        role_id: req.body.role_id,
        country_code: req.body.country_code,
        iso: req.body.iso,
      });
      // if (type == "MU") {
      //   authResponse = await axios.post(AUTH_SERVICE_URL + "/accounts/" + type,
      //     {
      //       email: req.body.email,
      //       password: req.body.password,
      //       contact: req.body.contact,
      //       role_id: req.body.role_id,
      //       country_code: req.body.country_code,
      //       iso: req.body.iso,
      //     }
      //   );
      // } else {
      //   authResponse = await axios.post(AUTH_SERVICE_URL + "/accounts/" + type,
      //     {
      //       email: req.body.email,
      //       password: req.body.password,
      //       contact: req.body.contact,
      //       role_id: req.body.role_id,
      //       country_code: req.body.country_code,
      //       iso: req.body.iso,
      //     }
      //   );
      // }

      const authData = decryptResponseBody(
        authResponse.headers.get("IV"),
        authResponse.data
      );

      if (type == "MU") {
        if (req.file) {
          const { url } = (req.body.profile = await s3.uploadFileToS3(
            req.file
          ));
          req.body.profile = url;
          //  file = await s3.uploadFileToS3(req.file);
        }
        var userObj = {
          user_id: authData.id,
          name: req.body.name,
          dob: req.body.dob,
          city: req.body.city,
          zip_code: req.body.zip_code,
          address: req.body.address,
          profile: req.body.profile,
        };
      } else {
        var userObj = {
          user_id: authData.id,
          name: req.body.name,
          dob: req.body.dob,
          city: req.body.city,
          zip_code: req.body.zip_code,
          address: req.body.address,
        };
      }
      const userResponse = await axios.post(USER_SERVICE_URL + "/profiles", {
        data: encryptRequestBody(userObj),
      });

      const userResponseData = decryptResponseBody(
        userResponse.headers.get("IV"),
        userResponse.data
      );

      return res.status(userResponse.status).json(userResponseData);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json(
          decryptResponseBody(
            error.response.headers.get("IV"),
            error.response.data
          )
        );
    }
  },
  websiteSignup: async (req, res) => {
    try {
      const userRole = await axios.get(AUTH_SERVICE_URL + "/roles?search=user");

      const userRoleDecrypt = decryptResponseBody(
        userRole.headers.get("IV"),
        userRole.data
      );

      const authResponse = await axios.post(AUTH_SERVICE_URL + "/accounts", {
        email: req.body.email,
        password: req.body.password,
        contact: req.body.contact,
        role_id: userRoleDecrypt.data[0].id,
      });

      const authData = decryptResponseBody(
        authResponse.headers.get("IV"),
        authResponse.data
      );

      const userResponse = await axios.post(USER_SERVICE_URL + "/profiles", {
        data: encryptRequestBody({
          user_id: authData.id,
          name: req.body.name,
          city: req.body.city,
          country_id: req.body.country_id,
          gender: req.body.gender,
          profile_type: req.body.profile_type,
        }),
      });

      const userResponseData = decryptResponseBody(
        userResponse.headers.get("IV"),
        userResponse.data
      );

      const userInterest = await axios.put(
        USER_SERVICE_URL + "/profiles/" + userResponseData.id,
        {
          data: encryptRequestBody({
            userInterests: req.body.userInterests,
          }),
        }
      );

      const userResponseDataForInterest = decryptResponseBody(
        userInterest.headers.get("IV"),
        userInterest.data
      );

      return res
        .status(userResponse.status)
        .json({ code: responseCodes.UR.created.code });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(error.response.status)
        .json(
          decryptResponseBody(
            error.response.headers.get("IV"),
            error.response.data
          )
        );
    }
  },
  list: async (req, res) => {
    try {
      let accounts = [],
        profiles = [],
        data = [],
        allcount = 0,
        count = 0;

      const query = await joi
        .object({
          search: joi.string(),
          type: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string(),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
          role_id: joi.string().uuid(),
          accounts: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
          searchType: joi.string().valid("auth", "user"),
          is_active: joi.boolean(),
          role_change_status: joi.number(),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      const {
        searchType,
        type,
        is_active,
        search,
        page,
        limit,
        sortBy,
        orderBy,
        role_id,
        accounts: accountsQuery,
        profiles: profilesQuery,
        role_change_status,
      } = query;

      if (
        (!sortBy && !searchType) ||
        query.hasOwnProperty("is_active") ||
        searchType === "auth" ||
        AuthService.sortByColumns.includes(sortBy)
      ) {
        if (type == "driver") {
          try {
            const { data, count: totalAccountsCount } =
              await AuthService.getAccountsList({
                ...query,
                ...(accountsQuery && { accounts: accountsQuery }),
              });

            accounts = data;
            allcount = totalAccountsCount;
          } catch (error) {
            console.log("accounts list fetch error:", error?.response);
            return res
              .status(error.response.status)
              .json(
                decryptResponseBody(
                  error.response.headers.get("IV"),
                  error.response.data
                )
              );
          }

          if (accounts.length) {
            try {
              const { data } = await UserService.getProfilesList({
                users: accounts.map((account) => account.id).join(","),
              });
              profiles = data;
              // profiles = data.map(item => item.dataValues);
            } catch (error) {
              console.log("profiles list fetch error:", error?.response);
              return res
                .status(error.response.status)
                .json(
                  decryptResponseBody(
                    error.response.headers.get("IV"),
                    error.response.data
                  )
                );
            }
          }

          let data2 = mapAccountsToProfiles(accounts, profiles, type);

          // data = data2.map((dt) => dt.role_id == roles.driver);
          let data3 = data2.filter(
            (dt) =>
              dt.role_id === roles.driver ||
              dt?.profile?.role_change_status != 0
          );

          count = data3.length;
          const startIndex = (parseInt(page) - 1) * parseInt(limit);
          const endIndex = parseInt(page) * parseInt(limit);

          // Limit the filtered results based on the pagination
          data = data3.slice(startIndex, endIndex);
        } else {
          try {
            const { data, count: totalAccountsCount } =
              await AuthService.getAccountsList({
                ...query,
                ...(accountsQuery && { accounts: accountsQuery }),
              });

            accounts = data;
            count = totalAccountsCount;
          } catch (error) {
            console.log("accounts list fetch error:", error?.response);
            return res
              .status(error.response.status)
              .json(
                decryptResponseBody(
                  error.response.headers.get("IV"),
                  error.response.data
                )
              );
          }

          if (accounts.length) {
            try {
              const { data } = await UserService.getProfilesList({
                users: accounts.map((account) => account.id).join(","),
              });
              profiles = data;
              // profiles = data.map(item => item.dataValues);
            } catch (error) {
              console.log("profiles list fetch error:", error?.response);
              return res
                .status(error.response.status)
                .json(
                  decryptResponseBody(
                    error.response.headers.get("IV"),
                    error.response.data
                  )
                );
            }
          }

          data = mapAccountsToProfiles(accounts, profiles);

          if (role_change_status && role_change_status == 1) {
            data = data.filter((item) => {
              return item.profile.role_change_status === 1;
            });
          }
        }
      } else if (
        searchType === "user" ||
        UserService.sortByColumns.includes(sortBy)
      ) {
        try {
          const { data } = await UserService.getProfilesList({
            ...query,
            ...(profilesQuery && { profiles: profilesQuery }),
          });

          profiles = data;
        } catch (error) {
          console.log("profiles list fetch error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }

        if (profiles.length) {
          const { data, count: totalAccountsCount } =
            await AuthService.getAccountsList({
              accounts: profiles.map((profile) => profile.user_id).join(","),
            });

          accounts = data;
          count = totalAccountsCount;
        }

        data = mapProfilesToAccounts(accounts, profiles);
      }

      return res.json({ data, count });
    } catch (error) {
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  exportUsers: async (req, res) => {
    try {
      let accounts = [],
        profiles = [];
      mappedData = [];

      try {
        const { data } = await AuthService.getAllAccountsList();
        accounts = data;
      } catch (error) {
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      if (accounts.length) {
        try {
          const { data } = await UserService.getProfilesList({
            users: accounts.map((account) => account.id).join(","),
          });
          profiles = data;
        } catch (error) {
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }
      }
      mappedData = mapAccountsToProfiles(accounts, profiles);
      const completeData = mappedData.map((item) => {
        return {
          name: item?.profile?.name || "",
          email: item.email,
          role: item.assignedRole.name,
          contact_no: item.contact || "",
        };
      });
      return res.json({
        data: completeData,
      });
    } catch (error) {
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  get: async (req, res) => {
    try {
      const { id } = req.params;

      let account = {},
        profile = {};
      role = {};

      try {
        account = await AuthService.getAccountById(id);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      try {
        profile = await UserService.getProfileByIdOrUserId(account.id);
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      let mappedData;
      if (!profile) {
        [mappedData] = mapAccountsToProfiles([account], []);
      } else {
        if (profile.requested_role != null && profile.requested_role != "") {
          try {
            role = await AuthService.getRoleById(profile.requested_role);
            if (role) {
              [profile] = await mapProfilesToRoles([profile], [role.data]);
            }
          } catch (error) {
            console.log("role fetch error:", error);
            profile.requested_role_name = "";
            // return res
            //   .status(error.response.status)
            //   .json(
            //     decryptResponseBody(
            //       error.response.headers.get("IV"),
            //       error.response.data
            //     )
            //   );
          }
        } else {
          profile.requested_role_name = "";
        }
        [mappedData] = mapAccountsToProfiles([account], [profile]);
      }
      return res.json(mappedData);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  delete: async (req, res) => {
    try {
      const id = req.params.id;

      try {
        await UserService.deleteProfileByIdOrUserId(id);
      } catch (error) {
        console.log("profile delete error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      try {
        var deletedUser = await AuthService.deleteAccountById(id);
      } catch (error) {
        console.log("accounts delete error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      return res.status(deletedUser.status).json(deletedUser.data);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getSelf: async (req, res) => {
    try {
      const { id } = req.user;

      let account = {},
        profile = {};

      try {
        account = await AuthService.getAccountById(id);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        profile = await UserService.getProfileByIdOrUserId(account.id);
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }
      let mappedData;
      if (!profile) {
        [mappedData] = mapAccountsToProfiles([account], []);
      } else {
        [mappedData] = mapAccountsToProfiles([account], [profile]);
      }

      return res.json(mappedData);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  update: async (req, res) => {
    try {
      //TODO: Add a check to only call the service if a particular update key is present. Also response code should be common and not of profile.
      const { id } = req.params;
      await AuthService.updateAccountById(id, req.body).catch((error) => {
        console.log("account update error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      });
      let updatedProfile;
      if (req.body.type == "MU") {
        if (req.file) {
          const { url } = await s3.uploadFileToS3(req.file);
          req.body.profile = url;
        }
        updatedProfile = await UserService.updateProfileByIdOrUserIdWithTypeMU(
          id,
          req.body
        ).catch((error) => {
          console.log("profile update error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        });
      } else {
        updatedProfile = await UserService.updateProfileByIdOrUserId(
          id,
          req.body
        ).catch((error) => {
          console.log("profile update error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        });
      }

      return res.status(updatedProfile.status).json(updatedProfile.data);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  updateSelf: async (req, res) => {
    try {
      //TODO: Add a check to only call the service if a particular update key is present. Also response code should be common and not of profile.
      const { id } = req.user;

      delete req.body.email;
      delete req.body.role_id;

      await AuthService.updateAccountById(id, req.body).catch((error) => {
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      });

      const updatedProfile = await UserService.updateProfileByIdOrUserId(
        id,
        req.body
      ).catch((error) => {
        console.log("profile update error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      });

      return res.status(updatedProfile.status).json(updatedProfile.data);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  deleteSelf: async (req, res) => {
    try {
      const { id } = req.user;

      const deletedUser = await AuthService.deleteAccountById(id).catch(
        (error) => {
          console.log("accounts delete error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }
      );

      try {
        UserService.deleteProfileByIdOrUserId(id);
      } catch (error) {
        console.log("accounts delete error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }

      return res.status(deletedUser.status).json(deletedUser.data);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getUserDetails: async (req, res) => {
    try {
      const { id } = req.user;

      let account = {},
        profile = {};
      let course, interest;

      try {
        account = await AuthService.getAccountById(id);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        profile = await UserService.getProfileByIdOrUserId(account.id);
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }
      try {
        course = await UserService.getProfileCourseByIdOrUserId(account.id);
      } catch (error) {
        console.log("profile course fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }
      try {
        interest = await UserService.getProfileInterestByIdOrUserId(profile.id);
      } catch (error) {
        console.log("profile interest fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }

      let actions = [
        {
          id: "609748cb-851a-4004-9f1c-5a393173e4e6",
          name: "running for fund",
        },
      ];

      const [mappedData] = mapAccountsToProfiles([account], [profile]);

      mappedData.action = actions;
      mappedData.interest = interest;
      mappedData.course = course;

      return res.json(mappedData);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  // getCounts: async (req, res) => {
  //   try {
  //     const { id: user_id } = req.params;
  //     const campaignCount = await axios.get(
  //       CAMPAIGN_SERVICE_URL + "/campaigns-count/" + user_id
  //     );
  //     const userResponseData = decryptResponseBody(
  //       campaignCount.headers.get("IV"),
  //       campaignCount.data
  //     );
  //     const projectsCount = await axios.get(
  //       PROJECT_SERVICE_URL + "/projects-count/" + user_id
  //     );
  //     const projectsCountData = decryptResponseBody(
  //       projectsCount.headers.get("IV"),
  //       projectsCount.data
  //     );
  //     const articleCount = await axios.get(
  //       ARTICLE_SERVICE_URL + "/article-count/" + user_id
  //     );
  //     const articleCountData = decryptResponseBody(
  //       articleCount.headers.get("IV"),
  //       articleCount.data
  //     );

  //     return res.json({
  //       campaignCount: userResponseData.campaign_count,
  //       projectsCount: projectsCountData.project_count,
  //       articleCount: articleCountData.article_count,
  //     });
  //   } catch (error) {
  //     console.log("error:", error);
  //     return res
  //       .status(500)
  //       .json({ code: responseCodes.SE.internalError.code });
  //   }
  // },
  questionList: async (req, res) => {
    try {
      let questions = [],
        answers = [],
        data = [],
        count = 0;

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string(),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      const { search, page, limit, sortBy, orderBy } = query;

      try {
        const { data, count: totalAccountsCount } =
          await UserService.getQuestionList({
            ...query,
          });
        questions = data;
        count = totalAccountsCount;
      } catch (error) {
        console.log("accounts list fetch error:", error?.response, error);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (questions.length) {
        try {
          const transformedData = questions
            .flatMap((question) =>
              question.questionanswers.map((answer) => answer.answer_id)
            )
            .join(",");

          const { data } = await SettingService.getAnswerList(transformedData);
          answers = data;
        } catch (error) {
          console.log("profiles list fetch error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }
      }

      data = mapAnswersinToQuestion(questions, answers);
      return res.json({ data, count });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  questionDetail: async (req, res) => {
    try {
      const { id } = req.params;

      let question = {},
        answers = [];

      try {
        question = await UserService.getQuestion(id);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      try {
        let transformedData;

        transformedData = question.questionanswers
          .map((answer) => answer.answer_id)
          .join(",");
        const { data } = await SettingService.getAnswerList(transformedData);
        answers = data;
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      let mappedData;
      [mappedData] = mapAnswersinToQuestion([question], answers);

      return res.json(mappedData);
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleRCStatus: async (req, res) => {
    try {
      const { user_id, id, status } = await joi
        .object({
          user_id: joi.string().uuid().required(),
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.AU.validations.invalidBody.code,
            description: err,
          });
        });

      let userrcupdate = {},
        userupdate = {};

      try {
        userrcupdate = await UserService.updateRCStatus(id, status);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      if (userrcupdate.code == "PF419" && status == 2) {
        try {
          userupdate = await AuthService.updateUserRole(user_id, status);
        } catch (error) {
          console.log("accounts fetch error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }
      }

      return res
        .status(200)
        .json({ code: responseCodes.AU.rcStatusUpdated.code });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleProfileStatus: async (req, res) => {
    try {
      const { user_id, id, status } = await joi
        .object({
          user_id: joi.string().uuid().required(),
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.AU.validations.invalidBody.code,
            description: err,
          });
        });

      let userprofileupdate = {},
        userupdate = {};

      try {
        userprofileupdate = await UserService.updateProfileStatus(id, status);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (userprofileupdate.code == "PF427" && status == 2) {
        try {
          userupdate = await AuthService.updateUserRole(user_id, status);
        } catch (error) {
          console.log("accounts fetch error:", error?.response);
          return res
            .status(error.response.status)
            .json(
              decryptResponseBody(
                error.response.headers.get("IV"),
                error.response.data
              )
            );
        }
      }

      return res
        .status(200)
        .json({ code: responseCodes.AU.rcStatusUpdated.code });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  allResponseCode: async (req, res) => {
    try {
      let account = [],
        profile = [];

      try {
        account = await AuthService.getResponseCode();
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      try {
        profile = await UserService.getResponseCode(account.id);
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      return res.json({ auth: account, user: profile });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getUserCarDetails: async (req, res) => {
    try {
      const { profile_id } = await joi
        .object({
          profile_id: joi.string().uuid().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.AU.validations.invalidBody.code,
            description: err,
          });
        });

      let vehicle = [],
        profile = [];
      colours = [];

      try {
        profile = await UserService.getCarByIdOrUserId(
          req.headers.authorization,
          profile_id
        );
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        vehicle = await SettingService.getVehicleList(
          req.headers.authorization
        );
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }
      try {
        colours = await SettingService.getColourList(req.headers.authorization);
      } catch (error) {
        console.log("profile fetch error:", error?.response);
        // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
      }
      const mappedData = mapVehileToUserVehicle(
        profile.data,
        vehicle.data,
        colours.data
      );

      // mappedData.action = actions;
      // mappedData.interest = interest;
      // mappedData.course = course;

      return res.json({ profile: mappedData });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAllRidelist: async (req, res) => {
    try {
      let result = [],
        rides = [],
        data = [],
        count = 0;

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().valid().default("start_city_name"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          ride_status: joi.number(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      const {
        search,
        limit,
        page,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = query;

      try {
        result = await UserService.getRidesList({
          ...query,
        });
        rides = result.data;
        count = result.count;
      } catch (error) {
        console.log("accounts list fetch error:", error);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (rides.length) {

        try {
          const ridePayments = await PaymentService.getAllRidePayment();

          rides = mapRideToPaymentsForRide(ridePayments.data, rides);
        } catch (error) {
          console.log("payment fetch error:", error);
        }


        let filter_user_id_array = [];

        for (let ride of rides) {
          if (ride.driver_detail) {
            filter_user_id_array.push({
              id: ride.driver_detail?.user_id,
              type: "driver",
            });
          }
          if (ride.passenger_bookings.length) {
            for (let passenger of ride.passenger_bookings) {
              filter_user_id_array.push({
                id: passenger.passenger_detail.user_id,
                type: "ride_passenger",
              });
            }
          }
        }
        const { data, count: totalAccountsCount } =
          await AuthService.getAccountsList({
            // accounts: rides.map((ride) => ride.driver_detail.user_id).join(","),
            accounts: filter_user_id_array
              .map((filteruser) => filteruser.id)
              .join(","),
          });

        accounts = data;

        rides = mapProfilesToAccountsForDriverEmailVerifiedKeyForRide(
          accounts,
          rides,
          filter_user_id_array
        );

        try {
          vehicle = await SettingService.getVehicleList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }
        try {
          colours = await SettingService.getColourList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }

        const mappedData1 = mapVehileToUserVehiclefroDriver(
          rides,
          vehicle.data,
          colours.data
        );

        // TODO remove in sprint_4 release start
        const mappedData = mapVehileToUserVehicle(
          mappedData1,
          vehicle.data,
          colours.data
        );
        // TODO remove in sprint_4 release end

        return res.status(200).json({ data: mappedData, count });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getRideById: async (req, res) => {
    try {
      let account = {},
        ride = {},
        rideData = {},
        accounts = [];

      const { id } = req.params;
      try {
        ride = await UserService.getRideById(id);
      } catch (error) {
        console.log("accounts list fetch error:", error);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (ride.is_active) {
        let filter_user_id_array = [];

        for (let row of [ride]) {
          if (row.driver_detail) {
            filter_user_id_array.push({
              id: row.driver_detail.user_id,
              type: "driver",
            });
          }
          if (row.passenger_bookings.length) {
            for (let passenger of row.passenger_bookings) {
              filter_user_id_array.push({
                id: passenger.passenger_detail.user_id,
                type: "ride_passenger",
              });
            }
          }
        }
        const { data, count: totalAccountsCount } =
          await AuthService.getAccountsList({
            accounts: filter_user_id_array
              .map((filteruser) => filteruser.id)
              .join(","),
          });

        accounts = data;

        ride = mapProfilesToAccountsForDriverEmailVerifiedKeyForRide(
          accounts,
          [ride],
          filter_user_id_array
        );
        if (ride) {
          try {
            const ridePayments = await PaymentService.getPassengerRidePayment(
              ride[0].id
            );

            ride = mapRideToPaymentsForRide(ridePayments.data, ride);
          } catch (error) {
            console.log("payment fetch error:", error);
          }
        }
        try {
          vehicle = await SettingService.getVehicleList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }
        try {
          colours = await SettingService.getColourList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }

        const mappedData = mapVehileToUserVehicleForAvailableRides(
          ride,
          vehicle.data,
          colours.data
        );

        return res.status(200).json({ data: mappedData });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAvailbleRidelist: async (req, res) => {
    try {
      let result = [],
        rides = [],
        data = [],
        count = 0;
      accounts = [];
      vehicle = [];
      colours = [];
      accountcount = 0;

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().valid().default("start_city_name"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          ride_status: joi.number(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      // const body = await joi
      // .object({
      //   start_city_name: joi.string().required(),
      //   start_city_address: joi.string().required(),
      //   start_point_latitude: joi.string().required(),
      //   start_point_longitude: joi.string().required(),
      //   end_city_name: joi.string().required(),
      //   end_city_address: joi.string().required(),
      //   end_point_latitude: joi.string().required(),
      //   end_point_longitude: joi.string().required(),
      //   route_description: joi.string().required(),
      //   is_round_trip: joi.boolean().required(),
      //   start_time: joi.date().required(),
      //   round_start_time: joi.date().required(),
      //   seats: joi.number().required(),
      // })
      // .validateAsync(req.body)
      // .catch((err) => {
      //   console.log("err:", err);
      //   return res
      //     .status(400)
      //     .json({ code: responseCodes.AU.validations.invalidQuery.code });
      // });

      const {
        search,
        limit,
        page,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = query;

      try {
        result = await UserService.getAvailableRidesList({
          ...req.body,
          ...query,
        });
        rides = result.data;
        count = result.count;
      } catch (error) {
        console.log("accounts list fetch error:", error);
        return res
          .status(400)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (rides.length) {
        let filter_user_id_array = [];

        for (let ride of rides) {
          if (ride.driver_detail) {
            filter_user_id_array.push({
              id: ride.driver_detail?.user_id,
              type: "driver",
            });
          }
          if (ride.passenger_bookings.length) {
            for (let passenger of ride.passenger_bookings) {
              filter_user_id_array.push({
                id: passenger.passenger_detail.user_id,
                type: "ride_passenger",
              });
            }
          }
        }

        const { data, count: totalAccountsCount } =
          await AuthService.getAccountsList({
            // accounts: rides.map((ride) => ride.driver_detail.user_id).join(","),
            accounts: filter_user_id_array
              .map((filteruser) => filteruser.id)
              .join(","),
          });

        accounts = data;

        rides = mapProfilesToAccountsForDriverEmailVerifiedKeyForRide(
          accounts,
          rides,
          filter_user_id_array
        );

        // rides = mapProfilesToAccountsForDriverEmailVerifiedKey(accounts, rides);

        try {
          vehicle = await SettingService.getVehicleList();
        } catch (error) {
          // console.log("profile fetch error:", error?.response);
        }
        try {
          colours = await SettingService.getColourList();
        } catch (error) {
          // console.log("profile fetch error:", error?.response);
        }

        const mappedData = mapVehileToUserVehicleForAvailableRides(
          rides,
          vehicle.data,
          colours.data
        );

        return res.status(200).json({ data: mappedData, count });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAvailbleRidelistforTesting: async (req, res) => {
    try {
      let result = [],
        rides = [],
        data = [],
        count = 0;
      accounts = [];
      vehicle = [];
      colours = [];
      accountcount = 0;

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().valid().default("start_city_name"),
          orderBy: joi.string().valid("ASC", "DESC").default("ASC"),
          ride_status: joi.number(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      // const body = await joi
      // .object({
      //   start_city_name: joi.string().required(),
      //   start_city_address: joi.string().required(),
      //   start_point_latitude: joi.string().required(),
      //   start_point_longitude: joi.string().required(),
      //   end_city_name: joi.string().required(),
      //   end_city_address: joi.string().required(),
      //   end_point_latitude: joi.string().required(),
      //   end_point_longitude: joi.string().required(),
      //   route_description: joi.string().required(),
      //   is_round_trip: joi.boolean().required(),
      //   start_time: joi.date().required(),
      //   round_start_time: joi.date().required(),
      //   seats: joi.number().required(),
      // })
      // .validateAsync(req.body)
      // .catch((err) => {
      //   console.log("err:", err);
      //   return res
      //     .status(400)
      //     .json({ code: responseCodes.AU.validations.invalidQuery.code });
      // });

      const {
        search,
        limit,
        page,
        sortBy = "start_city_name",
        orderBy = "ASC",
        ride_status,
        type,
        is_active,
        profiles,
      } = query;

      try {
        result = await UserService.getAvailbleRidelistforTesting({
          ...req.body,
          ...query,
        });
        rides = result.data;
        count = result.count;
      } catch (error) {
        // console.log("accounts list fetch error:", error);
        return res
          .status(400)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (rides.length) {
        const { data, count: totalAccountsCount } =
          await AuthService.getAccountsList({
            accounts: rides.map((ride) => ride.driver_detail.user_id).join(","),
          });

        accounts = data;

        rides = mapProfilesToAccountsForDriverEmailVerifiedKey(accounts, rides);

        try {
          vehicle = await SettingService.getVehicleList();
        } catch (error) {
          // console.log("profile fetch error:", error?.response);
        }
        try {
          colours = await SettingService.getColourList();
        } catch (error) {
          // console.log("profile fetch error:", error?.response);
        }

        const mappedData = mapVehileToUserVehicleForAvailableRides(
          rides,
          vehicle.data,
          colours.data
        );

        return res.status(200).json({ data: mappedData, count });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAllBookingList: async (req, res) => {
    try {
      let result = [],
        bookings = [],
        data = [],
        count = 0;
      accounts = [];
      vehicle = [];
      colours = [];
      accountcount = 0;
      ridePayments = [];

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().valid().default("created_at"),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
          booking_status: joi.string(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      try {
        result = await UserService.getAllBookingList({
          ...query,
        });
       
        bookings = result.data;
        count = result.count;
      } catch (error) {
        // console.log("accounts list fetch error:", error);
        return res
          .status(400)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        ridePayments = await PaymentService.getAllRidePayment();

      } catch (error) {
        console.log("payment fetch error:", error);
      }

      let filter_user_id_array = [];
      if (query.type != 1) {
        if (bookings.length) {

          bookings = mapBookingToPaymentsForAllHistory(ridePayments.data, bookings, query.type);
          
          for (let groupbydate of bookings) {
            for (let booking of groupbydate.data) { 
              ///////////////////////// need to fix this ////////////////////////////////
              if (booking.ride_detail.driver_detail) {
                filter_user_id_array.push({
                  id: booking.ride_detail.driver_detail?.user_id,
                  type: "driver",
                });
              }
              if (booking.passenger_detail) {
                filter_user_id_array.push({
                  id: booking.passenger_detail?.user_id,
                  type: "passenger",
                });
              }
              if (booking.ride_detail.passenger_bookings.length) {
                for (let passenger of booking.ride_detail.passenger_bookings) {
                  filter_user_id_array.push({
                    id: passenger.passenger_detail.user_id,
                    type: "ride_passenger",
                  });
                }
              }
            }
          }

          const { data, count: totalAccountsCount } =
            await AuthService.getAccountsList({
              accounts: filter_user_id_array
                .map((filteruser) => filteruser.id)
                .join(","),
            });

          accounts = data;

          bookings = mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking(
            accounts,
            bookings,
            filter_user_id_array,
            query.type
          );

          try {
            vehicle = await SettingService.getVehicleList();
          } catch (error) {
            // console.log("profile fetch error:", error?.response);
          }
          try {
            colours = await SettingService.getColourList();
          } catch (error) {
            // console.log("profile fetch error:", error?.response);
          }
          let payment_where;
          if (query.booking_status && query.booking_status == "payment_success") {
            payment_where = "success";
          } else if (query.booking_status && query.booking_status == "payment_fail") {
            payment_where = "failed";
          }

          const filteredData = [];
          if (query.booking_status && (query.booking_status == "payment_success" || query.booking_status == "payment_fail")) {
            for (const entry of bookings) {
              const filteredEntry = {
                date: entry.date,
                data: []
              };
              for (const rideData of entry.data) {
                console.log(rideData.payment_detail.payment_status, "rideData.payment_detail.payment_status", payment_where)
                if (rideData.payment_detail.payment_status == payment_where) {
                  filteredEntry.data.push(rideData);
                }
              }
              if (filteredEntry.data.length > 0) {
                console.log("filteredEntry", filteredEntry)
                filteredData.push(filteredEntry);
              }
            }
            console.log("filteredData", filteredData, filteredData.length, bookings)

            const mappedData = mapVehileToUserVehicleForBookingsList(
              filteredData,
              vehicle.data,
              colours.data,
              query.type
            );
            return res.status(200).json({ data: mappedData, count: filteredData.length });
          } else {

            const mappedData = mapVehileToUserVehicleForBookingsList(
              bookings,
              vehicle.data,
              colours.data,
              query.type
            );
            return res.status(200).json({ data: mappedData, count });
          }




        } else {
          return res.status(200).json({ data: [], count: 0 });
        }
      } else {
        if (bookings.length) {
          bookings = mapBookingToPaymentsForAllHistory(ridePayments.data, bookings, query.type);
          for (let booking of bookings) {
            if (booking.ride_detail.driver_detail) {
              filter_user_id_array.push({
                id: booking.ride_detail.driver_detail?.user_id,
                type: "driver",
              });
            }
            if (booking.passenger_detail) {
              filter_user_id_array.push({
                id: booking.passenger_detail?.user_id,
                type: "passenger",
              });
            }
            if (booking.ride_detail.passenger_bookings.length) {
              for (let passenger of booking.ride_detail.passenger_bookings) {
                filter_user_id_array.push({
                  id: passenger.passenger_detail.user_id,
                  type: "ride_passenger",
                });
              }
            }
          }

          const { data, count: totalAccountsCount } =
            await AuthService.getAccountsList({
              accounts: filter_user_id_array
                .map((filteruser) => filteruser.id)
                .join(","),
            });

          accounts = data;

          bookings = mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking(
            accounts,
            bookings,
            filter_user_id_array,
            query.type
          );

          try {
            vehicle = await SettingService.getVehicleList();
          } catch (error) {
            // console.log("profile fetch error:", error?.response);
          }
          try {
            colours = await SettingService.getColourList();
          } catch (error) {
            // console.log("profile fetch error:", error?.response);
          }

          const mappedData = mapVehileToUserVehicleForBookingsList(
            bookings,
            vehicle.data,
            colours.data,
            query.type
          );

          return res.status(200).json({ data: mappedData, count });
        } else {
          return res.status(200).json({ data: [], count: 0 });
        }
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  getAllBookingByID: async (req, res) => {
    try {
      let accounts = [],
        booking = {};
      booking_data = {};
      vehicle = [];
      colours = [];
      accountcount = 0;

      const { id } = req.params;
      try {
        booking_data = await UserService.getBookingById(id);
      } catch (error) {
        console.log("accounts list fetch error:", error);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (booking_data) {

        try {
          const ridePayments = await PaymentService.getAllRidePayment();

          booking_data = mapBookingToPaymentsForRide(ridePayments.data, [booking_data]);
          booking = booking_data[0]
        } catch (error) {
          console.log("payment fetch error:", error);
        }

        let filter_user_id_array = [];
        if (booking.ride_detail.driver_detail) {
          filter_user_id_array.push({
            id: booking.ride_detail.driver_detail?.user_id,
            type: "driver",
          });
        }
        if (booking.passenger_detail) {
          filter_user_id_array.push({
            id: booking.passenger_detail?.user_id,
            type: "passenger",
          });
        }
        if (booking.ride_detail.passenger_bookings.length) {
          for (let passenger of booking.ride_detail.passenger_bookings) {
            filter_user_id_array.push({
              id: passenger.passenger_detail.user_id,
              type: "ride_passenger",
            });
          }
        }
        const { data, count: totalAccountsCount } =
          await AuthService.getAccountsList({
            accounts: filter_user_id_array
              .map((filteruser) => filteruser.id)
              .join(","),
          });

        accounts = data;

        booking = mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking(
          accounts,
          [booking],
          filter_user_id_array,
          1
        );
        try {
          vehicle = await SettingService.getVehicleList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }
        try {
          colours = await SettingService.getColourList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("profile fetch error:", error?.response);
        }
        console.log("vehicle+++", vehicle)
        const mappedData = mapVehileToUserVehicleForBookingsList(
          booking,
          vehicle.data,
          colours.data,
          1
        );

        return res.status(200).json({ data: mappedData });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  toggleBookingActiveStatus: async (req, res) => {
    try {
      const { driver_user_id, user_id, id, status } = await joi
        .object({
          driver_user_id: joi.string().uuid().required(),
          user_id: joi.string().uuid().required(),
          id: joi.string().uuid().required(),
          status: joi.number().required(),
        })
        .validateAsync(req.params)
        .catch((err) => {
          console.log("err:", err);
          return res.status(400).json({
            code: responseCodes.AU.validations.invalidBody.code,
            description: err,
          });
        });

      let bookingStatusUpdate = {},
        userupdate = {};

      try {
        bookingStatusUpdate = await UserService.updateBookingStatus(id, status);
      } catch (error) {
        console.log("accounts fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      if (bookingStatusUpdate.code == "PB411") {
        if (status == 6) {
          let pushObject = {
            title: "Booking Cancelled",
            text: "Booking cancelled by passenger.",
            user_id: driver_user_id
          }
          let bookingHistoryObject = {
            title: "Booking Cancelled",
            sub_title: "Booking cancelled by passenger.",
            booking_id: id
          }
          await module.exports.saveBookingHistory(bookingHistoryObject)
          // pushObject.user_ids = [driver_user_id]
          await module.exports.sendPush([pushObject])

        } else {
          try {
            userupdate = await AuthService.sendPushNotification(user_id, status);
            let title, text;
            if (status == 2) {
              title = "Booking accepted",
                text = "Booking accepted by driver"
            } else if (status == 4) {
              title = "Booking accepted",
                text = "Booking accepted by admin"
            } else if (status == 3) {
              title = "Booking rejected",
                text = "Booking rejected by driver"
            } else if (status == 5) {
              title = "Booking rejected",
                text = "Booking rejected by admin"
            }
            let bookingHistoryObject = {
              title: title,
              sub_title: text,
              booking_id: id
            }
            await module.exports.saveBookingHistory(bookingHistoryObject)
          } catch (error) {
            console.log("accounts fetch error:", error?.response);
            return res
              .status(error.response.status)
              .json(
                decryptResponseBody(
                  error.response.headers.get("IV"),
                  error.response.data
                )
              );
          }
        }
      }

      return res
        .status(200)
        .json({ code: responseCodes.AU.bookingStatusUpdated.code });
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  // getUserCarDetails: async (req, res) => {
  //   try {
  //     const { profile_id } = await joi
  //       .object({
  //         profile_id: joi.string().uuid().required(),
  //       })
  //       .validateAsync(req.params)
  //       .catch((err) => {
  //         console.log("err:", err);
  //         return res
  //           .status(400)
  //           .json({ code: responseCodes.AU.validations.invalidBody.code, description: err });
  //       });
  //       const { vehicle_id } = await joi.object({
  //         vehicle_id: joi.string().uuid()
  //       }).validateAsync(req.query);

  //     let vehicle = [],
  //     prefrense = [];

  //     try {
  //       prefrense = await UserService.getPrefrenseByIdOrUserId(req.headers.authorization, profile_id, vehicle_id);
  //     } catch (error) {
  //       console.log("profile fetch error:", error?.response);
  //       return res
  //         .status(error.response.status)
  //         .json(
  //           decryptResponseBody(
  //             error.response.headers.get("IV"),
  //             error.response.data
  //           )
  //         );
  //     }
  //     try {
  //       // console.log(account.id, "sd");
  //       vehicle = await SettingService.getVehicleList(req.headers.authorization);
  //     } catch (error) {
  //       console.log("profile fetch error:", error?.response);
  //       // return res.status(error.response.status).json(decryptResponseBody(error.response.headers.get("IV"), error.response.data));
  //     }

  //     const mappedData = mapVehileToUserVehicle(prefrense.data, vehicle.data);

  //     // mappedData.action = actions;
  //     // mappedData.interest = interest;
  //     // mappedData.course = course;

  //     return res.json({ profile: mappedData });
  //   } catch (error) {
  //     console.log("error:", error);
  //     return res
  //       .status(500)
  //       .json({ code: responseCodes.SE.internalError.code });
  //   }
  // },
  addBooking: async (req, res) => {
    try {
      let reversePriceCalculation;
      let addBookingRes;
      let savePaymentResponse;
      let saveBookingResponse;
      let uuid = uuidv4();
      let push_user_array = []
      const { profile_id } = req.params;
      const { error, value } = passengerBookingDtos.validate(req.body);
      if (error) {
        console.error("error:", error);
        return res.status(400).json({
          code: responseCodes.RA.validations.invalidBody.code,
          description: error,
        });
      }
      try {
        reversePriceCalculation = await getReversePriceCalculations({
          price_master_id: value.price_master_id,
          total_amount: value.total_amount,
        });
      } catch (error) {
        console.log("reverse calculation fetch error:", error?.response);
        return res
          .status(error.response.status)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        const addBookingPayload = {
          ride_id: value.ride_id,
        };
        addBookingRes = await addBooking(profile_id, addBookingPayload);
      } catch (error) {
        console.log("booking fetch error:", error?.response);
        return res
          .status(500)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }
      try {
        console.log("addBookingRes.availableSeats", addBookingRes.availableSeats)
        if (addBookingRes.availableSeats >= value.total_passenger) {

          // push_user_ids.push(addBookingRes.user_id)
          push_user_array.push({
            title: "Booked Ride",
            text: "Ride booking received",
            user_id: addBookingRes.user_id
          })

          // let pushObject = {
          //   title: "Booked Ride",
          //   text: "Ride booking received",
          // }
          let passengerPushObject = {
            title: "Booked Ride",
            text: "Ride booked successfully",
          }
          let bookingHistoryObject = {
            title: "Booked Ride",
            sub_title: "Ride booked successfully",
          }

          let paymentObject = {
            passenger_booking_id: uuid,
            ride_id: value.ride_id,
            profile_id: profile_id,
            payment_type: value.payment_type,
            currency: reversePriceCalculation.currency,
            total_amount: value.total_amount,
            is_refund: false,
            base_fare: reversePriceCalculation.base_fare.toString() || "0",
            wait_charges:
              reversePriceCalculation.wait_charges.toString() || "0",
            is_tax_percentage: reversePriceCalculation.is_tax_percentage
              ? 1
              : 0,
            tax_amount: reversePriceCalculation.tax_amount.toString() || "0",
            total_fare: reversePriceCalculation.total_fare || 0,
          };
          savePaymentResponse = await savePayment(paymentObject);
          if (
            savePaymentResponse.code === "PA200"
            //  && value.payment_type === "cash"
          ) {
            if (addBookingRes.availableSeats >= value.total_passenger) {
              
              let passengerBookingObject = {
                id: uuid,
                ride_id: value.ride_id,
                profile_id: profile_id,
                start_city_name: value.start_city_name,
                start_city_address: value.start_city_address,
                start_point_latitude: value.start_point_latitude,
                start_point_longitude: value.start_point_longitude,
                end_city_name: value.end_city_name,
                end_city_address: value.end_city_address,
                end_point_latitude: value.end_point_latitude,
                end_point_longitude: value.end_point_longitude,
                // distance: value.distance ,
                distance: value.distance != 0 ? value.distance : addBookingRes.ride.total_distance,
                start_time: addBookingRes.ride.start_time,
                end_time: addBookingRes.ride.end_time,
                is_round_trip: value.is_round_trip,
                total_passenger: value.total_passenger,
                amount_per_person: value.amount_per_person,
                total_amount: value.total_amount,
                payment_type: value.payment_type,
              };
              if (value.is_round_trip) {
                passengerBookingObject.round_start_time =
                  addBookingRes.ride.round_start_time;
                passengerBookingObject.round_end_time =
                  addBookingRes.ride.round_end_time;
              }
              saveBookingResponse = await createPassengerBooking(passengerBookingObject);
              if (saveBookingResponse.code === "PB201") {
                push_user_array.push({
                  title: "Booked Ride",
                  text: "Ride booked successfully",
                  user_id: saveBookingResponse.user_id
                })
                // push_user_ids.push(saveBookingResponse.user_id)
                bookingHistoryObject.booking_id = uuid
                // pushObject.user_ids = push_user_ids
                // passengerPushObject.user_id = 
                await module.exports.sendPush(push_user_array)
                await module.exports.saveBookingHistory(bookingHistoryObject)
              }
              return res.status(201).json({ code: 200 });
            } else {
              return res.status(400).json({
                code: responseCodes.RA.notFound.code,
                // description: responseCodes.RA.notFound.message,
              });
            }
          } else {
            if (addBookingRes.availableSeats >= value.total_passenger) {
              let passengerBookingObject = {
                id: uuid,
                ride_id: value.ride_id,
                profile_id: profile_id,
                start_city_name: value.start_city_name,
                start_city_address: value.start_city_address,
                start_point_latitude: value.start_point_latitude,
                start_point_longitude: value.start_point_longitude,
                end_city_name: value.end_city_name,
                end_city_address: value.end_city_address,
                end_point_latitude: value.end_point_latitude,
                end_point_longitude: value.end_point_longitude,
                distance: value.distance,
                start_time: addBookingRes.ride.start_time,
                end_time: addBookingRes.ride.end_time,
                is_round_trip: value.is_round_trip,
                total_passenger: value.total_passenger,
                amount_per_person: value.amount_per_person,
                total_amount: value.total_amount,
                booking_status: 7,
                payment_type: value.payment_type,
              };
              if (value.is_round_trip) {
                passengerBookingObject.round_start_time =
                  addBookingRes.ride.round_start_time;
                passengerBookingObject.round_end_time =
                  addBookingRes.ride.round_end_time;
              }
              saveBookingResponse = await createPassengerBooking(passengerBookingObject);
              if (saveBookingResponse.code === "PB201") {
                push_user_array.push({
                  title: "Booked Ride",
                  text: "Ride booked successfully",
                  user_id: saveBookingResponse.user_id
                })
                // push_user_ids.push(saveBookingResponse.user_id)
                bookingHistoryObject.booking_id = uuid
                // pushObject.user_ids = push_user_ids
                await module.exports.sendPush(push_user_array)
                // await module.exports.sendPush(passengerPushObject)
                await module.exports.saveBookingHistory(bookingHistoryObject)

              }
              return res.status(201).json({ code: 200 });
              // TODO : Online payment logic will be here
            } else {
              return res.status(400).json({
                code: responseCodes.RA.notFound.code,
                // description: responseCodes.RA.notFound.message,
              });
            }
          }
        } else {
          return res.status(400).json({
            code: responseCodes.RA.notFound.code,
            // description: responseCodes.RA.notFound.message,
          });
        }
      } catch (error) {
        console.log("error:", error);
        return res.status(500).json({
          code: responseCodes.SE.internalError.code,
          description: error,
        });
      }
    } catch (error) {
      console.log("error:", error);
      return res.status(500).json({
        code: responseCodes.SE.internalError.code,
        description: error,
      });
    }
  },
  getBookingListRefund: async (req, res) => {
    try {
      let result = [],
        bookings = [],
        data = [],
        count = 0;
      accounts = [];
      vehicle = [];
      colours = [];
      accountcount = 0;
      bookingRefundPayment = []

      const query = await joi
        .object({
          search: joi.string(),
          limit: joi.number(),
          page: joi.number(),
          sortBy: joi.string().valid().default("created_at"),
          orderBy: joi.string().valid("ASC", "DESC").default("DESC"),
          booking_status: joi.string(),
          refund_status: joi.string(),
          type: joi.number(),
          is_active: joi.boolean(),
          profiles: joi
            .string()
            .trim()
            .pattern(
              /^$|^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(,[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})*$/
            ),
        })
        .validateAsync(req.query)
        .catch((err) => {
          console.log("err:", err);
          return res
            .status(400)
            .json({ code: responseCodes.AU.validations.invalidQuery.code });
        });

      if (!query) return;

      try {
        result = await UserService.getAllBookingList({
          ...query,
        });
        bookings = result.data;
        count = result.count;
      } catch (error) {
        // console.log("accounts list fetch error:", error);
        return res
          .status(400)
          .json(
            decryptResponseBody(
              error.response.headers.get("IV"),
              error.response.data
            )
          );
      }

      if (bookings.length) {
        // for (let booking of bookings) {
        //   if (booking.ride_detail.driver_detail) {
        //     filter_user_id_array.push({
        //       id: booking.ride_detail.driver_detail?.user_id,
        //       type: "driver",
        //     });
        //   }
        //   if (booking.passenger_detail) {
        //     filter_user_id_array.push({
        //       id: booking.passenger_detail?.user_id,
        //       type: "passenger",
        //     });
        //   }
        //   if (booking.ride_detail.passenger_bookings.length) {
        //     for (let passenger of booking.ride_detail.passenger_bookings) {
        //       filter_user_id_array.push({
        //         id: passenger.passenger_detail.user_id,
        //         type: "ride_passenger",
        //       });
        //     }
        //   }
        // }

        // console.log(bookings, "bookings");
        // const { data, count: totalAccountsCount } =
        //   await AuthService.getAccountsList({
        //     accounts: filter_user_id_array
        //       .map((filteruser) => filteruser.id)
        //       .join(","),
        //   });

        // accounts = data;

        // bookings = mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking(
        //   accounts,
        //   bookings,
        //   filter_user_id_array,
        // );


        try {
          bookingRefundPayment = await PaymentService.getPassengerRefundPayment({
            ...query
          });
        } catch (error) {
          console.log("fetch error:", error?.response);
        }
        console.log(bookingRefundPayment, "bookingRefundPayment");

        try {
          vehicle = await SettingService.getVehicleList();
        } catch (error) {
          console.log("fetch error:", error?.response);
        }

        try {
          colours = await SettingService.getColourList(
            req.headers.authorization
          );
        } catch (error) {
          console.log("fetch error:", error?.response);
        }
        // console.log(colours, "colours");

        const mappedData = mapVehileToUserVehicleForBookingsList(
          bookings,
          vehicle.data,
          colours.data
        );

        const mappedDataForRefund = mapBookingToPaymentsRefund(
          bookingRefundPayment, mappedData
        );
        count = mappedDataForRefund.length

        return res.status(200).json({ data: mappedDataForRefund, count });
      } else {
        return res.status(200).json({ data: [], count: 0 });
      }
    } catch (error) {
      console.log("error:", error);
      return res
        .status(500)
        .json({ code: responseCodes.SE.internalError.code });
    }
  },
  sendPush: async (pushObject) => {
    try {
      console.log("push here ")

      return pushRes = await AuthService.sendPush(pushObject);
    } catch (error) {
      console.log("push fetch error:", error?.response);
      return error
    }
  },
  saveBookingHistory: async (bookingHistoryObject) => {
    try {
      await saveBookingHistory(bookingHistoryObject);
    } catch (error) {
      console.log("history fetch error:", error?.response);
      return error

    }
  }
};
