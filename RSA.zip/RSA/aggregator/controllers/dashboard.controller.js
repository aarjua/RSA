const {
    responseCodes,
} = require("../config");
const {
    auth: AuthService,
    user: UserService,
} = require("../services");
const { decryptResponseBody } = require("../services/crypto.service");
module.exports = {
    dashboardCount: async (req, res) => {
            try {
                try {
                    var usersCountResponse = await AuthService.getDashboardUserCount();
                } catch (error) {
                    console.log('articles list fetch err:', error);
                    return res.status(error.response.status).json(
                        decryptResponseBody(
                            error.response.headers.get("IV"),
                            error.response.data
                        )
                    );
                };
                return res.status(200).json({ usersCountResponse });
            } catch (error) {
                console.log("error:", error);
                return res.status(500).json({ code: responseCodes.SE.internalError.code });
            }
    }
}