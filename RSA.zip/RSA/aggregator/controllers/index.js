module.exports = {
    UserController: require("./user.controller"),
    DashboardController: require("./dashboard.controller")
}