const express = require('express');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require("cors");
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require("path");

const { NODE_ENV, ALLOWED_ORIGINS, REQUEST_RATE_LIMIT, REQUEST_RATE_LIMIT_DURATION } = require("./config/env.config");
// require("./config/db.config");
// require("./config/s3.config");

const app = express();

app.use(helmet());

app.use(
    NODE_ENV === "production" ?
        cors({ origin: ALLOWED_ORIGINS.split(",") })
        : cors()
);

app.use(rateLimit({
    windowMs: parseInt(REQUEST_RATE_LIMIT_DURATION),
    max: parseInt(REQUEST_RATE_LIMIT),
    handler: (req, res) => {
        res.status(429).send('Too many requests, please try again later.');
    }
}));

app.use(express.static(path.join(__dirname, 'public')));

logger.token('req-body', (req, res) => JSON.stringify(req.body));
app.use(logger(':method :url :status :res[content-length] - :response-time ms - body :req-body'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('./middlewares').encryptDecryptRequestResponse.decryptRequestBodyMiddleware);
app.use(require('./middlewares').encryptDecryptRequestResponse.encryptResponseBodyMiddleware);

app.use('/', require('./routes'));

// require("./config").swagger(app);

module.exports = app;