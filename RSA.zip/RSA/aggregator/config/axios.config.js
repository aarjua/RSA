const axios = require("axios");
const { encryptRequestBody, decryptResponseBody } = require("../services/crypto.service")

//TODO: Setup this later

// Encrypt the request data before sending it
axios.interceptors.request.use((config) => {
    const encryptedData = encryptRequestBody(config.data);
    config.data = encryptedData;
    return config;
});

// Decrypt the response data after receiving it
axios.interceptors.response.use((response) => {
    const decryptedData = decryptResponseBody(response.headers["IV"], response.data);
    response.data = decryptedData;
    return response;
}, (error) => {
    return Promise.reject(error);
});

module.exports = axios;





