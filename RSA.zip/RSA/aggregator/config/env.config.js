const console = require("./logs.config")('yap:auth:env');
const dotenv = require("dotenv");
const path = require("path");

// Load environment variables from parent folder .env file.
const envPath = path.resolve(__dirname, `../../${process.env.NODE_ENV || 'development'}.env`);
console.log('user envPath:', envPath)
dotenv.config({ path: envPath });

// Load environment variables from .env file in this service directory
const envPathLocal = path.resolve(__dirname, `../${process.env.NODE_ENV || 'development'}.env`);
console.log('user envPathLocal:', envPathLocal)
dotenv.config({ path: envPathLocal });

const joi = require("joi");

const environmentVariablesSchema = joi.object({
    NODE_ENV: joi.string().trim().allow(...['development', 'testing', 'staging', 'production']).required(),
    PORT: joi.number().default(3003),
    ENDPOINT: joi.string().uri().trim().optional(),
    RESPONSE_ENCRYPTION_KEY: joi.string().trim().required(),
    AUTH_SERVICE_URL: joi.string().uri().trim().required(),
    USER_SERVICE_URL: joi.string().uri().trim().required(),
    SETTING_SERVICE_URL: joi.string().uri().trim().required(),
    PAYMENT_SERVICE_URL: joi.string().uri().trim().required()
}).unknown();

const { error, value: environmentVariables } = environmentVariablesSchema.validate(process.env);
if (error) { console.error(`Environment variables validation error: ${error.message}`); process.exit(); }

module.exports = {
    ...environmentVariables,
    local: {
        username: environmentVariables.DB_USER,
        password: environmentVariables.DB_PASS,
        database: environmentVariables.DB_NAME,
        host: environmentVariables.DB_HOST,
        dialect: environmentVariables.DB_DIALECT,
        logging: false,
    }
};