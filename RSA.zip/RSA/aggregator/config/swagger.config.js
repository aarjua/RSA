const { NODE_ENV } = require("./env.config")
module.exports = function config(app) {
    if (['development', 'testing', 'staging'].includes(NODE_ENV)) {
        const swagger = require("swagger-ui-express");
        const yaml = require("yamljs");
        const path = require("path");
        app.use("/api-docs", swagger.serve, swagger.setup(yaml.load(
            path.resolve(__dirname, "../", "swagger.yaml")
        )));
    }
}