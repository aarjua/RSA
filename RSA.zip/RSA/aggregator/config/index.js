module.exports = {
    // enums: require("./enums.config"),
    env: require("./env.config"),
    responseCodes: require("./responseCodes.config"),
    logs: require("./logs.config"),
    swagger: require("./swagger.config"),
    enums: require("./enums.config"),
    s3: require("./s3.config"),
    // axios: require("./axios.config")
}