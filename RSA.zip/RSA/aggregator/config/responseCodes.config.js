module.exports = {
    /**
     * SE - System
     */
    SE: {
        internalError: {
            code: "SE500",
            message: "internal server error"
        }
    },
    AU: {
        validations: {
          invalidBody: {
            code: "AU400",
            message: "body invalid",
          },
          accountEmailAlreadyExists: {
            code: "AU407",
            message: "account email already exists",
          },
          accountContactAlreadyExists: {
            code: "AU408",
            message: "account contact already exists",
          },
          invalidQuery: {
            code: "AU410",
            message: "query invalid",
          },
          invalidToken: {
            code: "AU411",
            message: "invalid token"
          }
        },
        rcStatusUpdated: {
          code: "AU512",
          message: "rc status updated"
        },
        rideNotFound: {
          code: "AU413",
          message: "ride not found"
        },
        rcStatusUpdated: {
          code: "AU512",
          message: "rc status updated"
        },
        bookingStatusUpdated: {
          code: "PB411",
          message: "booking status updated",
        },
    },
    UR: {
        created: {
          code: "SU201",
          message: "created",
        },
        notFound: {
          code: "SU404",
          message: "system user not found",
        },
        validations: {
          invalidBody: {
            code: "SU400",
            message: "body invalid",
          },
          exists: {
            code: "SU409",
            message: "already exists",
          },
        },
        updated: {
          code: "SU200",
          message: "updated",
        },
      },
    RA: {
      notFound: {
        code: "RA404",
        message: "no available seats"
    }
    }  
    
};

(() => {
    const codes = new Set();

    const checkCodesUniqueness = (obj) => {
        for (const key in obj) {
            const code = obj[key].code;
            const message = obj[key].message;

            if (code !== undefined) {
                if (codes.has(code)) {
                    throw new Error(`Duplicate code found: ${code}.`);
                } else {
                    codes.add(code);
                }
            }

            if (message !== undefined && /[A-Z]/.test(message)) {
                throw new Error(`Capital letters found in message: ${message}`);
            }

            if (typeof obj[key] === 'object') {
                checkCodesUniqueness(obj[key]);
            }

        }
    };

    checkCodesUniqueness(module.exports);
})();

