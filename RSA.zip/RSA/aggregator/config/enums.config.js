module.exports = {
 
    roles: {
        passenger: 'b4ce3bb1-18cd-46f4-8ad0-99ebb84bb60f',
        driver: 'c7468e01-7b57-4b43-8c7a-78b6986e8d6d',
        passengerWithDriver:'a87a54db-7350-4b5e-89f1-168386915e9b'
    },
 
}