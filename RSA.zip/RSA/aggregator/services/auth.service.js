const {
  env: { AUTH_SERVICE_URL },
} = require("../config");
const axios = require("axios");
const { decryptResponseBody } = require("./crypto.service");
module.exports = {
  sortByColumns: ["email", "assignedRole.name", "contact"],
  getAccountsList: async ({
    is_active,
    search,
    page,
    limit,
    sortBy,
    orderBy,
    role_id,
    accounts,
    type,
  }) => {
    const sortByColumns = module.exports.sortByColumns;
    if (!sortByColumns.includes(sortBy)) {
      sortBy = "";
      orderBy = "";
    }

    try {
      const response = await axios.get(AUTH_SERVICE_URL + "/accounts", {
        params: {
          ...(typeof is_active === "boolean" && { is_active }),
          ...(search && { search }),
          ...(page && { page }),
          ...(limit && { limit }),
          ...(sortBy && { sortBy }),
          ...(orderBy && { orderBy }),
          ...(role_id && { role_id }),
          ...(accounts && { accounts }),
          ...(type && { type }),
        },
      });

      const { data, count } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data, count };
    } catch (err) {
      throw err;
    }
  },
  getAllAccountsList: async () => {
    try {
      const response = await axios.get(AUTH_SERVICE_URL + "/accounts");

      const { data, count } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data, count };
    } catch (err) {
      throw err;
    }
  },
  getAccountById: async (id) => {
    try {
      const response = await axios.get(AUTH_SERVICE_URL + "/accounts/" + id);

      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  getRoleById: async (id) => {
    try {
      const response = await axios.get(AUTH_SERVICE_URL + "/roles/" + id);
      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  deleteAccountById: async (id) => {
    try {
      const response = await axios.delete(AUTH_SERVICE_URL + "/accounts/" + id);

      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { status: response.status, data };
    } catch (err) {
      throw err;
    }
  },
  updateAccountById: async (id, body) => {
    try {
      let response;
      if (body.type == "MU") {
        response = await axios.patch(AUTH_SERVICE_URL + "/accounts/" + id, {
          email: body.email,
          password: body.password,
          contact: body.contact,
          role_id: body.role_id,
          country_code: body.country_code,
          iso: body.iso,
          type: body.type,
        });
      } else {
        response = await axios.patch(AUTH_SERVICE_URL + "/accounts/" + id, {
          email: body.email,
          password: body.password,
          contact: body.contact,
          role_id: body.role_id,
          type: body.type,
        });
      }

      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { status: response.status, data };
    } catch (err) {
      throw err;
    }
  },
  getDashboardUserCount: async () => {
    try {
      const response = await axios.get(
        AUTH_SERVICE_URL + "/dashboard/user-count"
      );

      const { data } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data };
    } catch (err) {
      throw err;
    }
  },
  getResponseCode: async () => {
    try {
      const response = await axios.get(AUTH_SERVICE_URL + "/response-code");

      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  updateUserRole: async (user_id, status) => {
    try {
      const response = await axios.patch(
        AUTH_SERVICE_URL + "/user-role-change/" + user_id + "/" + status
      );

      const { data } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data };
    } catch (err) {
      throw err;
    }
  },
  sendPushNotification: async (user_id, status) => {
    try {
      const response = await axios.patch(
        AUTH_SERVICE_URL + "/send_push_notification/" + user_id + "/" + status
      );

      const { data } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data };
    } catch (err) {
      throw err;
    }
  },
  sendPush: async (reqdata) => {
    try {
      const requestBody = {
        reqdata
      }
      const response = await axios.post(AUTH_SERVICE_URL+"/send_push_notifation", requestBody);

      const { data } = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return { data };
    } catch (err) {
      throw err;
    }
  },
};
