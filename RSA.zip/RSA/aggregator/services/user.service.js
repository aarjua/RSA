const console = require("../config/logs.config")("yap:aggregator:services:user");
const {
    env: {
        USER_SERVICE_URL
    },
} = require("../config")
const axios = require("axios");
const { decryptResponseBody } = require("./crypto.service");
const moment = require('moment');
module.exports = {
    // sortByColumns: ["name", "country.name"],
    sortByRidesColumns: ["start_city_name", "end_city_name", "start_city_address", "end_city_address", "driver_name", "vehicle_no","created_at","start_time","end_time"],
    sortByColumns: ["name"],
    sortByBookingColumns: ["created_at"],
    getProfilesList: async ({
        search,
        page,
        limit,
        sortBy,
        orderBy,
        profiles,
        type,
        users
    }) => {
        const sortByColumns = module.exports.sortByColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }

        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles', {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(profiles && { profiles }),
                    ...(type && { type }),
                    ...(users && { users }),
                }
            });

            const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getProfileByIdOrUserId: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getProfileCourseByIdOrUserId: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/course/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getProfileInterestByIdOrUserId: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/getInterest/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },

    deleteProfileByIdOrUserId: async (id) => {
        try {
            const response = await axios.delete(USER_SERVICE_URL + '/profiles/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    updateProfileByIdOrUserId: async (id, {
        name, city, zip_code, profile_type, dob, profile_detail, gender, address
    }) => {
        const response = await axios.patch(USER_SERVICE_URL + '/profiles/' + id, {
            ...(name && { name }),
            ...({ city }),
            ...(zip_code && { zip_code }),
            ...({ dob }),
            ...(profile_type && {profile_type}),
            ...({ profile_detail }),
            ...(gender && { gender }),
            ...(address && { address })
        });

        const data = decryptResponseBody(response.headers.get("IV"), response.data);
        return { status: response.status, data };
    },
    updateProfileByIdOrUserIdWithTypeMU: async (id, {
        name, city, zip_code, profile_type, dob, profile_detail, gender, address, type , profile
    }) => {
        const response = await axios.patch(USER_SERVICE_URL + '/profiles/' + id, {
            ...(name && { name }),
            ...({ city }),
            ...(zip_code && { zip_code }),
            ...({ dob }),
            ...(profile && {profile}),
            ...({ profile_detail }),
            ...(gender && { gender }),
            ...(address && { address }),
            ...(profile_type && { profile_type }),
            ...(type && { type })
        });

        const data = decryptResponseBody(response.headers.get("IV"), response.data);
        return { status: response.status, data };
    },
    updateProfileCourseByIdOrUserId: async (id, {
        type
    }) => {
        const response = await axios.post(USER_SERVICE_URL + '/course/' + id, {
            ...(type && { type }),
        });

        const data = decryptResponseBody(response.headers.get("IV"), response.data);
        return { status: response.status, data };
    },
    getQuestionList: async ({
        search,
        page,
        limit,
        sortBy,
        orderBy,
    }) => {
        const sortByQuestionColumns = module.exports.sortByQuestionColumns;
        if (!sortByQuestionColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }

        try {
            const response = await axios.get(USER_SERVICE_URL + '/questions', {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                }
            });

            const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getQuestion: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/questions/' + id);

            const { data } = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getResponseCode: async () => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/response-code');

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getCarByIdOrUserId: async (auth, id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/get-car/' + id, {
                headers: {
                    Authorization: auth,
                },
            });

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getPrefrenseByIdOrUserId: async (auth, id, vehicle_id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/get-user-prefrense/' + id, {
                params: {
                    ...(vehicle_id && { vehicle_id }),
                },
                headers: {
                    Authorization: auth,
                },
            });

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    updateRCStatus: async (id, status) => {
        try {
            const response = await axios.patch(USER_SERVICE_URL + '/profiles/update-rc-status/' + id + '/' + status);
            // console.log(response, "res+++")
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    updateBookingStatus: async (id, status) => {
        try {
            const response = await axios.patch(USER_SERVICE_URL + '/bookings/block-unblock/' + id + '/' + status);
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    updateProfileStatus: async (id, status) => {
        try {
            const response = await axios.patch(USER_SERVICE_URL + '/profiles/update-role-status/' + id + '/' + status);
            // console.log(response, "res+++")
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getRidesList: async ({
        search,
        page,
        limit,
        sortBy,
        orderBy,
        ride_status,
        type,
        is_active,
        profiles,
    }) => {
        const sortByColumns = module.exports.sortByRidesColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }

        try {
            const response = await axios.get(USER_SERVICE_URL + '/rides', {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(ride_status && { ride_status }),
                    ...(type && { type }),
                    ...(typeof is_active === "boolean" && { is_active }),
                    ...(profiles && { profiles }),
                }
            });

            return data = decryptResponseBody(response.headers.get("IV"), response.data);
            // const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getRideById: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/rides/' + id);
            // console.log(response, "res+++")
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data.data;
        } catch (err) {
            throw err;
        }
    },
    getAvailableRidesList: async ({
        start_city_name,
        start_city_address,
        start_point_latitude,
        start_point_longitude,
        end_city_name,
        end_city_address,
        end_point_latitude,
        end_point_longitude,
        route_description,
        is_round_trip,
        start_time,
        round_start_time,
        seats,
        sort_by,
        order_by,
        user_preference,
        search,
        page,
        limit,
        sortBy,
        orderBy,
        ride_status,
        type,
        is_active,
        profiles,
    }) => {
        const sortByColumns = module.exports.sortByRidesColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }
// console.log("start+time",start_time,"starttime+++++++++++")
        const requestBody = {
            start_city_name,
            start_city_address,
            start_point_latitude,
            start_point_longitude,
            end_city_name,
            end_city_address,
            end_point_latitude,
            end_point_longitude,
            route_description,
            is_round_trip,
            start_time,
            round_start_time,
            seats,
            sort_by,
            order_by,
            user_preference,
          };

        try {
            const response = await axios.post(USER_SERVICE_URL + '/rides/fetch/availableRideList',requestBody, {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(ride_status && { ride_status }),
                    ...(type && { type }),
                    ...(typeof is_active === "boolean" && { is_active }),
                    ...(profiles && { profiles }),
                },
                // data: {
                //     start_city_name,
                //     start_city_address,
                //     start_point_latitude,
                //     start_point_longitude,
                //     end_city_name,
                //     end_city_address,
                //     end_point_latitude,
                //     end_point_longitude,
                //     route_description,
                //     is_round_trip,
                //     start_time,
                //     round_start_time,
                //     seats,
                // }
            });

            return data = decryptResponseBody(response.headers.get("IV"), response.data);
            // const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getAvailbleRidelistforTesting: async ({
        start_city_name,
        start_city_address,
        start_point_latitude,
        start_point_longitude,
        end_city_name,
        end_city_address,
        end_point_latitude,
        end_point_longitude,
        route_description,
        is_round_trip,
        start_time,
        round_start_time,
        seats,
        sort_by,
        order_by,
        user_prefrense,
        search,
        page,
        limit,
        sortBy,
        orderBy,
        ride_status,
        type,
        is_active,
        profiles,
    }) => {
        const sortByColumns = module.exports.sortByRidesColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }
// console.log("start+time",start_time,"starttime+++++++++++")
        const requestBody = {
            start_city_name,
            start_city_address,
            start_point_latitude,
            start_point_longitude,
            end_city_name,
            end_city_address,
            end_point_latitude,
            end_point_longitude,
            route_description,
            is_round_trip,
            start_time,
            round_start_time,
            seats,
            sort_by,
            order_by,
            user_prefrense,
          };

        try {
            const response = await axios.post(USER_SERVICE_URL + '/rides/fetch/getAvailbleRidelistforTesting',requestBody, {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(ride_status && { ride_status }),
                    ...(type && { type }),
                    ...(typeof is_active === "boolean" && { is_active }),
                    ...(profiles && { profiles }),
                },
                // data: {
                //     start_city_name,
                //     start_city_address,
                //     start_point_latitude,
                //     start_point_longitude,
                //     end_city_name,
                //     end_city_address,
                //     end_point_latitude,
                //     end_point_longitude,
                //     route_description,
                //     is_round_trip,
                //     start_time,
                //     round_start_time,
                //     seats,
                // }
            });

            return data = decryptResponseBody(response.headers.get("IV"), response.data);
            // const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getAllBookingList: async ({
        search,
        page,
        limit,
        sortBy,
        orderBy,
        booking_status,
        type,
        is_active,
        profiles,
    }) => {
        const sortByColumns = module.exports.sortByBookingColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }


        try {
            // console.log("here bookings+++++")
            const response = await axios.get(USER_SERVICE_URL + '/bookings', {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(booking_status && { booking_status }),
                    ...(type && { type }),
                    ...(typeof is_active === "boolean" && { is_active }),
                    ...(profiles && { profiles }),
                },
            });
            // console.log("here bookings+++++",response.data)
            return data = decryptResponseBody(response.headers.get("IV"), response.data);
            // const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getBookingById: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/bookings/' + id);
            // console.log(response, "res+++")
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data.data;
        } catch (err) {
            throw err;
        }
    },
    addBooking: async (id,requestBody) => {
        try {
            const response = await axios.post(USER_SERVICE_URL + '/bookings/' + id,requestBody);
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data.data;
        } catch (err) {
            throw err;
        }
    },
    createPassengerBooking: async (requestBody) => {
        try {
            const response = await axios.post(USER_SERVICE_URL + '/bookings/passenger/create_booking',requestBody);
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    saveBookingHistory: async (requestBody) => {
        try {
            const response = await axios.post(USER_SERVICE_URL + '/bookings/passenger/create_booking_history',requestBody);
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data.data;
        } catch (err) {
            throw err;
        }
    }
};