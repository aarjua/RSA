const console = require("../config/logs.config")("yap:auth:services:file");
const excelJS = require("exceljs");
const fs = require("fs");
const path = require("path");
module.exports = {
  personMasterDataExportToExcel: async (data) => {
    return new Promise(async (resolve, reject) => {
      try {
        if (!Array.isArray(data))
          reject({ message: `data isn't of type array.` });
        const workbook = new excelJS.Workbook();
        const worksheet = workbook.addWorksheet("Sheet1");
        worksheet.columns = [
          { header: "S no.", key: "s_no", width: 10 },
          { header: "First Name", key: "first_name", width: 10 },
          { header: "Last Name", key: "last_name", width: 10 },
          { header: "Organisation", key: "organisation", width: 10 },
          { header: "Function", key: "function_in_organisation", width: 10 },
        ];

        let counter = 1;
        data.forEach((user) => {
          user.s_no = counter;
          worksheet.addRow(user); // Add data in worksheet
          counter++;
        });

        const date = new Date().getTime();
        await workbook.xlsx.writeFile(`./public/downloads/pmd-${date}.xlsx`);

        console.log(
          "`./public/downloads/pmd-${date}.xlsx`:",
          `./public/downloads/pmd-${date}.xlsx`
        );
        resolve(`./public/downloads/pmd-${date}.xlsx`);
      } catch (err) {
        console.error(err);
        reject(err);
      }
    });
  },
  UserExportToCSV: async (data) => {
    return new Promise(async (resolve, reject) => {
      try {
        if (!Array.isArray(data))
          reject({ message: `data isn't of type array.` });
        const csvData = [];

        const headerRow = ["S no.", "Name", "Email", "Role", "Contact Number"];
        csvData.push(headerRow);

        let counter = 1;
        data.forEach((obj) => {
          const row = [counter, obj.name, obj.email, obj.role, obj.contact_no];
          csvData.push(row);
          counter++;
        });

        // Convert the CSV data to a string
        const csvString = csvData.map((row) => row.join(",")).join("\n");
        const date = new Date().getTime();

        // Write the CSV string to a file
        fs.writeFile(
          path.join(__dirname, "../public/downloads", "users.csv"),
          csvString,
          (err) => {
            if (err) {
              console.log("Rejected", err);
              reject(err);
            } else {
              console.log(
                "`./public/downloads/pmd-${date}.csv`:",
                `./public/downloads/pmd-${date}.csv`
              );
              resolve(`./public/downloads/pmd-${date}.csv`);
            }
          }
        );
      } catch (err) {
        console.error(err);
        reject(err);
      }
    });
  },
};
