module.exports = {
  mapAccountsToProfiles: (accounts, profiles, type = "user") => {
    const mappedAccounts = accounts.map((account) => {
      const matchingProfile = profiles.length
        ? profiles.find((profile) => profile.user_id === account.id)
        : null;
      if (type == "driver") {
        return {
          ...account,
          profile: matchingProfile,
        };
      } else {
        return {
          ...account,
          profile: matchingProfile || null,
        };
      }
    });
    return mappedAccounts;
  },
  mapProfilesToRoles: async (profiles, roles) => {
    const mappedAccounts = profiles.map((profile) => {
      const matchingProfile = roles.length
        ? roles.find((role) => role.id == profile.requested_role)
        : null;
      profile.requested_role_name = matchingProfile
        ? matchingProfile.name || null
        : "";
      return profile;
    });
    return mappedAccounts;
  },
  mapProfilesToAccounts: (accounts, profiles) => {
    const mappedAccounts = profiles.map((profile) => {
      const matchingAccount = accounts.find(
        (account) => profile.user_id === account.id
      );
      return {
        ...matchingAccount,
        profile,
      };
    });
    return mappedAccounts;
  },
  mapProfilesToAccountsForDriverEmailVerifiedKey: (accounts, rides) => {
    const mappedAccounts = rides.map((ride) => {
      const matchingAccount = accounts.find(
        (account) => ride.driver_detail.user_id === account.id
      );
      ride.driver_detail.isEmailVerified = matchingAccount
        ? matchingAccount.is_email_verified
        : false;
      ride.driver_detail.isContactVerified = matchingAccount
        ? matchingAccount.is_contact_verified
        : false;
      return ride;
    });
    return mappedAccounts;
  },
  mapProfilesToAccountsforDriver: (accounts, profiles) => {
    const mappedAccounts = accounts.map((account) => {
      const matchingProfile = profiles.length
        ? profiles.find((profile) => profile.user_id === account.id)
        : null;
      if (matchingProfile) {
        return {
          ...account,
          profile: matchingProfile,
        };
      } else {
        return {
          ...account,
        };
      }
    });
    return mappedAccounts;
  },
  mapCampaignsToUsers: (campaigns, users) => {
    const mappedCampaigns = campaigns.map((campaign) => {
      const user = users.find((user) => campaign.user_id === user.id);
      return {
        ...campaign,
        user: user
          ? {
            id: user.id,
            email: user.email,
            contact: user?.contact || null,
            profile: user.profile
              ? {
                name: user?.profile?.name || null,
                id: user?.profile?.id || null,
                profile_url: user?.profile?.profile_url || null,
              }
              : null,
          }
          : null,
      };
    });
    return mappedCampaigns;
  },
  mapProjectsToUsers: (projects, users) => {
    const mappedProjects = projects.map((project) => {
      const user = users.find((user) => project.user_id === user.id);
      return {
        ...project,
        user: user
          ? {
            id: user.id,
            email: user.email,
            contact: user?.contact || null,
            profile: user.profile
              ? {
                name: user?.profile?.name || null,
                id: user?.profile?.id || null,
                profile_url: user?.profile?.profile_url || null,
              }
              : null,
          }
          : null,
      };
    });
    return mappedProjects;
  },
  mapArticlesToUsers: (articles, users) => {
    const mappedArticles = articles.map((article) => {
      const user = users.find((user) => article.user_id === user.id);
      return {
        ...article,
        user: user
          ? {
            id: user.id,
            email: user.email,
            contact: user?.contact || null,
            profile: user.profile
              ? {
                name: user?.profile?.name || null,
                id: user?.profile?.id || null,
                profile_url: user?.profile?.profile_url || null,
              }
              : null,
          }
          : null,
      };
    });
    return mappedArticles;
  },

  mapAnswersinToQuestion: (questions, answers) => {
    const mappedAccounts = questions.map((question) => {
      const questionanswers = question.questionanswers.map((quesanswer) => {
        const matchingAnswer = answers.find(
          (answer) => answer.id === quesanswer.answer_id
        );
        return matchingAnswer
          ? { answer: matchingAnswer, ...quesanswer }
          : null;
      });
      return { ...question, questionanswers };
    });
    return mappedAccounts;
  },
  mapVehileToUserVehicle: (profiles, vehicles, colours) => {
    const mappedAccounts = profiles.map((profile) => {
      let company_name,
        company_image,
        type_name,
        seat,
        model_name,
        colour_name,
        colour_code;
      for (let vehicle of vehicles) {
        if (vehicle.id == profile.vehicle_id) {
          company_name = vehicle.company_name;
          company_image = vehicle.image;
          for (let type of vehicle.vehicletypes) {
            if (type.id == profile.type_id) {
              type_name = type.type;
            }
            // for (let model of type.vehiclemodels) {
              // if (model.id == profile.model_id) {
                model_name = type.vehiclemodels.model;
                seat = type.vehiclemodels.seat;
              // }
            // }
          }
        }
      }
      for (let colour of colours) {
        if (colour.id == profile.colour_id) {
          colour_name = colour.colour;
          colour_code = colour.colour_code;
        }
      }

      profile.company_name = company_name;
      profile.company_image = company_image;
      profile.type_name = type_name;
      profile.seat = seat;
      profile.model_name = model_name;
      profile.colour_name = colour_name;
      profile.colour_code = colour_code;
      return profile;
    });
    return mappedAccounts;
  },
  mapVehileToUserVehiclefroDriver: (profiles, vehicles, colours) => {
    const mappedAccounts = profiles.map((profile) => {
      let company_name,
        company_image,
        type_name,
        seat,
        model_name,
        colour_name,
        colour_code;
      for (let vehicle of vehicles) {
        if (vehicle.id == profile.vehicle_detail.vehicle_id) {
          company_name = vehicle.company_name;
          company_image = vehicle.image;
          for (let type of vehicle.vehicletypes) {
            if (type.id == profile.vehicle_detail.type_id) {
              type_name = type.type;
            }
            // for (let model of type.vehiclemodels) {
            //   if (model.id == profile.vehicle_detail.model_id) {
                model_name = type.vehiclemodels.model;
                seat = type.vehiclemodels.seat;
              //}
            //}
          }
        }
      }
      for (let colour of colours) {
        if (colour.id == profile.vehicle_detail.colour_id) {
          colour_name = colour.colour;
          colour_code = colour.colour_code;
        }
      }

      profile.vehicle_detail.company_name = company_name;
      profile.vehicle_detail.company_image = company_image;
      profile.vehicle_detail.type_name = type_name;
      profile.vehicle_detail.seat = seat;
      profile.vehicle_detail.model_name = model_name;
      profile.vehicle_detail.colour_name = colour_name;
      profile.vehicle_detail.colour_code = colour_code;
      return profile;
    });
    return mappedAccounts;
  },
  mapVehileToUserVehicleForAvailableRides: (profiles, vehicles, colours) => {
    const mappedAccounts = profiles.map((profile) => {
      let company_name,
        company_image,
        type_name,
        seat,
        model_name,
        colour_name,
        colour_code;
      for (let vehicle of vehicles) {
        if (vehicle.id == profile.vehicle_detail.vehicle_id) {
          company_name = vehicle.company_name;
          company_image = vehicle.image;
          for (let type of vehicle.vehicletypes) {
            if (type.id == profile.vehicle_detail.type_id) {
              type_name = type.type;
            }
            //for (let model of type.models) {
             // if (model.id == profile.vehicle_detail.model_id) {
                model_name = type.vehiclemodels.model;
                seat = type.vehiclemodels.seat;
             // }
           // }
          }
        }
      }
      for (let colour of colours) {
        if (colour.id == profile.vehicle_detail.colour_id) {
          colour_name = colour.colour;
          colour_code = colour.colour_code;
        }
      }

      profile.vehicle_detail.company_name = company_name;
      profile.vehicle_detail.company_image = company_image;
      profile.vehicle_detail.type_name = type_name;
      profile.vehicle_detail.seat = seat;
      profile.vehicle_detail.model_name = model_name;
      profile.vehicle_detail.colour_name = colour_name;
      profile.vehicle_detail.colour_code = colour_code;
      return profile;
    });
    return mappedAccounts;
  },
  mapVehileToUserVehicleForBookingsList: (bookings, vehicles, colours, type) => {
    if (type && type != 1) {
      const mappedByBookingDateAccounts = bookings.map((bookingByDate) => {
        const mappedAccounts = bookingByDate.data.map((booking) => {
          let company_name,
            company_image,
            type_name,
            seat,
            model_name,
            colour_name,
            colour_code;
          for (let vehicle of vehicles) {
            if (vehicle.id == booking.ride_detail.vehicle_detail.vehicle_id) {
              company_name = vehicle.company_name;
              company_image = vehicle.image;
              for (let type of vehicle.vehicletypes) {
                if (type.id == booking.ride_detail.vehicle_detail.type_id) {
                  type_name = type.type;
                  
                }
               // for (let model of type.models) {
                 // if (model.id == booking.ride_detail.vehicle_detail.model_id) {
                    model_name = type.vehiclemodels.model;
                     seat = type.vehiclemodels.seat;
                  //}
               // }
              }
            }
          }
          for (let colour of colours) {
            if (colour.id == booking.ride_detail.vehicle_detail.colour_id) {
              colour_name = colour.colour;
              colour_code = colour.colour_code;
            }
          }

          booking.ride_detail.vehicle_detail.company_name = company_name;
          booking.ride_detail.vehicle_detail.company_image = company_image;
          booking.ride_detail.vehicle_detail.type_name = type_name;
          booking.ride_detail.vehicle_detail.seat = seat;
          booking.ride_detail.vehicle_detail.model_name = model_name;
          booking.ride_detail.vehicle_detail.colour_name = colour_name;
          booking.ride_detail.vehicle_detail.colour_code = colour_code;
          return booking;
        });
        return {
          date: bookingByDate.date,
          data: mappedAccounts
        }
        return mappedAccounts;
      });
      return mappedByBookingDateAccounts;
    } else {
      const mappedAccounts = bookings.map((booking) => {
        let company_name,
          company_image,
          type_name,
          seat,
          model_name,
          colour_name,
          colour_code;
        // console.log("vehicles",vehicles)
        for (let vehicle of vehicles) {
          if (vehicle.id == booking.ride_detail.vehicle_detail.vehicle_id) {
            company_name = vehicle.company_name;
            company_image = vehicle.image;
            for (let type of vehicle.vehicletypes) {
              if (type.id == booking.ride_detail.vehicle_detail.type_id) {
                type_name = type.type;
                
              }
              //for (let model of type.models) {
               // if (model.id == booking.ride_detail.vehicle_detail.model_id) {
                  model_name = type.vehiclemodels.model;
                  seat = type.vehiclemodels.seat;
                //}
             // }
            }
          }
        }
        for (let colour of colours) {
          if (colour.id == booking.ride_detail.vehicle_detail.colour_id) {
            colour_name = colour.colour;
            colour_code = colour.colour_code;
          }
        }

        booking.ride_detail.vehicle_detail.company_name = company_name;
        booking.ride_detail.vehicle_detail.company_image = company_image;
        booking.ride_detail.vehicle_detail.type_name = type_name;
        booking.ride_detail.vehicle_detail.seat = seat;
        booking.ride_detail.vehicle_detail.model_name = model_name;
        booking.ride_detail.vehicle_detail.colour_name = colour_name;
        booking.ride_detail.vehicle_detail.colour_code = colour_code;
        return booking;
      });
      return mappedAccounts;
    }
  },
  mapProfilesToAccountsForDriverEmailVerifiedKeyForBooking: (accounts, bookings, filter_users, type) => {
    let driver = filter_users.filter((array) => array.type == "driver")
    let passenger = filter_users.filter((array) => array.type == "passenger")
    let ride_passenger = filter_users.filter((array) => array.type == "ride_passenger")
    if (type && type != 1) {
      const groupByDate = bookings.map((groupbydate) => {
        const mappedAccounts = groupbydate.data.map((booking) => {

          if (driver.length > 0) {
            const matchingDriver = driver.find((user) => user.id === booking.ride_detail.driver_detail.user_id);
            if (matchingDriver) {
              const matchingAccount = accounts.find((account) => account.id === matchingDriver.id);
              booking.ride_detail.driver_detail.isEmailVerified = matchingAccount
                ? matchingAccount.is_email_verified
                : false;
              booking.ride_detail.driver_detail.isContactVerified = matchingAccount
                ? matchingAccount.is_contact_verified
                : false;
              booking.ride_detail.driver_detail.contact = matchingAccount
                ? matchingAccount.contact
                : "";
              booking.ride_detail.driver_detail.email = matchingAccount
                ? matchingAccount.email
                : "";
              booking.ride_detail.driver_detail.firebase_token = matchingAccount
                ? matchingAccount.firebase_token
                : "";
            }
          }
          if (passenger.length > 0) {
            const matchingPassenger = passenger.find((user) => user.id === booking.passenger_detail.user_id);
            if (matchingPassenger) {
              const matchingPassengerAccount = accounts.find((account) => account.id === matchingPassenger.id);
              booking.passenger_detail.isEmailVerified = matchingPassengerAccount
                ? matchingPassengerAccount.is_email_verified
                : false;
              booking.passenger_detail.isContactVerified = matchingPassengerAccount
                ? matchingPassengerAccount.is_contact_verified
                : false;
              booking.passenger_detail.contact = matchingPassengerAccount
                ? matchingPassengerAccount.contact
                : "";
              booking.passenger_detail.email = matchingPassengerAccount
                ? matchingPassengerAccount.email
                : "";
              booking.passenger_detail.firebase_token = matchingPassengerAccount
                ? matchingPassengerAccount.firebase_token
                : "";
            }
          }
          if (ride_passenger.length > 0) {
            for (let passenger of booking.ride_detail.passenger_bookings) {
              const matchingRidePassenger = ride_passenger.find((user) => user.id === passenger.passenger_detail.user_id);
              if (matchingRidePassenger) {
                const matchingRidePassengerAccount = accounts.find((account) => account.id === matchingRidePassenger.id);
                passenger.passenger_detail.isEmailVerified = matchingRidePassengerAccount
                  ? matchingRidePassengerAccount.is_email_verified
                  : false;
                passenger.passenger_detail.isContactVerified = matchingRidePassengerAccount
                  ? matchingRidePassengerAccount.is_contact_verified
                  : false;
                passenger.passenger_detail.contact = matchingRidePassengerAccount
                  ? matchingRidePassengerAccount.contact
                  : "";
                passenger.passenger_detail.email = matchingRidePassengerAccount
                  ? matchingRidePassengerAccount.email
                  : "";
                passenger.passenger_detail.firebase_token = matchingRidePassengerAccount
                  ? matchingRidePassengerAccount.firebase_token
                  : "";
              }
            }
          }
          // const matchingAccount = accounts.find(
          //   (account) => booking.ride_detail.driver_detail.user_id === account.id
          // );
          // booking.ride_detail.driver_detail.isEmailVerified = matchingAccount
          //   ? matchingAccount.is_email_verified
          //   : false;
          // booking.ride_detail.driver_detail.isContactVerified = matchingAccount
          //   ? matchingAccount.is_contact_verified
          //   : false;
          return booking;
        });
        return {
          date: groupbydate.date,
          data: mappedAccounts
        }
      });

      return groupByDate
    } else {
      const mappedAccounts = bookings.map((booking) => {

        if (driver.length > 0) {
          const matchingDriver = driver.find((user) => user.id === booking.ride_detail.driver_detail.user_id);
          if (matchingDriver) {
            const matchingAccount = accounts.find((account) => account.id === matchingDriver.id);
            booking.ride_detail.driver_detail.isEmailVerified = matchingAccount
              ? matchingAccount.is_email_verified
              : false;
            booking.ride_detail.driver_detail.isContactVerified = matchingAccount
              ? matchingAccount.is_contact_verified
              : false;
            booking.ride_detail.driver_detail.contact = matchingAccount
              ? matchingAccount.contact
              : "";
            booking.ride_detail.driver_detail.email = matchingAccount
              ? matchingAccount.email
              : "";
            booking.ride_detail.driver_detail.firebase_token = matchingAccount
              ? matchingAccount.firebase_token
              : "";
          }
        }
        if (passenger.length > 0) {
          const matchingPassenger = passenger.find((user) => user.id === booking.passenger_detail.user_id);
          if (matchingPassenger) {
            const matchingPassengerAccount = accounts.find((account) => account.id === matchingPassenger.id);
            booking.passenger_detail.isEmailVerified = matchingPassengerAccount
              ? matchingPassengerAccount.is_email_verified
              : false;
            booking.passenger_detail.isContactVerified = matchingPassengerAccount
              ? matchingPassengerAccount.is_contact_verified
              : false;
            booking.passenger_detail.contact = matchingPassengerAccount
              ? matchingPassengerAccount.contact
              : "";
            booking.passenger_detail.email = matchingPassengerAccount
              ? matchingPassengerAccount.email
              : "";
            booking.passenger_detail.firebase_token = matchingPassengerAccount
              ? matchingPassengerAccount.firebase_token
              : "";
          }
        }
        if (ride_passenger.length > 0) {
          for (let passenger of booking.ride_detail.passenger_bookings) {
            const matchingRidePassenger = ride_passenger.find((user) => user.id === passenger.passenger_detail.user_id);
            if (matchingRidePassenger) {
              const matchingRidePassengerAccount = accounts.find((account) => account.id === matchingRidePassenger.id);
              passenger.passenger_detail.isEmailVerified = matchingRidePassengerAccount
                ? matchingRidePassengerAccount.is_email_verified
                : false;
              passenger.passenger_detail.isContactVerified = matchingRidePassengerAccount
                ? matchingRidePassengerAccount.is_contact_verified
                : false;
              passenger.passenger_detail.contact = matchingRidePassengerAccount
                ? matchingRidePassengerAccount.contact
                : "";
              passenger.passenger_detail.email = matchingRidePassengerAccount
                ? matchingRidePassengerAccount.email
                : "";
              passenger.passenger_detail.firebase_token = matchingRidePassengerAccount
                ? matchingRidePassengerAccount.firebase_token
                : "";
            }
          }
        }
        // const matchingAccount = accounts.find(
        //   (account) => booking.ride_detail.driver_detail.user_id === account.id
        // );
        // booking.ride_detail.driver_detail.isEmailVerified = matchingAccount
        //   ? matchingAccount.is_email_verified
        //   : false;
        // booking.ride_detail.driver_detail.isContactVerified = matchingAccount
        //   ? matchingAccount.is_contact_verified
        //   : false;
        return booking;
      });
      return mappedAccounts;
    }
  },
  mapProfilesToAccountsForDriverEmailVerifiedKeyForRide: (accounts, rides, filter_users) => {
    let driver = filter_users.filter((array) => array.type == "driver")
    let ride_passenger = filter_users.filter((array) => array.type == "ride_passenger")

    const mappedAccounts = rides.map((ride) => {

      if (driver.length > 0) {
        const matchingDriver = driver.find((user) => user.id === ride.driver_detail.user_id);
        if (matchingDriver) {
          const matchingAccount = accounts.find((account) => account.id === matchingDriver.id);
          ride.driver_detail.isEmailVerified = matchingAccount
            ? matchingAccount.is_email_verified
            : false;
          ride.driver_detail.isContactVerified = matchingAccount
            ? matchingAccount.is_contact_verified
            : false;
          ride.driver_detail.contact = matchingAccount
            ? matchingAccount.contact
            : "";
          ride.driver_detail.email = matchingAccount
            ? matchingAccount.email
            : "";
          ride.driver_detail.firebase_token = matchingAccount
            ? matchingAccount.firebase_token
            : "";
        }
      }
      if (ride_passenger.length > 0) {
        for (let passenger of ride.passenger_bookings) {
          const matchingRidePassenger = ride_passenger.find((user) => user.id === passenger.passenger_detail.user_id);
          if (matchingRidePassenger) {
            const matchingRidePassengerAccount = accounts.find((account) => account.id === matchingRidePassenger.id);
            passenger.passenger_detail.isEmailVerified = matchingRidePassengerAccount
              ? matchingRidePassengerAccount.is_email_verified
              : false;
            passenger.passenger_detail.isContactVerified = matchingRidePassengerAccount
              ? matchingRidePassengerAccount.is_contact_verified
              : false;
            passenger.passenger_detail.contact = matchingRidePassengerAccount
              ? matchingRidePassengerAccount.contact
              : "";
            passenger.passenger_detail.email = matchingRidePassengerAccount
              ? matchingRidePassengerAccount.email
              : "";
            passenger.passenger_detail.firebase_token = matchingRidePassengerAccount
              ? matchingRidePassengerAccount.firebase_token
              : "";
          }
        }
      }
      return ride;
    });
    return mappedAccounts;

  },
  mapRideToPaymentsForRide: (payments, rides) => {
    const mappedAccounts = rides.map((ride) => {

      const activePassengerBookings = ride.passenger_bookings.filter(
        (booking) => booking.is_active === true && (booking.booking_status == 1 || booking.booking_status == 2 || booking.booking_status == 4)
      );
      const totalPassengerAmount = activePassengerBookings.reduce(
        (sum, booking) => sum + booking.total_amount,
        0
      );
      const totalRideAmount = ride.available_seat * ride.total_price
      const pending_amount = totalRideAmount - totalPassengerAmount;

      if (ride.passenger_bookings.length > 0) {
        for (let passenger of ride.passenger_bookings) {
          const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == passenger.ride_id && payment.profile_id == passenger.profile_id && payment.passenger_booking_id == passenger.id);
          passenger.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : {}
        }
      }
      const updatedItem = {
        ...ride,
        total_ride_amount: totalRideAmount,
        received_amount: totalPassengerAmount,
        pending_amount: pending_amount,
      };
      return updatedItem;
    });
    return mappedAccounts;

  },
  mapBookingToPaymentsForRide: (payments, bookings) => {
    const mappedAccounts = bookings.map((booking) => {

      const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == booking.ride_id && payment.profile_id == booking.profile_id && payment.passenger_booking_id == booking.id);
      booking.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : {}

      if (booking.ride_detail.passenger_bookings.length > 0) {
        for (let passenger of booking.ride_detail.passenger_bookings) {
          const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == passenger.ride_id && payment.profile_id == passenger.profile_id && payment.passenger_booking_id == passenger.id);
          passenger.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : {}
        }
      }
      console.log("booking", booking)
      return booking;
    });
    return mappedAccounts;

  },
  mapBookingToPaymentsForAllHistory: (payments, bookings, type) => {
    if (type && type != 1) {
      const groupByDate = bookings.map((groupbydate) => {
        const mappedAccounts = groupbydate.data.map((booking) => {

          const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == booking.ride_id && payment.profile_id == booking.profile_id && payment.passenger_booking_id == booking.id);
          booking.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : {}

          return booking;
        });
        return {
          date: groupbydate.date,
          data: mappedAccounts
        }
      });
      return groupByDate
    } else {
      const mappedAccounts = bookings.map((booking) => {

        const matchingRidePassengerAccount = payments.find((payment) => payment.ride_id == booking.ride_id && payment.profile_id == booking.profile_id && payment.passenger_booking_id == booking.id);
        booking.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : {}

        return booking;
      });
      return mappedAccounts;
    }

  },
  mapBookingToPaymentsRefund: (payments, bookings) => {
    let finalArray = [];
    const mappedAccounts = bookings.map((booking) => {
      const matchingRidePassengerAccount = payments.data.find((payment) => payment.passenger_booking_id == booking.id);
      booking.payment_detail = matchingRidePassengerAccount ? matchingRidePassengerAccount : null

      if (booking.payment_detail !== null) {
        finalArray = [...finalArray, booking]
      }
    });
    return finalArray;

  },
};
