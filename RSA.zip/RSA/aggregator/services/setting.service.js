const console = require("../config/logs.config")("yap:aggregator:services:user");
const {
    env: {
        SETTING_SERVICE_URL
    },
} = require("../config")
const axios = require("axios");
const { decryptResponseBody } = require("./crypto.service");
module.exports = {
    // sortByColumns: ["name", "country.name"],
    sortByColumns: ["name"],
    getProfilesList: async ({
        search,
        page,
        limit,
        sortBy,
        orderBy,
        profiles,
        users
    }) => {
        const sortByColumns = module.exports.sortByColumns;
        if (!sortByColumns.includes(sortBy)) { sortBy = ""; orderBy = ""; }

        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles', {
                params: {
                    ...(search && { search }),
                    ...(page && { page }),
                    ...(limit && { limit }),
                    ...(sortBy && { sortBy }),
                    ...(orderBy && { orderBy }),
                    ...(profiles && { profiles }),
                    ...(users && { users }),
                }
            });

            const { data, count } = decryptResponseBody(response.headers.get("IV"), response.data);
            return { data, count };
        } catch (err) {
            throw err;
        }
    },
    getAnswerList: async (ids) => {
        try {
            
            const response = await axios.get(SETTING_SERVICE_URL + '/enum/answers?ids=' + ids);
            console.log("answerlist++",response.data)
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getProfileCourseByIdOrUserId: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/course/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getProfileInterestByIdOrUserId: async (id) => {
        try {
            const response = await axios.get(USER_SERVICE_URL + '/profiles/getInterest/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },

    deleteProfileByIdOrUserId: async (id) => {
        try {
            const response = await axios.delete(USER_SERVICE_URL + '/profiles/' + id);

            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    updateProfileByIdOrUserId: async (id, {
        name, city, zip_code, profile_type, dob, profile_detail, address
    }) => {
        const response = await axios.patch(USER_SERVICE_URL + '/profiles/' + id, {
            ...(name && { name }),
            ...({ city }),
            ...(zip_code && { zip_code }),
            ...({ dob }),
            // ...(profile_type && {profile_type}),
            // ...({profile_detail}),
            ...(address && { address })
        });

        const data = decryptResponseBody(response.headers.get("IV"), response.data);
        return { status: response.status, data };
    },
    updateProfileCourseByIdOrUserId: async (id, {
        type
    }) => {
        const response = await axios.post(USER_SERVICE_URL + '/course/' + id, {
            ...(type && { type }),
        });

        const data = decryptResponseBody(response.headers.get("IV"), response.data);
        return { status: response.status, data };
    },
    getVehicleList: async (auth) => {
        try { 
            const response = await axios.get(SETTING_SERVICE_URL + '/enum/vehicles',{
                headers: {
                    Authorization: auth,
                },
            });
            // console.log("vehicle++",response)
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getColourList: async (auth) => {
        try {
            
            const response = await axios.get(SETTING_SERVICE_URL + '/enum/colours',{
                headers: {
                    Authorization: auth,
                },
            });
            // console.log("vehicle++",response)
            const data = decryptResponseBody(response.headers.get("IV"), response.data);
            return data;
        } catch (err) {
            throw err;
        }
    },
    getReversePriceCalculations: async (requestedBody) => {
        try {
          const url =
            SETTING_SERVICE_URL + "/recommendation/reverse_price_calculation";
          const response = await axios.post(
            url,
            requestedBody
          );
          const data = decryptResponseBody(response.headers.get("IV"), response.data);
          return data.data;
        } catch (err) {
          throw err;
        }
      },
};