const console = require("../config/logs.config")('yap:services:crypto');
const bcrypt = require('bcryptjs');
const crypto = require("crypto-js");
const { env: { RESPONSE_ENCRYPTION_KEY } } = require("../config")

module.exports = {
    hash: (value) => bcrypt.hashSync(value, 10),
    randomHash: (length = 10) => {
        let result = '';
        const characters =
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@-';
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return module.exports.hash(result);
    },
    compareHash: (value, hash) => bcrypt.compareSync(value, hash),
    encryptRequestBody: (value) => {
        const iv = crypto.lib.WordArray.random(16);
        const encryptedValue = crypto.AES.encrypt(JSON.stringify(value), RESPONSE_ENCRYPTION_KEY, { iv: iv }).toString();
        return encryptedValue;
    },
    decryptRequestBody: (value) => {
        const decryptedValue = crypto.AES.decrypt(value, RESPONSE_ENCRYPTION_KEY)
        const decryptedString = decryptedValue.toString(crypto.enc.Utf8);
        const decryptedJson = JSON.parse(decryptedString);
        return decryptedJson;
    },
    encryptResponseBody: (body) => {
        const iv = crypto.lib.WordArray.random(16);
        return {
            iv,
            body: crypto.AES.encrypt(JSON.stringify(body), RESPONSE_ENCRYPTION_KEY, { iv }).toString()
        }
    },
    decryptResponseBody: (iv, body) => {
        const decryptedValue = crypto.AES.decrypt(body.data, RESPONSE_ENCRYPTION_KEY,
            {
                iv: crypto.enc.Utf8.parse(iv),
            }
        );

        const decryptedParsedData = JSON.parse(JSON.parse(decryptedValue.toString(crypto.enc.Utf8)));

        return decryptedParsedData;
    }
}