const console = require("../config/logs.config")(
  "rsa:aggregator:services:payment"
);
const {
  env: { PAYMENT_SERVICE_URL },
} = require("../config");
const axios = require("axios");
const { decryptResponseBody } = require("./crypto.service");

module.exports = {
  getPassengerRidePayment: async (ride_id) => {
    try {
      const response = await axios.get(
        PAYMENT_SERVICE_URL + "/payments/" + ride_id
      );
      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  getAllRidePayment: async () => {
    try {
      const response = await axios.get(
        PAYMENT_SERVICE_URL + "/payments"
      );
      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  getPassengerRefundPayment: async ({refund_status}) => {
    try {
      const response = await axios.get(
        PAYMENT_SERVICE_URL + "/payments/refund", {
          params: {
            ...(refund_status && { refund_status }),
        }
      });
      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
  savePayment: async (requestedBody) => {
    try {
      const url = PAYMENT_SERVICE_URL + "/payments";
      const response = await axios.post(url, requestedBody);
      const data = decryptResponseBody(
        response.headers.get("IV"),
        response.data
      );
      return data;
    } catch (err) {
      throw err;
    }
  },
};
