module.exports = {
    crypto: require("./crypto.service"),
    auth: require("./auth.service"),
    user: require("./user.service"),
    token: require("./token.service"),
    helper: require("./helper.service"),
    payment: require("./payment.service"),
    setting: require("./setting.service"),
    s3: require("./s3.service"),
    file: require("./file.service"),
}