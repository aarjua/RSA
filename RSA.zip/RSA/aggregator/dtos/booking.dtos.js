const joi = require("joi");

const passengerBookingDtos = joi.object({
  ride_id: joi.string().uuid().required(),
  start_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  start_point_latitude: joi.string().required(),
  start_point_longitude: joi.string().required(),
  end_city_name: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_city_address: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  end_point_latitude: joi.string().required(),
  end_point_longitude: joi.string().required(),
  distance: joi.number().required(),
  is_round_trip: joi.boolean().required(),
  total_passenger: joi.number().required(),
  amount_per_person: joi.number().required().precision(2),
  total_amount: joi.number().required().precision(2),
  price_master_id: joi.string().uuid().required(),
  payment_type: joi.string().required(),
  passenger_detail: joi
    .array()
    .items(
      joi.object({
        first_name: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .required(),
        last_name: joi
          .string()
          .trim()
          .allow(...[null, ""])
          .optional(),
        age: joi.string().required(),
        seat_location: joi.string().optional(),
      })
    )
    .optional(),
});

module.exports = {
  passengerBookingDtos,
};
