const express = require("express");
const router = express.Router();
const {
    auth: { auth },
} = require("../middlewares");
const { DashboardController } = require("../controllers");

router.get("/", DashboardController.dashboardCount);

module.exports = router;