const express = require("express");
const router = express.Router();
const {
  auth: { auth },
  multerMiddleware
} = require("../middlewares");
const { UserController } = require("../controllers");


router.route("/response-code").get(UserController.allResponseCode);
router.route("/").get(UserController.list).post(multerMiddleware.uploadSingle("image"), UserController.add);
router.route("/export").get(UserController.exportUsers);
// router.route("/get-counts/:id").get(UserController.getCounts)
router.route("/google-sign-in").post(UserController.googleSignIn);
router.route("/website-signup").post(UserController.websiteSignup);
router.route("/bookings/refund").get(UserController.getBookingListRefund);
router.route("/get-user-details").get(auth(), UserController.getUserDetails);
router.route("/get-car/:profile_id").get(auth(), UserController.getUserCarDetails);
router.route("/get-user-prefrense/:profile_id").get(auth(), UserController.getUserCarDetails);
router.route("/questions").get(UserController.questionList);
router.route("/questions/:id").get(UserController.questionDetail);
router.route("/update-rc-status/:user_id/:id/:status").patch(auth(), UserController.toggleRCStatus)
router.route("/update-role-status/:user_id/:id/:status").patch(auth(), UserController.toggleProfileStatus)
// router.route("/add-driver").post(UserController.addDriver);
router.route("/rides").get(UserController.getAllRidelist);
router.route("/rides/:id").get(UserController.getRideById);
router.route("/rides/availableRideList").post(UserController.getAvailbleRidelist);
router.route("/rides/getAvailbleRidelistforTesting").post(UserController.getAvailbleRidelistforTesting);
router.route("/bookings").get(UserController.getAllBookingList);
router.route("/bookings/:profile_id").post(UserController.addBooking)
router.route("/bookings/:id").get(UserController.getAllBookingByID);
router.route("/bookings/block-unblock/:driver_user_id/:user_id/:id/:status").patch(UserController.toggleBookingActiveStatus)
router
  .route("/self")
  .get(auth(), UserController.getSelf)
  .patch(auth(), UserController.updateSelf)
  .delete(auth(), UserController.deleteSelf);

router
  .route("/:id")
  .get(auth(), UserController.get)
  .patch(auth(),multerMiddleware.uploadSingle("image"), UserController.update)
  .delete(auth(), UserController.delete);

// router.delete("/",auth(), UserController.delete);


module.exports = router;
