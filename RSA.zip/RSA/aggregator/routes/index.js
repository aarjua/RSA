var express = require('express');
var router = express.Router();

router.get('/hc', (req, res) => res.sendStatus(200));

router.use('/users', require("./user.route"));
router.use("/dashboard", require("./dashboard.route"));

module.exports = router;
