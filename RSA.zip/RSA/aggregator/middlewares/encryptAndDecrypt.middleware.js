const { crypto: { decryptRequestBody } } = require("../services");
const { encryptResponseBody } = require("../services/crypto.service");
const { responseCodes } = require("../config");

module.exports = {
    decryptRequestBodyMiddleware: (req, res, next) => {
        try {
            if (req.method !== "GET" && req.body.data) {
                req.body = decryptRequestBody(req.body.data);
            }
            next();
        } catch (err) {
            return res.status(400).json({ code: responseCodes.SE.invalidEncryptedBody.code })
        }
    },
    encryptResponseBodyMiddleware: (req, res, next) => {
        const originalSend = res.send;

        res.send = function (body) {
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Content-Encoding', 'aes-256-cbc');
            const { iv, body: encryptedBody } = encryptResponseBody(body);
            res.setHeader('IV', iv.toString());
            originalSend.call(this, JSON.stringify({ data: encryptedBody }));
        }
        next();
    }
}