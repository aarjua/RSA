module.exports = {
    encryptDecryptRequestResponse: require("./encryptAndDecrypt.middleware"),
    auth: require("./auth.middleware"),
    multerMiddleware: require("./multer.middleware")
}