const Sequelize = require("sequelize");
const console = require("./logs.config")("yap:db");
const env = require("./env.config");

const sequelize = new Sequelize(env.DB_NAME, env.DB_USER, env.DB_PASS, {
  host: env.DB_HOST,
  dialect: env.DB_DIALECT,
  port: env.DB_PORT,
  define: {
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  },
  logging: false,
  pool: {
    max: 10,
    min: 0,
    idle: 10000,
  },
  sync: false, // disable automatic synchronization
  underscoredAll: true, // snake_case column names, also forces createdAt, updatedAt and deletedAt to be in snake_case
});
sequelize
  .authenticate()
  .then(() => {
    console.log("Connection has been established successfully.");
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
  });

module.exports = { Sequelize, sequelize };
