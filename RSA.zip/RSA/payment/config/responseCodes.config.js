/**
 * SM - System
 * AU - Auth
 * UR - User
 */
  
module.exports = {
    /**
     * SE - System
     */
    SE: {
      internalError: {
        code: "SE500",
        message: "internal server error",
      },
      invalidEncryptedBody: {
        code: "SE501",
        message: "invalid encrypted body or couldn't decrypt the request body",
      },
    },
    /**
     * CM -Country
     */
    CM: {
      notFound: {
        code: "CM404",
        message: " country name not found",
      },
    },
    /**
     * AU -Authentication
     */
    AU: {
      invalidToken: {
        code: "AU411",
        message: "invalid token"
      }
    },
    /**
     * CA- Category
     */
    CA: {
       created: {
        code: "CA200",
        message: "created",
       },
       invalidBody: {
        code: "CA400",
        message: "body invalid",
       },
       categoryAlreadyExist: {
        code: "CA401",
        message: "category already exist"
       },
       notFound: {
        code:"CA403",
        message: "category not found"
       },
       invalidQuery: {
        code: "AU410",
        message: "query invalid",
      },
       deleted: {
        code: "CA201",
        message: "category deleted successfully"
       },
       updated: {
         code: "CA202",
         message: "category updated successfully"
       }
    },
    /**
     * OF- Offer Master
     */
    OF: {
       created: {
        code: "OF200",
        message: "created",
       },
       invalidBody: {
        code: "OF400",
        message: "body invalid",
       },
       categoryAlreadyExist: {
        code: "OF401",
        message: "category already exist"
       },
       notFound: {
        code:"OF403",
        message: "category not found"
       },
       invalidQuery: {
        code: "OF410",
        message: "query invalid",
      },
       deleted: {
        code: "OF201",
        message: "category deleted successfully"
       },
       updated: {
         code: "OF202",
         message: "category updated successfully"
       }
    },
    /**
     * PG - Page
     */
    PG: {
      notFound: {
        code:"PG403",
        message: "not found"
       },
       invalidBody: {
        code: "PG400",
        message: "body invalid",
       },
       alreadyExists:{
        code: "PG401",
        message: "type already exists",
       },
       created: {
        code: "PG200",
        message: "created",
       },
       updated: {
        code:"PG201",
        message: "updated",
       },
       deleted: {
        code:"PG202",
        message: "deleted",
       }

    },
    /**
     * PA - Payament Gateway
     */
    PA: {
      notFound: {
        code:"PA403",
        message: "not found"
       },
       invalidBody: {
        code: "PA400",
        message: "body invalid",
       },
       alreadyExists:{
        code: "PA401",
        message: "type already exists",
       },
       created: {
        code: "PA200",
        message: "created",
       },
       updated: {
        code:"PA201",
        message: "updated",
       },
       deleted: {
        code:"PA202",
        message: "deleted",
       },
       developing: {
        code:"PA205",
        message: "under development",
       },
       approveRefundStatusChange: {
        code:"PA206",
        message: "approve refund status changed",
       }

    },
  /**
   * IN - Interest
   */
  IN: {
    notFound: {
      code:"IN403",
      message: "not found"
     },
     invalidBody: {
      code: "IN400",
      message: "body invalid",
     },
     alreadyExists:{
      code: "IN401",
      message: "already exists",
     },
     created: {
      code: "IN200",
      message: "created",
     },
     updated: {
      code:"IN201",
      message: "updated",
     },
     deleted: {
      code:"IN202",
      message: "deleted",
     },
     appDataNotFound: {
      code:"IN204",
      message: "app data not found",
     },
     appalreadyExists:{
      code: "IN402",
      message: "app setting already exists",
     },

  },
    
    /**
     * U - System User
     */
    UR: {
      created: {
        code: "SU201",
        message: "created",
      },
      notFound: {
        code: "SU404",
        message: "system user not found",
      },
      validations: {
        invalidBody: {
          code: "SU400",
          message: "body invalid",
        },
        exists: {
          code: "SU409",
          message: "already exists",
        },
      },
      updated: {
        code: "SU200",
        message: "updated",
      },
    },

  };
  
  (() => {
    const codes = new Set();
  
    const checkCodesUniqueness = (obj) => {
      for (const key in obj) {
        const code = obj[key].code;
        const message = obj[key].message;
  
        if (code !== undefined) {
          if (codes.has(code)) {
            throw new Error(`Duplicate code found: ${code}.`);
          } else {
            codes.add(code);
          }
        }
  
        if (message !== undefined && /[A-Z]/.test(message)) {
          throw new Error(`Capital letters found in message: ${message}`);
        }
  
        if (typeof obj[key] === "object") {
          checkCodesUniqueness(obj[key]);
        }
      }
    };
  
    checkCodesUniqueness(module.exports);
  })();
  