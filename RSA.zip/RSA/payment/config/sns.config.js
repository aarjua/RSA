const console = require("./logs.config")('yap:auth:config:sns');
const { snsTopics } = require("./enums.config");
const { AWS_ID, AWS_ACCOUNT_ID, AWS_SECRET_KEY, AWS_REGION, ENDPOINT, PORT } = require("./env.config");
const AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION, accessKeyId: AWS_ID, secretAccessKey: AWS_SECRET_KEY });
const sns = new AWS.SNS();


const newUserTopic = {
    Protocol: 'http',
    TopicArn: `arn:aws:sns:${AWS_REGION}:${AWS_ACCOUNT_ID}:${snsTopics.newUser}`,
    Endpoint: `${ENDPOINT}:${PORT}/hc`
}

//TODO: Do this later on.