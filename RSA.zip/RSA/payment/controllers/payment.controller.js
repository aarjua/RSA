const console = require("../config/logs.config")(
    "rsa:users:controllers:profile"
);
const { Payment } = require("../models");
const { responseCodes } = require("../config");
const {
    Sequelize: { Op },
    sequelize,
} = require("../config/db.config");
const joi = require("joi")
const { updateRefundPaymentStatusDtos, addPaymentDtos } = require("../dtos/paymentDtos");
module.exports = {
    get: async (req, res) => {
        try {
            const { ride_id } = req.params;
            let payments = await Payment.findAll({
                where: {
                    ride_id,
                },
            });
            if (!payments)
                return res.status(400).json({ code: responseCodes.PA.notFound.code });
            payments = payments.map(item => item.dataValues);
            return res.status(200).json({ data: payments });
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
    getAll: async (req, res) => {
        try {
            let payments = await Payment.findAll();
            if (!payments)
                return res.status(400).json({ code: responseCodes.PA.notFound.code });
            payments = payments.map(item => item.dataValues);
            return res.status(200).json({ data: payments });
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
    add: async (req, res) => {
        try {
            const { error, value } = addPaymentDtos.validate(req.body);
            if (error) {
                console.error("error:", error);
                return res
                    .status(400)
                    .json({ code: responseCodes.PA.validations.invalidBody.code, description: error });
            }
            if (value.payment_type == "cash") {
                let paymentObject = {
                    ride_id: value.ride_id,
                    profile_id: value.profile_id,
                    payment_type: value.payment_type,
                    payment_status: "pending",
                    currency: value.currency_name,
                    total_amount: value.total_amount,
                    is_refund: value.is_refund,
                    base_fare: value.base_fare,
                    wait_charges: value.wait_charges,
                    tax_amount: value.tax_amount,
                    is_tax_percentage: value.is_tax_percentage,
                    total_fare: value.total_amount,
                    passenger_booking_id: value.passenger_booking_id
                }
                var bookingCreated = await Payment.create(paymentObject);
                return res
                    .status(201)
                    .json({ code: responseCodes.PA.created.code, });
            } else {
                return res
                    .status(40)
                    .json({ code: responseCodes.PA.developing.code });
            }
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
    updateRefundStatus: async (req, res) => {
        try {
            const { error, value } = updateRefundPaymentStatusDtos.validate(req.body);
            if (error) {
                console.error("error:", error);
                return res
                    .status(400)
                    .json({ code: responseCodes.PA.validations.invalidBody.code, description: error });
            }
            const paymentInfo = await Payment.findOne({
                where: {
                    ride_id: value.ride_id,
                    profile_id: value.profile_id,
                    passenger_booking_id: value.passenger_booking_id,
                    payment_status: "payment_success"
                }
            });
            if (!paymentInfo) {
                return res
                    .status(404)
                    .json({ message: "Payment is not found" });
            }
            await paymentInfo.update({
                is_refund: true
            })
            return res.status(200).json({ message: "Refund reuqest has been proceeded" })
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
    getAllForRefund: async (req, res) => {
        try {
            const {refund_status} = req.query;
            let whereCondition
            if (refund_status && refund_status == "approved") {
                whereCondition= {
                    [Op.and]: [
                    { is_refund: true },
                    {is_approved: true }
                  ]
                }
              } else if (refund_status && refund_status == "rejected") {
                whereCondition= {
                    [Op.and]: [
                    { is_refund: true },
                    {is_approved: false }
                  ]
                }
              }else{
                whereCondition = {
                    is_refund: true
                }
                }
            let payments = await Payment.findAll({
                where: whereCondition
            });
            if (!payments)
                return res.status(400).json({ code: responseCodes.PA.notFound.code });
            return res.status(200).json({ data: payments });
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
    approveRefundStatus: async (req, res) => {
        try {
            const { id } = req.params;
            const { is_approved } = await joi
            .object({
                is_approved: joi.boolean().required(),
            })
            .validateAsync(req.body)
            .catch((err) => {
              console.error("err:", err);
              return res.status(400).json({
                code: responseCodes.PB.validations.invalidBody.code,
                description: err,
              });
            });
            const paymentRefund = await Payment.findOne({
                where: {
                    id: id
                }
            });
            if (!paymentRefund) {
                return res
                    .status(404)
                    .json({ code: responseCodes.PA.notFound.code});
            }
            const a = await paymentRefund.update({
                is_approved: is_approved
            })
            return res.status(200).json({ code: responseCodes.PA.approveRefundStatusChange.code })
        } catch (err) {
            console.error("err:", err);
            return res
                .status(500)
                .json({ code: responseCodes.SE.internalError.code });
        }
    },
};