module.exports = {
    PaymentController: require("./payment.controller"),
  };
  