const console = require("../config/logs.config")('yap:services:helper');
module.exports = {
    replaceObjectEmptyStringKeysWithNull: (obj) => replaceEmptyStringWithNull(obj),
}

function replaceEmptyStringWithNull(obj) {
    if (obj === null || obj === undefined) {
        return null;
    } else if (Array.isArray(obj)) {
        return obj.map(replaceEmptyStringWithNull);
    } else if (typeof obj === 'object') {
        if (obj instanceof Date) {
            return obj;
        } else {
            return Object.keys(obj).reduce((acc, key) => {
                acc[key] = replaceEmptyStringWithNull(obj[key]);
                return acc;
            }, {});
        }
    } else if (obj === '') {
        return null;
    } else {
        return obj;
    }
}