module.exports = {
    crypto: require("./crypto.service"),
    helper: require("./helper.service"),
    token: require("./token.service"),
    // mail: require("./mail.service"),
    // file: require("./file.service"),
    s3: require("./s3.service")
}