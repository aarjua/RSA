'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('payments', 'parent_id', {
      type: Sequelize.UUID,
      allowNull: true,
    });
    await queryInterface.addColumn('payments', 'is_approved', {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('payments', 'parent_id');
    await queryInterface.removeColumn('payments', 'is_approved');
  }
};
