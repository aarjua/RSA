"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("payments", {
      id: {
        type: Sequelize.INTEGER,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      ride_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      profile_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      passenger_booking_id: {
        type: Sequelize.UUID,
        allowNull: true,
      },
      payment_type: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      transaction_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      currency: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      total_amount: {
        type: Sequelize.DOUBLE,
        allowNull: true,
      },
      payment_status: {
        type: Sequelize.STRING, //Enum:- Paid/cancelled
        allowNull: true,
      },
      payment_gateway_response: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_refund: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      base_fare: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      wait_charges: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      tax_amount: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_tax_percentage: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
      },
      total_fare: {
        type: Sequelize.DOUBLE,
        allowNull: true,
      },
      is_approved: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("payments");
  },
};
