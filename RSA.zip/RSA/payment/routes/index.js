var express = require("express");
var router = express.Router();

router.get("/hc", (req, res) =>  res.sendStatus(200));

router.use("/payments", require("./payment.route"));

module.exports = router;
