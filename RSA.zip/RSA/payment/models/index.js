module.exports = {
  Payment: require("./payment.model"),
};
