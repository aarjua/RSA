const {
  db: {
    sequelize,
    Sequelize: { DataTypes },
  },
} = require("../config");
const Payment = sequelize.define(
  "payment",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    ride_id: {
      type: DataTypes.UUID,
      allowNull: true,
    },
    profile_id: {
      type: DataTypes.UUID,
      allowNull: true,
    },
    passenger_booking_id: {
      type: DataTypes.UUID,
      allowNull: true,
    },
    payment_type: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    transaction_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    currency: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    total_amount: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    payment_status: {
      type: DataTypes.STRING, //Enum:- Paid/cancelled
      allowNull: true,
    },
    payment_gateway_response: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_refund: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    base_fare: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    wait_charges: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    tax_amount: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_tax_percentage: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    total_fare: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    is_approved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    underscored: true,
  }
);

module.exports = Payment;
