const joi = require("joi");

const addPaymentDtos = joi.object({
  ride_id: joi.string().uuid().required(),
  profile_id: joi.string().uuid().required(),
  payment_type: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  currency: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  total_amount: joi.number().required(),
  is_refund: joi.boolean().required(),
  base_fare: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  wait_charges: joi
    .string()
    .trim()
    .allow(...[null, ""])
    .optional(),
  tax_amount: joi.number().required(),
  is_tax_percentage: joi.number().required(),
  total_fare: joi.number().required(),
  passenger_booking_id: joi.string().uuid().optional(),
});

const updateRefundPaymentStatusDtos = {
  ride_id: joi.string().uuid().required(),
  profile_id: joi.string().uuid().required(),
  passenger_booking_id: joi.string().uuid().required(),
};

module.exports = {
  addPaymentDtos,
  updateRefundPaymentStatusDtos,
};
